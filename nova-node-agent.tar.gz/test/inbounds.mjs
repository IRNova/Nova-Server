import { test } from "node:test";
import assert from "node:assert/strict";

import {
  normalizeInbound,
  validateInbound,
  clientsForInbound,
  buildInbound,
  genRealityKeys,
  genShortId,
  genSSPassword,
  VISION_FLOW,
  SS_METHOD,
} from "../src/xray/inbounds.mjs";
import { generateXrayConfig } from "../src/xray/config.mjs";

const realityKeys = {
  privateKey: "EJwRvzyxpkJXSUOphvklb4zcrSiiX7_dz5SXSO4VpEI",
  publicKey: "gMek7p-asiIMUGsUbripC7kMahsAl-41J7fHjwnOLRQ",
};

function realityVision(over = {}) {
  return normalizeInbound({
    id: "rv", protocol: "vless", network: "tcp", security: "reality",
    port: 8443, flow: VISION_FLOW,
    reality: { dest: "www.microsoft.com:443", serverNames: ["www.microsoft.com"], shortIds: ["0123abcd"], ...realityKeys },
    ...over,
  });
}

const USERS = [
  { id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "a", enabled: true },
  { id: "u2", uuid: "22222222-2222-4222-8222-222222222222", email: "b", enabled: true },
  { id: "u3", uuid: "33333333-3333-4333-8333-333333333333", email: "c", enabled: false },
];

test("validateInbound accepts a reality-vision inbound", () => {
  assert.equal(validateInbound(realityVision()).ok, true);
});

test("validateInbound rejects reality over websocket, reality without keys, and stray flow", () => {
  assert.equal(validateInbound(realityVision({ network: "ws" })).ok, false);
  assert.equal(validateInbound(realityVision({ reality: { dest: "x:443", serverNames: ["x"] } })).ok, false);
  // vision flow on a grpc inbound is invalid
  assert.equal(
    validateInbound(normalizeInbound({ protocol: "vless", network: "grpc", security: "tls", sni: "x", port: 2053, flow: VISION_FLOW })).ok,
    false,
  );
  // tls with no sni
  assert.equal(validateInbound(normalizeInbound({ protocol: "vless", network: "ws", security: "tls", port: 2087 })).ok, false);
  // shadowsocks must not carry tls/reality
  assert.equal(validateInbound(normalizeInbound({ protocol: "shadowsocks", network: "tcp", security: "tls", port: 9000 })).ok, false);
});

test("clientsForInbound: vless carries the vision flow, dedupes, drops disabled", () => {
  const clients = clientsForInbound(realityVision(), USERS);
  assert.equal(clients.length, 2); // u3 disabled
  assert.equal(clients[0].id, USERS[0].uuid);
  assert.equal(clients[0].flow, VISION_FLOW);
});

test("clientsForInbound: trojan reuses uuid as password, ss derives a stable key", () => {
  const trojan = normalizeInbound({ protocol: "trojan", network: "grpc", security: "tls", sni: "x", port: 2083, serviceName: "n" });
  assert.equal(clientsForInbound(trojan, USERS)[0].password, USERS[0].uuid);

  const ss = normalizeInbound({ protocol: "shadowsocks", network: "tcp", security: "none", port: 9000 });
  const a = clientsForInbound(ss, USERS);
  const b = clientsForInbound(ss, USERS);
  assert.equal(a[0].password, b[0].password); // deterministic
  assert.equal(a[0].method, undefined); // SS-2022 clients carry no method
  assert.notEqual(a[0].password, a[1].password); // per-user
});

test("clientsForInbound honours allUsers=false + userIds", () => {
  const inb = realityVision({ allUsers: false, userIds: ["u2"] });
  const clients = clientsForInbound(inb, USERS);
  assert.equal(clients.length, 1);
  assert.equal(clients[0].id, USERS[1].uuid);
});

test("buildInbound: reality-vision emits realitySettings + client flow, no cert", () => {
  const inb = realityVision();
  const x = buildInbound(inb, clientsForInbound(inb, USERS), {});
  assert.equal(x.streamSettings.security, "reality");
  assert.equal(x.streamSettings.realitySettings.privateKey, realityKeys.privateKey);
  assert.deepEqual(x.streamSettings.realitySettings.serverNames, ["www.microsoft.com"]);
  assert.deepEqual(x.streamSettings.realitySettings.shortIds, ["0123abcd"]);
  assert.equal(x.settings.clients[0].flow, VISION_FLOW);
  assert.equal(x.streamSettings.tlsSettings, undefined);
});

test("buildInbound: grpc-tls and xhttp-tls emit their transport + cert", () => {
  const defs = { certificateFile: "/c.pem", keyFile: "/c.key" };
  const grpc = normalizeInbound({ protocol: "vless", network: "grpc", security: "tls", sni: "g.example", port: 2053, serviceName: "novagrpc" });
  const gx = buildInbound(grpc, clientsForInbound(grpc, USERS), defs);
  assert.equal(gx.streamSettings.grpcSettings.serviceName, "novagrpc");
  assert.equal(gx.streamSettings.tlsSettings.serverName, "g.example");
  assert.equal(gx.streamSettings.tlsSettings.certificates[0].certificateFile, "/c.pem");

  const xh = normalizeInbound({ protocol: "vless", network: "xhttp", security: "tls", sni: "x.example", port: 2096, path: "/dl", xhttpMode: "packet-up" });
  const xx = buildInbound(xh, clientsForInbound(xh, USERS), defs);
  assert.equal(xx.streamSettings.network, "xhttp");
  assert.equal(xx.streamSettings.xhttpSettings.mode, "packet-up");
  assert.equal(xx.streamSettings.xhttpSettings.path, "/dl");
});

test("buildInbound: shadowsocks-2022 carries method, server psk, per-user clients", () => {
  const inb = normalizeInbound({ protocol: "shadowsocks", network: "tcp", security: "none", port: 9000, ssPassword: "SERVERKEYBASE64==" });
  const x = buildInbound(inb, clientsForInbound(inb, USERS), {});
  assert.equal(x.settings.method, SS_METHOD);
  assert.equal(x.settings.password, "SERVERKEYBASE64==");
  assert.equal(x.settings.network, "tcp,udp");
  assert.equal(x.settings.clients.length, 2);
});

test("genRealityKeys falls back to node crypto and returns base64url keys", async () => {
  const failExec = async () => { throw new Error("no xray"); };
  const { privateKey, publicKey } = await genRealityKeys(failExec);
  // 32 raw bytes -> 43 base64url chars, url alphabet only
  assert.match(privateKey, /^[A-Za-z0-9_-]{43}$/);
  assert.match(publicKey, /^[A-Za-z0-9_-]{43}$/);
  assert.match(genShortId(), /^[0-9a-f]{8}$/);
  assert.ok(Buffer.from(genSSPassword(), "base64").length === 16);
});

test("generateXrayConfig appends standalone inbounds, keeps the front, excludes diagnostics from JSON", () => {
  const rv = realityVision();
  const cfg = generateXrayConfig(USERS, { port: 443, inbounds: [rv] });
  const tags = cfg.inbounds.map((i) => i.tag);
  assert.ok(tags.includes("front"));
  assert.ok(tags.includes(rv.tag));
  assert.ok(tags.includes("api"));
  // the reality inbound is on 8443, the front on 443
  const ri = cfg.inbounds.find((i) => i.tag === rv.tag);
  assert.equal(ri.port, 8443);
  // diagnostics do not leak into the serialised config
  assert.equal(JSON.stringify(cfg).includes("_skippedInbounds"), false);
  assert.deepEqual(cfg._skippedInbounds, []);
});

test("generateXrayConfig drops a standalone inbound that collides with the front port", () => {
  const clash = realityVision({ id: "clash", tag: "clash", port: 443 });
  const cfg = generateXrayConfig(USERS, { port: 443, inbounds: [clash] });
  assert.equal(cfg.inbounds.some((i) => i.tag === "clash"), false);
  assert.equal(cfg._skippedInbounds.length, 1);
  assert.match(cfg._skippedInbounds[0].reason, /already in use/);
});

test("raw mode: a hand-edited inbound is used verbatim, tag forced, clients injected", () => {
  const raw = {
    port: 47744,
    protocol: "vless",
    settings: { clients: [{ id: "placeholder" }], decryption: "none" },
    streamSettings: { network: "tcp", security: "none", tcpSettings: { acceptProxyProtocol: true } },
    tag: "should-be-overridden",
  };
  const inb = normalizeInbound({ raw, allUsers: true });
  assert.equal(inb.port, 47744, "port derives from raw json");
  assert.equal(validateInbound(inb).ok, true, "valid raw passes");
  const built = buildInbound(inb, [{ id: "u-uuid", email: "u" }]);
  assert.equal(built.tag, inb.tag, "tag is forced to the panel tag");
  assert.equal(built.streamSettings.tcpSettings.acceptProxyProtocol, true, "advanced options survive");
  assert.deepEqual(built.settings.clients, [{ id: "u-uuid", email: "u" }], "per-user clients are injected");
  assert.equal(validateInbound(normalizeInbound({ raw: { protocol: "vless" } })).ok, false, "raw without a port is rejected");
});

test("hysteria2 inbound: skipped by xray builder, valid, generates a sing-box inbound", async () => {
  const rec = { protocol: "hysteria2", port: 8443, remark: "Gaming", allUsers: true, enabled: true, obfsType: "salamander", obfsPassword: "sec" };
  const inb = normalizeInbound(rec);
  assert.equal(inb.protocol, "hysteria2");
  assert.equal(validateInbound(inb).ok, true, "valid hysteria2 record");
  assert.equal(inb.obfsType, "salamander");
  // xray builder must skip it (it is a sing-box protocol, not an xray inbound).
  const users = [{ id: "me", uuid: "11111111-1111-4111-8111-111111111111", email: "me", enabled: true }];
  const { generateXrayConfig } = await import("../src/xray/config.mjs");
  const cfg = generateXrayConfig(users, { inbounds: [rec] });
  assert.ok(!cfg.inbounds.some((i) => i.port === 8443), "hysteria2 does not appear as an xray inbound");
  assert.equal((cfg._skippedInbounds || []).some((s) => s.reason && /already in use/.test(s.reason)), false, "not reported as a dropped inbound");
  // sing-box generator emits it.
  const { generateSingboxConfig } = await import("../src/singbox/config.mjs");
  const sb = generateSingboxConfig(users, { port: 443, enableDefault: true, extraInbounds: [{ tag: "hy2-8443", port: 8443, obfsPassword: "sec", serves: () => true }] });
  const hy = sb.inbounds.find((i) => i.listen_port === 8443);
  assert.ok(hy && hy.type === "hysteria2", "sing-box has the 8443 hysteria2 inbound");
  assert.equal(hy.obfs.type, "salamander");
});
