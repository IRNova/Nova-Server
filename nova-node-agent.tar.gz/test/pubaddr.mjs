import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSub } from "../src/subscription.mjs";
import { enumerateProxies, toSingbox, toClash } from "../src/sub-formats.mjs";
import { normalizeInbound } from "../src/xray/inbounds.mjs";

const decode = (b) => Buffer.from(b, "base64").toString("utf8");
const user = (e) => ({ id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "u1", enabled: true, ...e });
const sInb = (extra) => ({ id: "s1", tag: "s1", protocol: "vless", placement: "standalone", network: "ws", security: "tls", port: 8443, path: "/x", enabled: true, ...extra });

test("normalizeInbound keeps a clean pubAddr and drops an unsafe one", () => {
  assert.equal(normalizeInbound({ pubAddr: "sub1.example.com" }).pubAddr, "sub1.example.com");
  assert.equal(normalizeInbound({ pubAddr: "1.2.3.4" }).pubAddr, "1.2.3.4");
  assert.equal(normalizeInbound({ pubAddr: "a b.com" }).pubAddr, "");        // space
  assert.equal(normalizeInbound({ pubAddr: "evil.com/x?q=1" }).pubAddr, ""); // url metachars
  assert.equal(normalizeInbound({}).pubAddr, "");
});

test("pubAddr makes this config dial its own domain; SNI stays the main host", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", inbounds: [sInb({ pubAddr: "sub1.example.com" })], protocols: {},
  }));
  const line = sub.split("\n").find((l) => l.startsWith("vless://") && l.includes(":8443"));
  assert.ok(line, "standalone line present");
  assert.match(line, /@sub1\.example\.com:8443/);   // dials its own subdomain
  assert.match(line, /sni=exit\.example\.com/);      // SNI stays the main host
  assert.doesNotMatch(line, /@exit\.example\.com:8443/);
});

test("no pubAddr keeps the main host (unchanged behavior)", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", inbounds: [sInb()], protocols: {},
  }));
  const line = sub.split("\n").find((l) => l.startsWith("vless://") && l.includes(":8443"));
  assert.match(line, /@exit\.example\.com:8443/);
});

test("pubAddr bypasses the Iran-bridge reroute (dials its domain, not the bridge)", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", tunnelAddr: "198.51.100.10", tunnelPorts: [8443],
    inbounds: [sInb({ pubAddr: "sub1.example.com" })], protocols: {},
  }));
  const line = sub.split("\n").find((l) => l.startsWith("vless://") && l.includes(":8443"));
  assert.match(line, /@sub1\.example\.com:8443/);   // own domain wins over the bridge
  assert.doesNotMatch(line, /198\.51\.100\.10/);
});

test("Clash and sing-box formats honor pubAddr as the server address", async () => {
  const inb = normalizeInbound(sInb({ pubAddr: "sub1.example.com" }));
  const proxies = await enumerateProxies([user({ inboundIds: ["s1"] })], { host: "exit.example.com", inbounds: [inb], protocols: {} });
  const p = proxies.find((x) => x.port === 8443);
  assert.ok(p, "standalone proxy enumerated");
  assert.equal(p.server, "sub1.example.com");        // socket target = own domain
  assert.equal(p.sni, "exit.example.com");            // SNI stays the main host
  assert.match(toSingbox([p], { net: {} }), /"server":\s*"sub1\.example\.com"/);
  assert.match(toClash([p], { net: {} }), /server: "?sub1\.example\.com"?/);
});
