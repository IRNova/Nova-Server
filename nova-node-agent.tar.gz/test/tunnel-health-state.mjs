import test from "node:test";
import assert from "node:assert/strict";
import { openKv } from "../src/kv/sqlite.mjs";
import { maybeTunnelHealth, putSettings } from "../src/server.mjs";
import {
  readTunnelHealth,
  recordTunnelHealth,
  tunnelHealthSample,
  tunnelRouteGate,
  TUNNEL_HEALTH_MAX_SAMPLES,
} from "../src/tunnels/health.mjs";

const failLive = (failureClass = "timeout") => ({
  up: true,
  state: "active",
  probe: { ok: false, state: "fail", failureClass, detail: "payload probe timed out", latencyMs: 4000 },
});
const passLive = () => ({
  up: true,
  state: "active",
  probe: { ok: true, reachable: true, state: "pass", detail: "Nova payload reached", latencyMs: 91, httpStatus: 200 },
});
// Data path forwards traffic but the exit fronts 443 with a proxy, so /install/status
// is not the Nova agent: reachable (routable) but not build-verified.
const reachableLive = () => ({
  up: true,
  state: "active",
  probe: { ok: false, reachable: true, state: "reachable", failureClass: "unverified", detail: "tunnel forwards traffic", latencyMs: 120, httpStatus: 404 },
});

test("tunnel health classifies service, unknown, payload failure, and pass", () => {
  assert.equal(tunnelHealthSample({ up: false, state: "inactive" }, 1).failureClass, "service-down");
  assert.equal(tunnelHealthSample({ up: true, state: "active" }, 2).ok, null);
  assert.equal(tunnelHealthSample(failLive("timeout"), 3).failureClass, "timeout");
  const pass = tunnelHealthSample(passLive(), 4);
  assert.equal(pass.ok, true);
  assert.equal(pass.httpStatus, 200);
  assert.equal(pass.latencyMs, 91);
});

test("three consecutive failures alert once; a pass produces one recovery", async () => {
  const kv = openKv(":memory:");
  try {
    let r = await recordTunnelHealth(kv, failLive(), { now: 1 });
    assert.equal(r.transition, null);
    r = await recordTunnelHealth(kv, failLive(), { now: 2 });
    assert.equal(r.transition, null);
    r = await recordTunnelHealth(kv, failLive(), { now: 3 });
    assert.equal(r.transition, "failed");
    assert.equal(r.alertState, "failed");
    r = await recordTunnelHealth(kv, failLive(), { now: 4 });
    assert.equal(r.transition, null, "sustained failure does not spam");
    r = await recordTunnelHealth(kv, passLive(), { now: 5 });
    assert.equal(r.transition, "recovered");
    assert.equal(r.consecutiveFailures, 0);
    r = await recordTunnelHealth(kv, passLive(), { now: 6 });
    assert.equal(r.transition, null, "continued health does not spam recovery");
  } finally {
    kv.close();
  }
});

test("client routing requires the newest payload success to be fresh", () => {
  const now = 1_000_000;
  assert.equal(tunnelRouteGate({ samples: [] }, { now }).ok, false);
  assert.equal(tunnelRouteGate({ samples: [{ at: now - 1, ok: false }] }, { now }).ok, false);
  assert.equal(tunnelRouteGate({ samples: [{ at: now - 11 * 60_000, ok: true }] }, { now }).ok, false);
  const pass = tunnelRouteGate({ samples: [{ at: now - 1000, ok: true, latencyMs: 88 }] }, { now });
  assert.equal(pass.ok, true);
  assert.equal(pass.latencyMs, 88);
  assert.equal(pass.verified, true);
});

test("a reachable-but-unverified tunnel is routable and does not alert", async () => {
  const now = 1_000_000;
  // Gate: reachable (data path alive) is routable, marked not verified.
  const g = tunnelRouteGate({ samples: [{ at: now - 1000, ok: false, reachable: true, latencyMs: 120 }] }, { now });
  assert.equal(g.ok, true);
  assert.equal(g.verified, false);
  // A hard transport failure (reachable false) stays non-routable.
  assert.equal(tunnelRouteGate({ samples: [{ at: now - 1000, ok: false, reachable: false }] }, { now }).ok, false);
  // Sample carries the reachable flag and a distinct "reachable" state.
  const s = tunnelHealthSample(reachableLive(), 7);
  assert.equal(s.ok, false);
  assert.equal(s.reachable, true);
  assert.equal(s.state, "reachable");
  // Alerting: reachable samples never trip the failure alert.
  const kv = openKv(":memory:");
  try {
    let r;
    for (const t of [1, 2, 3, 4]) r = await recordTunnelHealth(kv, reachableLive(), { now: t });
    assert.equal(r.alertState, "clear", "reachable traffic is not a failure");
    assert.equal(r.consecutiveFailures, 0);
    assert.equal(r.transition, null);
  } finally {
    kv.close();
  }
});

test("unknown samples do not trip or clear a tunnel alert and history stays bounded", async () => {
  const kv = openKv(":memory:");
  try {
    for (let i = 0; i < 3; i++) await recordTunnelHealth(kv, failLive(), { now: i });
    const unknown = { up: true, state: "active", probe: { ok: null, state: "unavailable", failureClass: "unavailable", detail: "no target" } };
    const r = await recordTunnelHealth(kv, unknown, { now: 4 });
    assert.equal(r.alertState, "failed");
    assert.equal(r.consecutiveFailures, 3);
    for (let i = 5; i < 150; i++) await recordTunnelHealth(kv, unknown, { now: i });
    assert.equal((await readTunnelHealth(kv)).samples.length, TUNNEL_HEALTH_MAX_SAMPLES);
  } finally {
    kv.close();
  }
});

test("scheduled tunnel monitor emits one failure and one recovery notification/event", async () => {
  const kv = openKv(":memory:");
  await putSettings(kv, {
    host: "vpn.example.test",
    alertsEnabled: true,
    tunnel: {
      enabled: true,
      backend: "backhaul",
      role: "exit",
      transport: "tcpmux",
      tunnelPort: 2053,
      bridgeAddr: "198.51.100.8:2053",
      token: "secret-not-for-history",
      forwards: ["443"],
    },
  });
  const messages = [];
  const events = [];
  const notifyFn = async (_kv, text) => messages.push(text);
  const eventFn = async (_kv, event, data) => events.push({ event, data });
  const run = (live, now) => maybeTunnelHealth(kv, { managerOpts: { exec: false } }, {
    now,
    force: true,
    statusFn: async () => live,
    notifyFn,
    eventFn,
  });
  try {
    await run(failLive(), 1);
    await run(failLive(), 2);
    assert.equal(messages.length, 0);
    await run(failLive(), 3);
    await run(failLive(), 4);
    assert.equal(messages.length, 1);
    assert.equal(events.filter((x) => x.event === "tunnel.failed").length, 1);
    await run(passLive(), 5);
    await run(passLive(), 6);
    assert.equal(messages.length, 2);
    assert.equal(events.filter((x) => x.event === "tunnel.recovered").length, 1);
    const health = await readTunnelHealth(kv);
    assert.equal(health.lastSuccessAt, 6);
    assert.doesNotMatch(JSON.stringify(health), /secret-not-for-history/);
  } finally {
    kv.close();
  }
});
