// Per-inbound traffic: stat parsing + daily accrual into inbtraffic buckets.
import { test } from "node:test";
import assert from "node:assert/strict";

import { parseInboundStats, accrueInbound } from "../src/xray/stats.mjs";

function memKv() {
  const m = new Map();
  return {
    map: m,
    async get(k) { return m.has(k) ? m.get(k) : null; },
    async put(k, v) { m.set(k, String(v)); },
    async list({ prefix = "" } = {}) {
      return [...m.keys()].filter((k) => k.startsWith(prefix)).map((name) => ({ name }));
    },
  };
}

test("parseInboundStats groups uplink/downlink per inbound tag", () => {
  const json = {
    stat: [
      { name: "inbound>>>tuic-2443>>>traffic>>>uplink", value: "100" },
      { name: "inbound>>>tuic-2443>>>traffic>>>downlink", value: "250" },
      { name: "inbound>>>vless-front>>>traffic>>>downlink", value: "40" },
      { name: "user>>>alice>>>traffic>>>uplink", value: "9" }, // ignored (not inbound)
    ],
  };
  const out = parseInboundStats(json);
  assert.deepEqual(out["tuic-2443"], { up: 100, down: 250 });
  assert.deepEqual(out["vless-front"], { up: 0, down: 40 });
  assert.equal(out["alice"], undefined);
});

test("accrueInbound writes running total + per-day bucket per tag", async () => {
  const kv = memKv();
  const now = new Date("2026-03-04T12:00:00.000Z");
  const total = await accrueInbound(kv, { "tuic-2443": { up: 100, down: 250 }, "empty": { up: 0, down: 0 } }, { now });
  assert.equal(total, 350);
  assert.equal(await kv.get("inbtraffic:tuic-2443"), "350");
  assert.equal(await kv.get("inbtraffic-d:tuic-2443:2026-03-04"), "350");
  // Zero-delta tags are skipped entirely.
  assert.equal(await kv.get("inbtraffic:empty"), null);

  // A second poll same day adds to the same buckets.
  await accrueInbound(kv, { "tuic-2443": { up: 50, down: 0 } }, { now });
  assert.equal(await kv.get("inbtraffic:tuic-2443"), "400");
  assert.equal(await kv.get("inbtraffic-d:tuic-2443:2026-03-04"), "400");
});

test("per-day buckets separate across days and the tag has no colon", async () => {
  const kv = memKv();
  await accrueInbound(kv, { "hy2-8443": { up: 10, down: 10 } }, { now: new Date("2026-03-04T23:00:00Z") });
  await accrueInbound(kv, { "hy2-8443": { up: 5, down: 5 } }, { now: new Date("2026-03-05T01:00:00Z") });
  assert.equal(await kv.get("inbtraffic-d:hy2-8443:2026-03-04"), "20");
  assert.equal(await kv.get("inbtraffic-d:hy2-8443:2026-03-05"), "10");
  // Key layout: "inbtraffic-d:" + tag + ":" + day, tag never contains ":".
  const keys = (await kv.list({ prefix: "inbtraffic-d:" })).map((x) => x.name);
  for (const k of keys) {
    const rest = k.slice("inbtraffic-d:".length);
    assert.equal(rest.slice(0, rest.lastIndexOf(":")), "hy2-8443");
  }
});
