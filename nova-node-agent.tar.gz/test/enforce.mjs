import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { rmSync, readFileSync } from "node:fs";

import { openKv } from "../src/kv/sqlite.mjs";
import { putSettings, getSettings, enforcePolicies } from "../src/server.mjs";

function freshKv() {
  const path = join(tmpdir(), `nova-enf-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return { kv, cleanup() { kv.close(); for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} } } };
}
const uuid = "11111111-1111-4111-8111-111111111111";

test("enforcePolicies removes an over-quota user from the generated xray config", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-enf-cfg-${randomBytes(6).toString("hex")}.json`);
  try {
    await putSettings(kv, { host: "h", wsPath: "/n", subToken: "t", users: [
      { id: "me", uuid, email: "me", enabled: true, quotaBytes: 1000 },
    ] });
    await kv.put("uusage:me", "2000"); // over quota
    const r = await enforcePolicies(kv, { managerOpts: { exec: false, configPath } });
    assert.equal(r.changed, true);
    const cfg = JSON.parse(readFileSync(configPath, "utf8"));
    const front = cfg.inbounds.find((i) => i.tag === "vless-ws");
    assert.equal(front.settings.clients.length, 0, "over-quota user is not served");
  } finally {
    cleanup();
  }
});

test("enforcePolicies rolls over a daily reset cycle and zeroes usage", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-enf-cfg-${randomBytes(6).toString("hex")}.json`);
  try {
    const old = Date.now() - 2 * 86400000; // 2 days ago
    await putSettings(kv, { host: "h", wsPath: "/n", subToken: "t", users: [
      { id: "me", uuid, email: "me", enabled: true, resetStrategy: "day", lastReset: old },
    ] });
    await kv.put("uusage:me", "5000");
    await enforcePolicies(kv, { managerOpts: { exec: false, configPath } });
    assert.equal(await kv.get("uusage:me"), "0", "usage reset");
    const s = await getSettings(kv);
    assert.ok(Number(s.users[0].lastReset) > old, "lastReset advanced");
  } finally {
    cleanup();
  }
});

test("enforcePolicies sets first-use expiry once the user has traffic", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-enf-cfg-${randomBytes(6).toString("hex")}.json`);
  try {
    await putSettings(kv, { host: "h", wsPath: "/n", subToken: "t", users: [
      { id: "me", uuid, email: "me", enabled: true, expireDays: 30 },
    ] });
    // No usage yet -> no expiry set.
    await enforcePolicies(kv, { managerOpts: { exec: false, configPath } });
    assert.equal((await getSettings(kv)).users[0].expiry, undefined);
    // First traffic -> expiry stamped.
    await kv.put("uusage:me", "1");
    await enforcePolicies(kv, { managerOpts: { exec: false, configPath } });
    assert.match((await getSettings(kv)).users[0].expiry, /^\d{4}-\d{2}-\d{2}$/);
  } finally {
    cleanup();
  }
});
