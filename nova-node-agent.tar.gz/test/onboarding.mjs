import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { openKv } from "../src/kv/sqlite.mjs";
import { applyUserAction, getSettings, putSettings } from "../src/server.mjs";
import { buildSub } from "../src/subscription.mjs";

test("starter user has every enabled protocol and all-users inbound", async () => {
  const kv = openKv(":memory:");
  const workDir = mkdtempSync(join(tmpdir(), "nova-onboarding-"));
  try {
    const initial = await getSettings(kv);
    const inbounds = [{
      id: "extra-vless",
      tag: "vless-ws-extra",
      enabled: true,
      placement: "standalone",
      nodeId: "local",
      protocol: "vless",
      network: "ws",
      security: "tls",
      port: 8443,
      path: "/extra",
      sni: "node.example.com",
      allUsers: true,
      userIds: [],
    }];
    await putSettings(kv, {
      ...initial,
      host: "node.example.com",
      protocols: { vless: true, vmess: true, trojan: true, hysteria2: true },
      inbounds,
    });

    const { user } = await applyUserAction(
      kv,
      { action: "add", user: { id: "me", email: "me", enabled: true } },
      { managerOpts: { exec: false, configPath: join(workDir, "config.json") } },
    );
    assert.equal(user.inboundIds, undefined, "no allowlist means all current and future all-users inbounds");

    const body = Buffer.from(await buildSub([user], {
      host: "node.example.com",
      protocols: { vless: true, vmess: true, trojan: true, hysteria2: true },
      inbounds,
      kv,
    }), "base64").toString("utf8");
    const lines = body.split(/\r?\n/).filter(Boolean);
    assert.ok(lines.some(line => line.startsWith("vless://") && line.includes("@node.example.com:443?")));
    assert.ok(lines.some(line => line.startsWith("vmess://")));
    assert.ok(lines.some(line => line.startsWith("trojan://")));
    assert.ok(lines.some(line => line.startsWith("hysteria2://")));
    assert.ok(lines.some(line => line.startsWith("vless://") && line.includes("@node.example.com:8443?")));
  } finally {
    kv.close();
    rmSync(workDir, { recursive: true, force: true });
  }
});

test("installer seeds only a fresh standalone panel", () => {
  const installer = readFileSync(new URL("../install/nova-node.sh", import.meta.url), "utf8");
  assert.match(installer, /if \[ "\$CONFIGURED" = false \] && \[ "\$NODE_MODE" != 1 \]; then/);
  assert.ok(installer.includes('\\"id\\":\\"me\\",\\"uuid\\":\\"$UUID\\",\\"email\\":\\"me\\",\\"enabled\\":true'));
  assert.match(installer, /No inboundIds/);
  assert.match(installer, /upgrades must never recreate a user/);
});

test("dashboard exposes a translated personal subscription QR", () => {
  const panel = readFileSync(new URL("../src/web/panel.html", import.meta.url), "utf8");
  assert.equal((panel.match(/dashConnectTitle:/g) || []).length, 3, "EN, FA and RU titles");
  assert.equal((panel.match(/dashConnectDesc:/g) || []).length, 3, "EN, FA and RU descriptions");
  assert.match(panel, /data-testid="dash-quick-connect"/);
  assert.match(panel, /data-testid="dash-connect-qr"/);
  assert.match(panel, /api\("\/admin\/user-links\?id="/);
  assert.match(panel, /function dashConnectUser\(\)/);
  assert.match(panel, /u\.id === "me" \|\| u\.email === "me"/);
  assert.match(panel, /\.dash-connect \{\s*margin: 0 0 14px;/);
});
