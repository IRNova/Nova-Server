import test from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:https";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { once } from "node:events";
import { probeTunnelDataPath, tunnelPreflight, tunnelProbeTarget } from "../src/tunnels/manager.mjs";

function selfSignedServer(handler) {
  const dir = mkdtempSync(join(tmpdir(), "nova-tunnel-probe-"));
  const key = join(dir, "key.pem");
  const cert = join(dir, "cert.pem");
  execFileSync("openssl", [
    "req", "-x509", "-newkey", "rsa:2048", "-nodes",
    "-keyout", key, "-out", cert, "-days", "1", "-subj", "/CN=nova.test",
  ], { stdio: "ignore" });
  const server = createServer({ key: readFileSync(key), cert: readFileSync(cert) }, handler);
  return { server, dir };
}

function exitTunnel(port) {
  return {
    enabled: true,
    role: "exit",
    bridgeAddr: "127.0.0.1:2053",
    forwards: [`${port}=127.0.0.1:443`],
  };
}

test("tunnelProbeTarget selects the bridge listener that maps to local HTTPS", () => {
  assert.deepEqual(
    tunnelProbeTarget({
      role: "exit",
      bridgeAddr: "198.51.100.4:2053",
      forwards: ["8443/udp", "9443=127.0.0.1:443", "8080=127.0.0.1:80"],
    }, { host: "vpn.example.test:443" }),
    { address: "198.51.100.4", port: 9443, host: "vpn.example.test", servername: "vpn.example.test" },
  );
  assert.equal(tunnelProbeTarget({ role: "bridge", bridgeAddr: "198.51.100.4:2053", forwards: ["443"] }), null);
  assert.equal(tunnelProbeTarget({ role: "exit", bridgeAddr: "bad", forwards: ["443"] }), null);
});

test("payload probe verifies HTTP 200 and the Nova build marker through the bridge listener", async () => {
  const { server, dir } = selfSignedServer((req, res) => {
    assert.equal(req.url, "/install/status");
    assert.equal(req.headers.host, "vpn.example.test");
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ configured: true, build: "nova-node-agent/1.12.0" }));
  });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  try {
    const result = await probeTunnelDataPath(exitTunnel(server.address().port), {
      host: "vpn.example.test",
      timeoutMs: 1_000,
    });
    assert.equal(result.ok, true);
    assert.equal(result.state, "pass");
    assert.equal(result.httpStatus, 200);
    assert.match(result.detail, /nova-node-agent\/1\.12\.0/);
    assert.ok(Number.isInteger(result.latencyMs) && result.latencyMs >= 0);
  } finally {
    server.close();
    await once(server, "close");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("payload probe marks a non-Nova response as reachable (data path alive)", async () => {
  const { server, dir } = selfSignedServer((_req, res) => {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ ok: true }));
  });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  try {
    const result = await probeTunnelDataPath(exitTunnel(server.address().port), {
      host: "vpn.example.test",
      timeoutMs: 1_000,
    });
    // Bytes reached the exit and a response came back: the tunnel carries traffic.
    // We just cannot confirm the Nova build (front proxy), so it is reachable-unverified.
    assert.equal(result.ok, false);
    assert.equal(result.reachable, true);
    assert.equal(result.state, "reachable");
    assert.equal(result.failureClass, "unverified");
    assert.equal(result.httpStatus, 200);
    assert.match(result.detail, /forwards traffic|does not expose/);
  } finally {
    server.close();
    await once(server, "close");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("candidate preflight is read-only and reports binary/control readiness", async () => {
  const candidate = {
    backend: "backhaul",
    role: "exit",
    transport: "tcpmux",
    tunnelPort: 2053,
    bridgeAddr: "198.51.100.4:2053",
    token: "supersecret",
    forwards: ["443"],
  };
  let connected = null;
  const result = await tunnelPreflight(candidate, {
    availableFn: async (backend) => backend === "backhaul",
    connectFn: async (endpoint) => {
      connected = endpoint;
      return { ok: true, state: "pass", latencyMs: 15, detail: "control port accepted TCP" };
    },
  });
  assert.equal(result.ok, true);
  assert.equal(result.valid, true);
  assert.equal(result.applied, false);
  assert.equal(result.disruptive, false);
  assert.deepEqual(connected, { host: "198.51.100.4", port: 2053 });
  assert.deepEqual(result.artifact, { kind: "file", exec: "backhaul" });
  assert.ok(!JSON.stringify(result).includes("supersecret"), "preflight response never leaks the token");
});

test("candidate preflight rejects invalid specs before checking the host", async () => {
  let called = false;
  const result = await tunnelPreflight({ backend: "backhaul", role: "exit" }, {
    availableFn: async () => { called = true; return true; },
  });
  assert.equal(result.ok, false);
  assert.equal(result.valid, false);
  assert.equal(result.applied, false);
  assert.equal(called, false);
});
