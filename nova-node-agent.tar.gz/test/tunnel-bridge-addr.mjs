import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSub } from "../src/subscription.mjs";
import { validateTunnel } from "../src/tunnels/config.mjs";

const decode = (b) => Buffer.from(b, "base64").toString("utf8");
const user = (e) => ({ id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "u1", enabled: true, ...e });

test("tunnelAddr overrides the front link ADDRESS but keeps SNI/host = domain", async () => {
  const sub = decode(await buildSub([user({})], { host: "exit.example.com", tunnelAddr: "85.9.106.104", protocols: { vless: true } }));
  assert.match(sub, /@85\.9\.106\.104:443/);      // socket lands on the bridge
  assert.match(sub, /sni=exit\.example\.com/);     // TLS SNI stays the domain
  assert.match(sub, /host=exit\.example\.com/);    // ws host stays the domain
  assert.doesNotMatch(sub, /@exit\.example\.com:443/);
});

test("no tunnelAddr => front link address is the host (unchanged behavior)", async () => {
  const sub = decode(await buildSub([user({})], { host: "exit.example.com", protocols: { vless: true } }));
  assert.match(sub, /@exit\.example\.com:443/);
  assert.doesNotMatch(sub, /85\.9\.106\.104/);
});

test("clearing tunnelAddr (empty string) reverts to host", async () => {
  const sub = decode(await buildSub([user({})], { host: "exit.example.com", tunnelAddr: "", protocols: { vless: true } }));
  assert.match(sub, /@exit\.example\.com:443/);
});

const sInb = (extra) => ({ id: "s1", tag: "s1", protocol: "vless", placement: "standalone", network: "ws", security: "tls", port: 8443, path: "/x", enabled: true, ...extra });

test("local standalone inbound fronts through the tunnel (addr=bridge, sni=exit host)", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", tunnelAddr: "1.2.3.4", inbounds: [sInb()], protocols: {},
  }));
  const line = sub.split("\n").find((l) => l.startsWith("vless://") && l.includes(":8443"));
  assert.ok(line, "standalone line present");
  assert.match(line, /@1\.2\.3\.4:8443/);          // dials the Iran bridge
  assert.match(line, /sni=exit\.example\.com/);     // SNI stays the exit (cert validates)
});

test("node inbound is NOT tunneled (keeps its node address)", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", tunnelAddr: "1.2.3.4",
    inbounds: [sInb({ nodeId: "nd1" })], nodes: [{ id: "nd1", name: "DE", address: "9.9.9.9" }], protocols: {},
  }));
  const line = sub.split("\n").find((l) => l.startsWith("vless://") && l.includes(":8443"));
  assert.ok(line);
  assert.match(line, /@9\.9\.9\.9:8443/);
  assert.doesNotMatch(line, /1\.2\.3\.4/);          // node is a separate server, never tunneled
});

test("no tunnel: local standalone uses the exit host (unchanged behavior)", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", inbounds: [sInb()], protocols: {},
  }));
  const line = sub.split("\n").find((l) => l.startsWith("vless://") && l.includes(":8443"));
  assert.match(line, /@exit\.example\.com:8443/);
});

test("geo-exit configs route through the tunnel bridge too (not just base front)", async () => {
  const sub = decode(await buildSub([user({ geoExits: true })], {
    host: "exit.example.com", tunnelAddr: "1.2.3.4", protocols: { vless: true },
    geoExits: [{ service: "tor", country: "us", enabled: true }],
  }));
  const geoLine = sub.split("\n").find((l) => l.includes("nova-geo"));
  assert.ok(geoLine, "geo line present");
  assert.match(geoLine, /@1\.2\.3\.4:443/);        // connects via the bridge
  assert.match(geoLine, /sni=exit\.example\.com/);  // SNI stays the domain
});

test("disabling the tunnel (empty tunnelAddr) reverts EVERY front config to the host", async () => {
  const opts = {
    host: "exit.example.com", protocols: { vless: true, trojan: true },
    geoExits: [{ service: "tor", country: "us", enabled: true }],
  };
  const on = decode(await buildSub([user({ geoExits: true })], { ...opts, tunnelAddr: "1.2.3.4" }));
  assert.ok(on.includes("@1.2.3.4:"), "with tunnel on, configs point at the bridge");
  const off = decode(await buildSub([user({ geoExits: true })], { ...opts, tunnelAddr: "" }));
  assert.doesNotMatch(off, /1\.2\.3\.4/);           // NOTHING left at the bridge
  assert.match(off, /@exit\.example\.com:443/);      // all reverted to the domain
});

test("tunnelPorts gates rerouting: front (443) tunneled, standalone (8443) not forwarded stays put", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["front:vless", "s1"] })], {
    host: "exit.example.com", tunnelAddr: "1.2.3.4", tunnelPorts: [443],
    inbounds: [sInb()], protocols: { vless: true },
  }));
  const front = sub.split("\n").find((l) => l.startsWith("vless://") && l.includes(":443"));
  const inbLine = sub.split("\n").find((l) => l.startsWith("vless://") && l.includes(":8443"));
  assert.match(front, /@1\.2\.3\.4:443/);          // 443 is forwarded -> bridge
  assert.match(inbLine, /@exit\.example\.com:8443/); // 8443 not in forwards -> real host
});

test("tunnelPorts includes the standalone port => that inbound reroutes to the bridge", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", tunnelAddr: "1.2.3.4", tunnelPorts: [443, 8443],
    inbounds: [sInb()], protocols: {},
  }));
  const inbLine = sub.split("\n").find((l) => l.startsWith("vless://") && l.includes(":8443"));
  assert.match(inbLine, /@1\.2\.3\.4:8443/);        // 8443 forwarded -> bridge
  assert.match(inbLine, /sni=exit\.example\.com/);   // SNI still the exit host
});

test("validateTunnel rejects a token with unsafe characters (config injection)", () => {
  // The token is written verbatim into token = "..." in the backhaul TOML.
  for (const bad of ['ab"cd1234', "tok\nen123", "tok en1234", "a\\b12345"]) {
    assert.equal(validateTunnel({ backend: "backhaul", role: "bridge", tunnelPort: 2053, token: bad, forwards: ["443"] }).ok, false, `should reject ${JSON.stringify(bad)}`);
  }
  assert.equal(validateTunnel({ backend: "backhaul", role: "bridge", tunnelPort: 2053, token: "ef9dc585aac54304", forwards: ["443"] }).ok, true);
});

test("validateTunnel rejects a forward target with unsafe characters", () => {
  const r = validateTunnel({ backend: "backhaul", role: "bridge", tunnelPort: 2053, token: "goodtoken1", forwards: ['443=127.0.0.1:443",evil'] });
  assert.equal(r.ok, false);
});

test("validateTunnel rejects a tunnel port that collides with a TCP forward (443)", () => {
  const r = validateTunnel({ backend: "backhaul", role: "bridge", tunnelPort: 443, token: "12345678", forwards: ["443", "8443/udp"] });
  assert.equal(r.ok, false);
});

test("validateTunnel rejects a tunnel port matching a UDP forward too (8443 vs 8443/udp)", () => {
  // backhaul opens a TCP listener for every forward number, so 8443 control
  // collides with the 8443/udp forward. This is the exact bridge failure.
  const r = validateTunnel({ backend: "backhaul", role: "bridge", tunnelPort: 8443, token: "12345678", forwards: ["443", "8443/udp"] });
  assert.equal(r.ok, false);
});

test("validateTunnel allows a third port not in the forwards (2053)", () => {
  const r = validateTunnel({ backend: "backhaul", role: "bridge", tunnelPort: 2053, token: "12345678", forwards: ["443", "8443/udp"] });
  assert.equal(r.ok, true);
});

test("validateTunnel rejects a bridgeAddr carrying URL metacharacters", () => {
  // bridgeAddr may later be published into tunnelAddr after a payload-health
  // gate, so a "?sni=evil#" host must never pass validation.
  for (const bad of ["a?sni=evil#x:443", "1.2.3.4/x:443", "u@h:443", "a b:443"]) {
    const r = validateTunnel({ backend: "backhaul", role: "exit", tunnelPort: 2053, token: "12345678", bridgeAddr: bad, forwards: ["443"] });
    assert.equal(r.ok, false, `should reject ${bad}`);
  }
});

test("validateTunnel accepts a clean bridgeAddr (IPv4 / hostname:port)", () => {
  // The Iran bridge is an IPv4 VPS or a hostname; the guard mirrors the host-only
  // tunnelAddr charset, so bracketed IPv6 is intentionally out of scope here.
  for (const good of ["1.2.3.4:443", "bridge.example.com:2053"]) {
    const r = validateTunnel({ backend: "backhaul", role: "exit", tunnelPort: 2053, token: "12345678", bridgeAddr: good, forwards: ["443"] });
    assert.equal(r.ok, true, `should accept ${good}`);
  }
});
