import { test } from "node:test";
import assert from "node:assert/strict";

import { buildSub, inboundLine } from "../src/subscription.mjs";
import { normalizeInbound, userCredential, VISION_FLOW, SS_METHOD } from "../src/xray/inbounds.mjs";

const realityKeys = {
  privateKey: "EJwRvzyxpkJXSUOphvklb4zcrSiiX7_dz5SXSO4VpEI",
  publicKey: "gMek7p-asiIMUGsUbripC7kMahsAl-41J7fHjwnOLRQ",
};
const U = { id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "a", enabled: true };

function realityVision() {
  return normalizeInbound({
    id: "rv", tag: "rv", protocol: "vless", network: "tcp", security: "reality", port: 8443,
    flow: VISION_FLOW, remark: "Reality",
    reality: { dest: "www.microsoft.com:443", serverNames: ["www.microsoft.com"], shortIds: ["0123abcd"], ...realityKeys },
  });
}

test("inboundLine: reality-vision carries pbk, sid, fp, spx, flow and the borrowed sni", () => {
  const link = inboundLine(U, realityVision(), { host: "203.0.113.9" });
  assert.ok(link.startsWith(`vless://${U.uuid}@203.0.113.9:8443?`));
  const q = new URL(link).searchParams;
  assert.equal(q.get("security"), "reality");
  assert.equal(q.get("sni"), "www.microsoft.com");
  assert.equal(q.get("pbk"), realityKeys.publicKey);
  assert.equal(q.get("sid"), "0123abcd");
  assert.equal(q.get("fp"), "chrome");
  assert.equal(q.get("spx"), "/");
  assert.equal(q.get("flow"), VISION_FLOW);
  assert.equal(q.get("type"), "tcp");
});

test("inboundLine: grpc-tls and xhttp-tls carry their transport params", () => {
  const grpc = normalizeInbound({ protocol: "vless", network: "grpc", security: "tls", sni: "g.example", port: 2053, serviceName: "novagrpc" });
  const gq = new URL(inboundLine(U, grpc, { host: "g.example" })).searchParams;
  assert.equal(gq.get("serviceName"), "novagrpc");
  assert.equal(gq.get("security"), "tls");
  assert.equal(gq.get("sni"), "g.example");

  const xh = normalizeInbound({ protocol: "vless", network: "xhttp", security: "tls", sni: "x.example", port: 2096, path: "/dl", xhttpMode: "packet-up" });
  const xq = new URL(inboundLine(U, xh, { host: "x.example" })).searchParams;
  assert.equal(xq.get("type"), "xhttp");
  assert.equal(xq.get("path"), "/dl");
  assert.equal(xq.get("mode"), "packet-up");
});

test("inboundLine: shadowsocks-2022 encodes method:serverPSK:userPSK", () => {
  const inb = normalizeInbound({ protocol: "shadowsocks", network: "tcp", security: "none", port: 9000, ssPassword: "SERVERKEY==" });
  const link = inboundLine(U, inb, { host: "203.0.113.9" });
  assert.ok(link.startsWith("ss://"));
  const userinfo = link.slice("ss://".length, link.indexOf("@"));
  const decoded = Buffer.from(userinfo.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
  const [method, serverPsk, userPsk] = decoded.split(":");
  assert.equal(method, SS_METHOD);
  assert.equal(serverPsk, "SERVERKEY==");
  assert.equal(userPsk, userCredential(inb, U));
});

test("buildSub emits the front link plus one link per assigned standalone inbound", async () => {
  const b64 = await buildSub([U], {
    host: "cf.example.com",
    directHost: "203.0.113.9",
    protocols: { vless: true },
    inbounds: [realityVision()],
  });
  const body = Buffer.from(b64, "base64").toString("utf8");
  const lines = body.split("\n").filter(Boolean);
  assert.equal(lines.length, 2); // front vless + reality
  assert.ok(lines.some((l) => l.includes("cf.example.com:443"))); // front via CF host
  assert.ok(lines.some((l) => l.includes("203.0.113.9:8443") && l.includes("security=reality"))); // reality via direct host
});

test("buildSub omits inbound links for a disabled/unassigned user", async () => {
  const inb = normalizeInbound({ ...realityVision(), allUsers: false, userIds: ["someone-else"] });
  const b64 = await buildSub([U], { host: "h", directHost: "203.0.113.9", protocols: { vless: true }, inbounds: [inb] });
  const body = Buffer.from(b64, "base64").toString("utf8");
  assert.equal(body.split("\n").filter(Boolean).length, 1); // only the front link
});
