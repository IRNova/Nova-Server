// Login guard + webhooks + inbound-traffic, exercised through the real
// node:http server: config round-trips, an actual ban after repeated bad
// logins, and a live webhook delivery to a local capture server.
import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { rmSync } from "node:fs";
import { createServer as httpCreateServer } from "node:http";

import { openKv } from "../src/kv/sqlite.mjs";
import { createServer } from "../src/server.mjs";

const UA = "Nova/1.0.0 (desktop)";

function startServer(kv, opts) {
  const server = createServer(kv, opts);
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      resolve({ base: `http://127.0.0.1:${port}`, close: () => new Promise((r) => server.close(r)) });
    });
  });
}
function freshKv() {
  const path = join(tmpdir(), `nova-sec-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return { kv, cleanup() { kv.close(); for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} } } };
}
function cookieValue(res) {
  const m = /(?:^|,\s*)auth=([^;]+)/.exec(res.headers.get("set-cookie") || "");
  return m ? m[1] : null;
}
async function setup(srv) {
  const res = await fetch(srv.base + "/install/set", {
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": UA },
    body: JSON.stringify({ password: "hunter2secret" }),
  });
  const cookie = cookieValue(res);
  return { cookie: `auth=${cookie}`, "user-agent": UA, "content-type": "application/json" };
}
// A throwaway HTTP server that records the bodies POSTed to it (webhook target).
function captureServer() {
  const hits = [];
  const server = httpCreateServer((req, res) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      hits.push({ headers: req.headers, body });
      res.writeHead(200, { "content-type": "application/json" });
      res.end('{"ok":true}');
    });
  });
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      resolve({ url: `http://127.0.0.1:${server.address().port}/hook`, hits, close: () => new Promise((r) => server.close(r)) });
    });
  });
}

test("login-guard: config round-trip + a real ban after repeated bad logins", async () => {
  const { kv, cleanup } = freshKv();
  const srv = await startServer(kv);
  try {
    const auth = await setup(srv);

    // Defaults on a fresh install.
    let r = await fetch(srv.base + "/admin/login-guard", { headers: auth });
    let j = await r.json();
    assert.equal(j.config.enabled, true);
    assert.equal(j.config.maxFails, 5);
    assert.deepEqual(j.bans, []);

    // Tighten it so the test trips fast.
    r = await fetch(srv.base + "/admin/login-guard", {
      method: "POST", headers: auth, body: JSON.stringify({ action: "config", maxFails: 2, windowMin: 10, banMin: 30 }),
    });
    j = await r.json();
    assert.equal(j.config.maxFails, 2);

    // Two wrong passwords, then the IP is banned outright (even a correct one 429s).
    const bad = () => fetch(srv.base + "/login", {
      method: "POST", headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ password: "wrong" }),
    });
    assert.equal((await bad()).status, 401);
    assert.equal((await bad()).status, 401); // this one trips the ban
    const now = await fetch(srv.base + "/login", {
      method: "POST", headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ password: "hunter2secret" }), // correct, but banned
    });
    assert.equal(now.status, 429);

    // The ban shows up, and can be lifted.
    r = await fetch(srv.base + "/admin/login-guard", { headers: auth });
    j = await r.json();
    assert.equal(j.bans.length, 1);
    const ip = j.bans[0].ip;
    r = await fetch(srv.base + "/admin/login-guard", {
      method: "POST", headers: auth, body: JSON.stringify({ action: "unban", ip }),
    });
    j = await r.json();
    assert.deepEqual(j.bans, []);
  } finally {
    await srv.close();
    cleanup();
  }
});

test("webhooks: add, list, and a live signed delivery via test ping", async () => {
  const { kv, cleanup } = freshKv();
  const srv = await startServer(kv);
  const cap = await captureServer();
  try {
    const auth = await setup(srv);

    // Empty to start; events catalog is advertised.
    let r = await fetch(srv.base + "/admin/webhooks", { headers: auth });
    let j = await r.json();
    assert.deepEqual(j.webhooks, []);
    assert.ok(j.events.includes("user.created"));

    // Add one pointing at the capture server.
    r = await fetch(srv.base + "/admin/webhooks", {
      method: "POST", headers: auth,
      body: JSON.stringify({ action: "add", webhook: { url: cap.url, secret: "topsecret", events: ["user.created"] } }),
    });
    j = await r.json();
    assert.equal(j.webhooks.length, 1);
    const id = j.webhooks[0].id;

    // Fire a test ping and confirm the capture server actually received it.
    r = await fetch(srv.base + "/admin/webhooks", {
      method: "POST", headers: auth, body: JSON.stringify({ action: "test", id }),
    });
    j = await r.json();
    assert.equal(j.ok, true);
    assert.equal(j.status, 200);
    assert.equal(cap.hits.length, 1);
    const hit = cap.hits[0];
    assert.equal(hit.headers["x-nova-event"], "test");
    assert.ok(hit.headers["x-nova-signature"].startsWith("sha256="));
    const payload = JSON.parse(hit.body);
    assert.equal(payload.event, "test");
    assert.deepEqual(payload.data, { message: "Nova webhook test" });

    // Delete it.
    r = await fetch(srv.base + "/admin/webhooks", {
      method: "POST", headers: auth, body: JSON.stringify({ action: "delete", id }),
    });
    j = await r.json();
    assert.deepEqual(j.webhooks, []);
  } finally {
    await cap.close();
    await srv.close();
    cleanup();
  }
});

test("inbound-traffic: empty until data, then reflects accrued buckets", async () => {
  const { kv, cleanup } = freshKv();
  const srv = await startServer(kv);
  try {
    const auth = await setup(srv);
    let r = await fetch(srv.base + "/admin/inbound-traffic?days=7", { headers: auth });
    let j = await r.json();
    assert.equal(j.dates.length, 7);
    assert.deepEqual(j.inbounds, []);

    // Seed a bucket for today the way the poll loop would, then read it back.
    const today = new Date().toISOString().slice(0, 10);
    await kv.put("inbtraffic:tuic-2443", "500");
    await kv.put(`inbtraffic-d:tuic-2443:${today}`, "500");
    r = await fetch(srv.base + "/admin/inbound-traffic?days=7", { headers: auth });
    j = await r.json();
    assert.equal(j.inbounds.length, 1);
    assert.equal(j.inbounds[0].tag, "tuic-2443");
    assert.equal(j.inbounds[0].total, 500);
    assert.equal(j.inbounds[0].series[j.inbounds[0].series.length - 1], 500); // today is last
  } finally {
    await srv.close();
    cleanup();
  }
});

test("owner-only: these routes are refused for a reseller session", async () => {
  const { kv, cleanup } = freshKv();
  const srv = await startServer(kv);
  try {
    const auth = await setup(srv);
    // Create a reseller admin, then sign in as them.
    let r = await fetch(srv.base + "/admin/admins", {
      method: "POST", headers: auth,
      body: JSON.stringify({ action: "add", name: "seller", password: "resellerpass1", role: "reseller" }),
    });
    assert.ok(r.ok, `create reseller failed: ${r.status}`);
    r = await fetch(srv.base + "/login", {
      method: "POST", headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ password: "resellerpass1" }),
    });
    const rc = cookieValue(r);
    const rAuth = { cookie: `auth=${rc}`, "user-agent": UA, "content-type": "application/json" };
    for (const p of ["/admin/login-guard", "/admin/webhooks", "/admin/inbound-traffic"]) {
      const resp = await fetch(srv.base + p, { headers: rAuth });
      assert.equal(resp.status, 403, `${p} should be owner-only`);
    }
  } finally {
    await srv.close();
    cleanup();
  }
});
