// Respond-before-restart: a panel user action (Enable/Disable/Extend/Reset) is
// served through xray :443, so restarting xray synchronously drops the request's
// own connection before the response is delivered ("Could not access the node"
// even though the change applied). With deferRestart the restart is scheduled a
// moment later, after the response flushes, instead of run inline.
import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { applyUsers } from "../src/xray/manager.mjs";

const tmpConfig = () => join(tmpdir(), `nova-defer-${randomBytes(6).toString("hex")}.json`);
const USERS = [{ id: "u1", uuid: "66666666-6666-4666-8666-666666666666", email: "a", enabled: true }];

test("deferRestart returns restart-deferred and does NOT restart xray inline", async () => {
  // NOVA_NO_EXEC keeps the deferred restart from spawning a real systemctl shell
  // in the test; exec:true is passed explicitly so applyUsers still reaches the
  // restart branch (the code path we are exercising).
  process.env.NOVA_NO_EXEC = "1";
  try {
    const calls = [];
    const res = await applyUsers(USERS, {
      exec: true,
      prev: USERS,
      forceReload: true, // config-only change -> restart path
      deferRestart: true,
      runExec: async (bin, args) => { calls.push({ bin, args: (args || []).join(" ") }); return { stdout: "" }; },
      configPath: tmpConfig(),
    });
    assert.equal(res.method, "restart-deferred");
    // The restart is deferred to a detached shell, so it must NOT go through the
    // synchronous runExec restart path.
    assert.ok(!calls.some((c) => c.bin === "systemctl" && c.args === "restart xray"),
      "deferRestart must not restart xray inline");
  } finally {
    delete process.env.NOVA_NO_EXEC;
  }
});

test("without deferRestart the same change restarts xray inline (unchanged behavior)", async () => {
  const calls = [];
  const res = await applyUsers(USERS, {
    exec: true,
    prev: USERS,
    forceReload: true,
    runExec: async (bin, args) => { calls.push({ bin, args: (args || []).join(" ") }); return { stdout: "" }; },
    configPath: tmpConfig(),
  });
  assert.equal(res.method, "restart");
  assert.ok(calls.some((c) => c.bin === "systemctl" && c.args === "restart xray"),
    "the default path still restarts inline");
});
