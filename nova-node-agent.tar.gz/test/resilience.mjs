import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSub } from "../src/subscription.mjs";

const decode = (b) => Buffer.from(b, "base64").toString("utf8");
const user = (e) => ({ id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "u1", enabled: true, ...e });
const sInb = (extra) => ({ id: "s1", tag: "s1", protocol: "vless", placement: "standalone", network: "ws", security: "tls", port: 8443, path: "/x", enabled: true, ...extra });
const NODES = [{ id: "nd1", name: "DE", address: "1.2.3.4" }, { id: "nd2", name: "NL", address: "5.6.7.8" }];
const addrs = (sub) => sub.split("\n").filter((l) => l.startsWith("vless://") && l.includes(":8443")).map((l) => (l.match(/@([^:]+):8443/) || [])[1]).sort();

test("resilience OFF: a local inbound stays on the main host only (unchanged)", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", inbounds: [sInb()], nodes: NODES, protocols: {},
  }));
  assert.deepEqual(addrs(sub), ["exit.example.com"]);
});

test("resilience ON: a local inbound is emitted on the main server AND every node", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", inbounds: [sInb()], nodes: NODES, resilience: true, protocols: {},
  }));
  assert.deepEqual(addrs(sub), ["1.2.3.4", "5.6.7.8", "exit.example.com"]);
});

test("resilience ON stacks with the bridge fan-out for front links", async () => {
  const sub = decode(await buildSub([user({})], {
    host: "exit.example.com", tunnelAddrs: ["10.0.0.1", "10.0.0.2"], tunnelAddr: "10.0.0.1",
    nodes: NODES, resilience: true, protocols: { vless: true },
  }));
  // Front link mirrored once per bridge IP (failover across bridges).
  assert.ok(sub.includes("@10.0.0.1:443") && sub.includes("@10.0.0.2:443"));
});

test("resilience ON: a pubAddr inbound stays pinned to its domain, not fanned to nodes", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", inbounds: [sInb({ pubAddr: "sub1.example.com" })], nodes: NODES, resilience: true, protocols: {},
  }));
  assert.deepEqual(addrs(sub), ["sub1.example.com"]);   // one config, its own domain
});

test("resilience ON with no nodes behaves like a single-server sub", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["s1"] })], {
    host: "exit.example.com", inbounds: [sInb()], nodes: [], resilience: true, protocols: {},
  }));
  assert.deepEqual(addrs(sub), ["exit.example.com"]);
});
