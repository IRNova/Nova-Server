import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSub } from "../src/subscription.mjs";
import { generateXrayConfig } from "../src/xray/config.mjs";
import { certCoversDomain } from "../src/cert.mjs";
import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const decode = (b) => Buffer.from(b, "base64").toString("utf8");
const user = (e) => ({ id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "u1", enabled: true, ...e });
const lineFor = (sub, needle) => sub.split("\n").find((l) => l.startsWith("vless://") && l.includes(needle));

test("certCoversDomain: exact, wildcard one-level, and rejections (real cert)", () => {
  const dir = mkdtempSync(join(tmpdir(), "nova-cert-"));
  try {
    execFileSync("openssl", ["req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", join(dir, "k"),
      "-out", join(dir, "c"), "-days", "1", "-subj", "/CN=a.com", "-addext", "subjectAltName=DNS:a.com,DNS:*.a.com"],
      { stdio: "ignore" });
    const pem = readFileSync(join(dir, "c"), "utf8");
    assert.equal(certCoversDomain(pem, "a.com"), true);
    assert.equal(certCoversDomain(pem, "x.a.com"), true);
    assert.equal(certCoversDomain(pem, "b.com"), false);
    assert.equal(certCoversDomain(pem, "y.x.a.com"), false); // wildcard is one level
    assert.equal(certCoversDomain("not a cert", "a.com"), false);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test("a cert-domain bridge presents its own SNI; a bare-IP bridge keeps the exit SNI", async () => {
  const sub = decode(await buildSub([user({})], {
    host: "exit.example.com",
    tunnelAddr: "br1.example.com",
    tunnelAddrs: ["br1.example.com", "br2.example.com", "198.51.100.9"],
    certDomains: ["br1.example.com", "br2.example.com"],
    protocols: { vless: true },
  }));
  const l1 = lineFor(sub, "@br1.example.com:443");
  const l2 = lineFor(sub, "@br2.example.com:443");
  const l3 = lineFor(sub, "@198.51.100.9:443");
  assert.ok(l1 && l2 && l3, "all three bridges present");
  assert.match(l1, /sni=br1\.example\.com/);          // primary cert-domain -> own SNI
  assert.match(l2, /sni=br2\.example\.com/);          // extra cert-domain -> own SNI
  assert.match(l3, /sni=exit\.example\.com/);          // bare IP -> exit SNI (cert validates through it)
});

test("no certDomains => bridges keep the exit SNI (unchanged behavior)", async () => {
  const sub = decode(await buildSub([user({})], {
    host: "exit.example.com",
    tunnelAddr: "br1.example.com",
    tunnelAddrs: ["br1.example.com", "br2.example.com"],
    protocols: { vless: true },
  }));
  const l1 = lineFor(sub, "@br1.example.com:443");
  const l2 = lineFor(sub, "@br2.example.com:443");
  assert.match(l1, /sni=exit\.example\.com/);
  assert.match(l2, /sni=exit\.example\.com/);
});

test("xray front serves the primary cert plus each extra bridge cert (SNI selection)", () => {
  const cfg = generateXrayConfig([user({})], {
    port: 443,
    extraCerts: [
      { domain: "br1.example.com", certPem: "/etc/nova/certs/br1.example.com.pem", keyPem: "/etc/nova/certs/br1.example.com.key" },
      { domain: "br2.example.com", certPem: "/etc/nova/certs/br2.example.com.pem", keyPem: "/etc/nova/certs/br2.example.com.key" },
    ],
  });
  const front = cfg.inbounds.find((i) => i.port === 443 && i.streamSettings && i.streamSettings.security === "tls");
  assert.ok(front, "tls front present");
  const files = front.streamSettings.tlsSettings.certificates.map((c) => c.certificateFile);
  assert.deepEqual(files, ["/etc/nova/origin.pem", "/etc/nova/certs/br1.example.com.pem", "/etc/nova/certs/br2.example.com.pem"]);
});

test("no extraCerts => xray front has just the primary cert (unchanged)", () => {
  const cfg = generateXrayConfig([user({})], { port: 443 });
  const front = cfg.inbounds.find((i) => i.port === 443 && i.streamSettings && i.streamSettings.security === "tls");
  assert.deepEqual(front.streamSettings.tlsSettings.certificates, [{ certificateFile: "/etc/nova/origin.pem", keyFile: "/etc/nova/origin.key" }]);
});
