// Unit tests for the full-tunnel exit bridge (src/tunnel.mjs).
//
// Drives a real loopback TCP echo server through the JSON op protocol, so the
// connect -> data -> drain -> close path and the SSRF guard are both exercised
// without any external network. The loopback target is only reachable because
// NOVA_TUNNEL_ALLOW_LOCAL=1 is set here (production blocks loopback).

process.env.NOVA_TUNNEL_ALLOW_LOCAL = "1";

import test from "node:test";
import assert from "node:assert/strict";
import net from "node:net";
import { once } from "node:events";
import {
  tunnelOp,
  isPublicTunnelHost,
  tunnelSessionCount,
  closeAllTunnelSessions,
} from "../src/tunnel.mjs";

const b64 = (s) => Buffer.from(s).toString("base64");
const unb64 = (s) => Buffer.from(s || "", "base64");

// A loopback echo server: whatever it receives it writes straight back.
async function echoServer() {
  const srv = net.createServer((sock) => sock.pipe(sock));
  srv.listen(0, "127.0.0.1");
  await once(srv, "listening");
  return { srv, port: srv.address().port };
}

test("SSRF guard blocks private and allows public", () => {
  // Loopback is allowed ONLY because the escape hatch is set for this test.
  assert.equal(isPublicTunnelHost("8.8.8.8"), true);
  assert.equal(isPublicTunnelHost("1.1.1.1"), true);
  assert.equal(isPublicTunnelHost("10.0.0.5"), false);
  assert.equal(isPublicTunnelHost("192.168.1.1"), false);
  assert.equal(isPublicTunnelHost("172.16.9.9"), false);
  assert.equal(isPublicTunnelHost("169.254.1.1"), false);
  assert.equal(isPublicTunnelHost("100.100.0.1"), false); // CGNAT
});

test("connect -> data echo -> close", async () => {
  const { srv, port } = await echoServer();
  try {
    const c = await tunnelOp({ op: "connect", h: "127.0.0.1", p: port });
    assert.ok(c.id, `connect returned id: ${JSON.stringify(c)}`);

    // Write "hello", expect it echoed back on the same or a following drain.
    let r = await tunnelOp({ op: "data", id: c.id, d: b64("hello") });
    let got = unb64(r.d);
    if (got.length === 0) {
      r = await tunnelOp({ op: "data", id: c.id });
      got = unb64(r.d);
    }
    assert.equal(got.toString(), "hello");

    const closed = await tunnelOp({ op: "close", id: c.id });
    assert.equal(closed.ok, true);
    // A data op after close is a no-session error.
    const after = await tunnelOp({ op: "data", id: c.id });
    assert.equal(after.e, "no session");
  } finally {
    srv.close();
    closeAllTunnelSessions();
  }
});

test("connect refuses a private target via tunnelOp", async () => {
  // The escape hatch only whitelists loopback; 10.x must still be refused.
  const r = await tunnelOp({ op: "connect", h: "10.1.2.3", p: 80 });
  assert.equal(r.e, "target not allowed");
});

test("bad op and bad target", async () => {
  assert.equal((await tunnelOp({ op: "nope" })).e, "unknown op");
  assert.equal((await tunnelOp({ op: "connect", h: "8.8.8.8", p: 0 })).e, "bad target");
  assert.equal((await tunnelOp({ op: "connect", p: 80 })).e, "bad target");
});

test("batch runs ops in order", async () => {
  const { srv, port } = await echoServer();
  try {
    const r = await tunnelOp({
      op: "batch",
      ops: [
        { op: "connect", h: "127.0.0.1", p: port },
        { op: "nope" },
      ],
    });
    assert.ok(Array.isArray(r.r));
    assert.ok(r.r[0].id);
    assert.equal(r.r[1].e, "unknown op");
    await tunnelOp({ op: "close", id: r.r[0].id });
  } finally {
    srv.close();
    closeAllTunnelSessions();
  }
});

test("sessions are tracked and cleaned up", async () => {
  const { srv, port } = await echoServer();
  try {
    const before = tunnelSessionCount();
    const c = await tunnelOp({ op: "connect", h: "127.0.0.1", p: port });
    assert.equal(tunnelSessionCount(), before + 1);
    await tunnelOp({ op: "close", id: c.id });
    assert.equal(tunnelSessionCount(), before);
  } finally {
    srv.close();
    closeAllTunnelSessions();
  }
});
