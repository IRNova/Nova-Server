import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { writeFileSync as wf, appendFileSync as af, rmSync } from "node:fs";

import { parseAccessLines, readNewLines, updateOnline, onlineCounts, overLimitIds } from "../src/xray/access.mjs";
import { openKv } from "../src/kv/sqlite.mjs";

const LINES = [
  "2026/07/19 21:00:00 from 1.2.3.4:5678 accepted tcp:example.com:443 [vless-ws -> direct] email: alice",
  "2026/07/19 21:00:01 from 9.9.9.9:1111 accepted tcp:example.com:443 [vless-ws -> direct] email: alice",
  "2026/07/19 21:00:02 from 1.2.3.4:5679 accepted tcp:x:443 [vless-ws -> direct] email: alice",
  "2026/07/19 21:00:03 from 5.5.5.5:2222 accepted tcp:y:443 [trojan-grpc -> direct] email: bob",
  "2026/07/19 21:00:04 from [2606:4700::1]:3333 accepted udp:z:443 [hy2 -> direct] email: bob",
  "2026/07/19 21:00:05 some unrelated log line without a match",
];

test("parseAccessLines extracts ip + email, strips ipv6 brackets", () => {
  const e = parseAccessLines(LINES);
  assert.equal(e.length, 5);
  assert.deepEqual(e[0], { ip: "1.2.3.4", email: "alice" });
  assert.equal(e[4].ip, "2606:4700::1");
  assert.equal(e[4].email, "bob");
});

test("readNewLines reads only appended bytes and survives truncation", () => {
  const p = join(tmpdir(), `nova-acc-${randomBytes(6).toString("hex")}.log`);
  wf(p, LINES.slice(0, 2).join("\n") + "\n");
  const r1 = readNewLines(p, 0);
  assert.equal(r1.lines.length, 2);
  af(p, LINES[3] + "\n");
  const r2 = readNewLines(p, r1.offset);
  assert.equal(r2.lines.length, 1);
  assert.match(r2.lines[0], /bob/);
  // truncate -> re-read from 0
  wf(p, LINES[0] + "\n");
  const r3 = readNewLines(p, r2.offset);
  assert.equal(r3.lines.length, 1);
  rmSync(p);
});

test("updateOnline counts distinct IPs and expires old ones by window", async () => {
  const path = join(tmpdir(), `nova-acc-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  try {
    const t0 = 1_000_000;
    let counts = await updateOnline(kv, parseAccessLines(LINES), { windowMs: 300_000, now: t0 });
    assert.equal(counts.alice, 2); // 1.2.3.4 + 9.9.9.9 (5679 same IP as 5678)
    assert.equal(counts.bob, 2);
    // alice reconnects from one IP much later; the other two age out.
    counts = await updateOnline(kv, [{ ip: "1.2.3.4", email: "alice" }], { windowMs: 300_000, now: t0 + 400_000 });
    assert.equal(counts.alice, 1);
    const live = await onlineCounts(kv, { windowMs: 300_000, now: t0 + 400_000 });
    assert.equal(live.alice, 1);
  } finally {
    kv.close();
    for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} }
  }
});

test("overLimitIds flags only users past a positive ipLimit", () => {
  const users = [
    { id: "a", ipLimit: 2 },
    { id: "b", ipLimit: 0 },
    { id: "c", ipLimit: 3 },
  ];
  const over = overLimitIds(users, { a: 3, b: 99, c: 3 });
  assert.equal(over.has("a"), true);
  assert.equal(over.has("b"), false); // unlimited
  assert.equal(over.has("c"), false); // exactly at limit
});
