// Multi-node subscriptions (inbound-driven model). A user gets an inbound purely
// from their inbound allowlist; a node-placed inbound is then emitted at THAT
// node's address (never the main host), and nodeId:"all" emits one config per
// node. There is no separate per-user node access: the node follows the assigned
// inbound. A placement with no reachable node emits nothing. buildSub is pure, so
// these pin the exact address in each generated config.
import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSub } from "../src/subscription.mjs";

const decode = (b64) => Buffer.from(b64, "base64").toString("utf8");
const user = (extra) => ({ id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "u1", enabled: true, ...extra });
const inbound = (extra) => ({ id: "in1", protocol: "vless", placement: "standalone", network: "tcp", security: "none", port: 8443, ...extra });
const NODES = [{ id: "nd1", name: "Germany", address: "11.11.11.11" }, { id: "nd2", name: "UK", address: "22.22.22.22" }];
const HOST = "main.example.com";

test("local placement, assigned -> config uses the main host", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["in1"] })], { host: HOST, inbounds: [inbound({ nodeId: "local" })], nodes: NODES }));
  assert.match(sub, /@main\.example\.com:8443/);
  assert.doesNotMatch(sub, /11\.11\.11\.11/);
});

test("node placement, assigned -> config uses THAT node's address (no toggle needed)", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["in1"] })], { host: HOST, inbounds: [inbound({ nodeId: "nd1" })], nodes: NODES }));
  assert.match(sub, /@11\.11\.11\.11:8443/);
  assert.doesNotMatch(sub, /@main\.example\.com:8443/);
  assert.doesNotMatch(sub, /22\.22\.22\.22/);
});

test("all-nodes placement, assigned -> one config per node with its address + name", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["in1"] })], { host: HOST, inbounds: [inbound({ nodeId: "all" })], nodes: NODES }));
  assert.match(sub, /@11\.11\.11\.11:8443/);
  assert.match(sub, /@22\.22\.22\.22:8443/);
  assert.match(sub, /Germany/);
  assert.match(sub, /UK/);
  assert.doesNotMatch(sub, /@main\.example\.com:8443/);
});

test("a user NOT assigned the node inbound does not get it", async () => {
  const sub = decode(await buildSub([user({ inboundIds: [] })], { host: HOST, inbounds: [inbound({ nodeId: "nd1" })], nodes: NODES }));
  assert.doesNotMatch(sub, /11\.11\.11\.11/);
  assert.doesNotMatch(sub, /8443/);
});

test("placement on a missing node -> no config, and no main-host leak", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["in1"] })], { host: HOST, inbounds: [inbound({ nodeId: "gone" })], nodes: NODES }));
  assert.doesNotMatch(sub, /8443/);
  assert.doesNotMatch(sub, /@main\.example\.com:8443/);
});

test("empty fleet -> a node-placed inbound is dropped, NOT fallen back to the main host", async () => {
  const sub = decode(await buildSub([user({ inboundIds: ["in1"] })], { host: HOST, inbounds: [inbound({ nodeId: "nd1" })], nodes: [] }));
  assert.doesNotMatch(sub, /8443/);
  assert.doesNotMatch(sub, /@main\.example\.com:8443/);
});
