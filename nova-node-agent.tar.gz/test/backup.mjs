import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { rmSync } from "node:fs";

import { openKv } from "../src/kv/sqlite.mjs";
import { createServer } from "../src/server.mjs";

const UA = "Nova/1.0.0 (desktop; sing-box)";
function startServer(kv, opts) {
  const server = createServer(kv, opts);
  return new Promise((resolve) => server.listen(0, "127.0.0.1", () => {
    const { port } = server.address();
    resolve({ base: `http://127.0.0.1:${port}`, close: () => new Promise((r) => server.close(r)) });
  }));
}
function freshKv() {
  const path = join(tmpdir(), `nova-bk-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return { kv, cleanup() { kv.close(); for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} } } };
}
const cookieOf = (res) => (/(?:^|,\s*)auth=([^;]+)/.exec(res.headers.get("set-cookie") || "") || [])[1];

test("backup exports settings, restore validates and re-applies them", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-bk-cfg-${randomBytes(6).toString("hex")}.json`);
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  try {
    let res = await fetch(srv.base + "/install/set", {
      method: "POST", headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ password: "hunter2secret" }),
    });
    const cookie = cookieOf(res);
    const auth = { cookie: `auth=${cookie}`, "user-agent": UA, "content-type": "application/json" };

    await fetch(srv.base + "/admin/network-settings.json", {
      method: "POST", headers: auth,
      body: JSON.stringify({ host: "node.example", enableAdBlock: true }),
    });
    await fetch(srv.base + "/admin/users.json", {
      method: "POST", headers: auth,
      body: JSON.stringify({ action: "add", user: { id: "me", uuid: "11111111-1111-4111-8111-111111111111", email: "me", enabled: true } }),
    });

    // Back up.
    res = await fetch(srv.base + "/admin/backup", { headers: { cookie: `auth=${cookie}`, "user-agent": UA } });
    assert.equal(res.headers.get("content-disposition"), 'attachment; filename="nova-node-backup.json"');
    const dump = await res.json();
    assert.equal(dump.settings.enableAdBlock, true);
    assert.equal(dump.settings.users.length, 1);

    // Wipe a setting, then restore.
    await fetch(srv.base + "/admin/network-settings.json", { method: "POST", headers: auth, body: JSON.stringify({ enableAdBlock: false }) });
    res = await fetch(srv.base + "/admin/restore", { method: "POST", headers: auth, body: JSON.stringify(dump) });
    assert.equal(res.status, 200);
    assert.equal((await res.json()).users, 1);

    res = await fetch(srv.base + "/admin/network-settings.json", { headers: { cookie: `auth=${cookie}`, "user-agent": UA } });
    const s = await res.json();
    assert.equal(s.enableAdBlock, true); // restored
    assert.equal(s.users[0].id, "me");
  } finally {
    await srv.close();
    cleanup();
  }
});

test("restore rejects a backup whose inbound is invalid", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-bk-cfg-${randomBytes(6).toString("hex")}.json`);
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  try {
    const r0 = await fetch(srv.base + "/install/set", {
      method: "POST", headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ password: "hunter2secret" }),
    });
    const auth = { cookie: `auth=${cookieOf(r0)}`, "user-agent": UA, "content-type": "application/json" };
    const bad = { settings: { users: [], inbounds: [{ id: "x", protocol: "vless", network: "ws", security: "reality", port: 8443 }] } };
    const res = await fetch(srv.base + "/admin/restore", { method: "POST", headers: auth, body: JSON.stringify(bad) });
    assert.equal(res.status, 400); // reality over ws is rejected
  } finally {
    await srv.close();
    cleanup();
  }
});
