// Nova VPS agent: local smoke test. No VPS, no xray: the process manager's
// shell-outs are no-op'd (managerOpts.exec = false), so this exercises the whole
// vertical slice on any Node 24+ box.
//
//   node --test        (or: node test/smoke.mjs)

import { test } from "node:test";
import assert from "node:assert/strict";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { rmSync, readFileSync } from "node:fs";
import { randomBytes } from "node:crypto";

import { openKv } from "../src/kv/sqlite.mjs";
import {
  setPassword,
  checkPassword,
  makeSession,
  verifySession,
} from "../src/auth.mjs";
import {
  applyUserAction,
  usageData,
  getSettings,
  createServer,
} from "../src/server.mjs";
import { generateXrayConfig } from "../src/xray/config.mjs";
import { buildSub } from "../src/subscription.mjs";
import { accrue } from "../src/xray/stats.mjs";
import { applyUsers } from "../src/xray/manager.mjs";
import { recordTunnelHealth } from "../src/tunnels/health.mjs";

function tmpConfig() {
  return join(tmpdir(), `nova-smoke-cfg-${randomBytes(6).toString("hex")}.json`);
}

// Start the real node:http server on an ephemeral loopback port.
function startServer(kv, opts) {
  const server = createServer(kv, opts);
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      resolve({
        base: `http://127.0.0.1:${port}`,
        close: () => new Promise((r) => server.close(r)),
      });
    });
  });
}

function cookieValue(res) {
  const sc = res.headers.get("set-cookie") || "";
  const m = /(?:^|,\s*)auth=([^;]+)/.exec(sc);
  return m ? m[1] : null;
}

const UA = "Nova/1.0.0 (desktop; sing-box)";
// Dev mode: no shell-outs to xray/systemctl, and write the config to a tmp path
// instead of the system default (/usr/local/etc/xray/config.json).
const CONFIG_PATH = join(tmpdir(), `nova-smoke-config-${randomBytes(6).toString("hex")}.json`);
const NOEXEC = { managerOpts: { exec: false, configPath: CONFIG_PATH } };

function freshKv() {
  const path = join(tmpdir(), `nova-smoke-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return {
    kv,
    cleanup() {
      kv.close();
      for (const ext of ["", "-wal", "-shm"]) {
        try {
          rmSync(path + ext);
        } catch {}
      }
    },
  };
}

test("KV round-trips get/put/delete/list with a prefix", async () => {
  const { kv, cleanup } = freshKv();
  try {
    assert.equal(await kv.get("missing"), null);
    await kv.put("uusage:a", "10");
    await kv.put("uusage:b", "20");
    await kv.put("uusage-d:a:2026-07-19", "5"); // must NOT match "uusage:" prefix
    assert.equal(await kv.get("uusage:a"), "10");
    const names = (await kv.list({ prefix: "uusage:" })).map((r) => r.name).sort();
    assert.deepEqual(names, ["uusage:a", "uusage:b"]);
    await kv.delete("uusage:a");
    assert.equal(await kv.get("uusage:a"), null);
  } finally {
    cleanup();
  }
});

test("password set + login + session issue/verify (UA-pinned)", async () => {
  const { kv, cleanup } = freshKv();
  try {
    await setPassword(kv, "hunter2secret");
    assert.equal(await checkPassword(kv, "hunter2secret"), true);
    assert.equal(await checkPassword(kv, "wrong"), false);

    const sess = await makeSession(kv, { userAgent: UA });
    assert.match(sess.cookie, /^auth=/);
    assert.match(sess.cookie, /HttpOnly/);
    assert.match(sess.cookie, /Secure/);
    assert.match(sess.cookie, /SameSite=Lax/);

    // Valid with the same UA...
    assert.equal(await verifySession(kv, sess.value, { userAgent: UA }), true);
    // ...pinned: a different UA fails.
    assert.equal(
      await verifySession(kv, sess.value, { userAgent: "curl/8" }),
      false,
    );
    // ...idle timeout: an old token fails.
    assert.equal(
      await verifySession(kv, sess.value, {
        userAgent: UA,
        now: Date.now(),
        maxAgeMs: -1,
      }),
      false,
    );
    // ...changing the password invalidates outstanding cookies.
    await setPassword(kv, "a-new-password");
    assert.equal(await verifySession(kv, sess.value, { userAgent: UA }), false);
  } finally {
    cleanup();
  }
});

test("add a user via the handler -> xray config contains it", async () => {
  const { kv, cleanup } = freshKv();
  try {
    await setPassword(kv, "hunter2secret");
    const { user } = await applyUserAction(
      kv,
      { action: "add", user: { email: "alice", name: "Alice" } },
      NOEXEC,
    );
    assert.ok(user.id);
    assert.match(user.uuid, /^[0-9a-f-]{36}$/);

    const settings = await getSettings(kv);
    assert.equal(settings.users.length, 1);

    const cfg = generateXrayConfig(settings.users, { wsPath: settings.wsPath });
    const inbound = cfg.inbounds.find((i) => i.tag === "vless-ws");
    const ids = inbound.settings.clients.map((c) => c.id);
    assert.ok(ids.includes(user.uuid), "generated config must include the user's uuid");
  } finally {
    cleanup();
  }
});

test("buildSub emits a vless link and hides an over-quota user", async () => {
  const { kv, cleanup } = freshKv();
  try {
    const users = [
      { id: "u_ok", uuid: "11111111-1111-4111-8111-111111111111", email: "u_ok", enabled: true, quotaBytes: 1000 },
      { id: "u_over", uuid: "22222222-2222-4222-8222-222222222222", email: "u_over", enabled: true, quotaBytes: 1000 },
      { id: "u_off", uuid: "33333333-3333-4333-8333-333333333333", email: "u_off", enabled: false },
    ];
    await kv.put("uusage:u_ok", "500"); // under quota
    await kv.put("uusage:u_over", "2000"); // over quota -> hidden

    const b64 = await buildSub(users, { host: "node.example.com", wsPath: "/nova-x", kv });
    const body = Buffer.from(b64, "base64").toString("utf8");
    const lines = body.split("\n").filter(Boolean);

    assert.equal(lines.length, 1, "only the under-quota enabled user is listed");
    assert.match(lines[0], /^vless:\/\/11111111-1111-4111-8111-111111111111@node\.example\.com:443\?/);
    assert.match(lines[0], /security=tls/);
    assert.match(lines[0], /path=%2Fnova-x/);
    assert.ok(!body.includes("22222222"), "over-quota user must be hidden");
    assert.ok(!body.includes("33333333"), "disabled user must be hidden");
  } finally {
    cleanup();
  }
});

test("accrue writes xray deltas into uusage:* keys", async () => {
  const { kv, cleanup } = freshKv();
  try {
    const deltas = {
      u_alice: { up: 100, down: 400 },
      u_bob: { up: 0, down: 0 },
    };
    const total = await accrue(kv, deltas, { now: new Date("2026-07-19T00:00:00Z") });
    assert.equal(total, 500);
    assert.equal(await kv.get("uusage:u_alice"), "500");
    assert.equal(await kv.get("uusage-d:u_alice:2026-07-19"), "500");
    // Up/down are kept split too.
    assert.equal(await kv.get("uusage-up:u_alice"), "100");
    assert.equal(await kv.get("uusage-dn:u_alice"), "400");
    assert.equal(await kv.get("uusage-d-up:u_alice:2026-07-19"), "100");
    assert.equal(await kv.get("uusage-d-dn:u_alice:2026-07-19"), "400");
    // A second poll accumulates.
    await accrue(kv, { u_alice: { up: 0, down: 50 } }, { now: new Date("2026-07-19T01:00:00Z") });
    assert.equal(await kv.get("uusage:u_alice"), "550");
    assert.equal(await kv.get("uusage-dn:u_alice"), "450");

    const usage = await usageData(kv);
    assert.equal(usage.u_alice, 550);
  } finally {
    cleanup();
  }
});

test("http server: install, login, UA-pinned auth, admin add, sub (M8)", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  const post = (obj, cookie) => ({
    method: "POST",
    headers: {
      "content-type": "application/json",
      "user-agent": UA,
      ...(cookie ? { cookie: `auth=${cookie}` } : {}),
    },
    body: JSON.stringify(obj),
  });
  try {
    // /install/set mints a session cookie.
    let res = await fetch(srv.base + "/install/set", post({ password: "hunter2secret" }));
    assert.equal(res.status, 200);
    const cookie = cookieValue(res);
    assert.ok(cookie, "install returns a session cookie");

    // /login: correct password works, wrong password is 401.
    res = await fetch(srv.base + "/login", post({ password: "hunter2secret" }));
    assert.equal(res.status, 200);
    assert.ok(cookieValue(res), "login returns a session cookie");
    res = await fetch(srv.base + "/login", post({ password: "nope" }));
    assert.equal(res.status, 401);

    // /admin/usage-data: no cookie -> 401.
    res = await fetch(srv.base + "/admin/usage-data");
    assert.equal(res.status, 401);
    // ...cookie + matching UA -> 200.
    res = await fetch(srv.base + "/admin/usage-data", {
      headers: { cookie: `auth=${cookie}`, "user-agent": UA },
    });
    assert.equal(res.status, 200);
    // ...cookie replayed under a different UA -> rejected (UA pinning).
    res = await fetch(srv.base + "/admin/usage-data", {
      headers: { cookie: `auth=${cookie}`, "user-agent": "curl/8" },
    });
    assert.equal(res.status, 401);

    // Authenticated add of a user.
    const uuid = "11111111-1111-4111-8111-111111111111";
    res = await fetch(
      srv.base + "/admin/users.json",
      post({ action: "add", user: { id: "alice", email: "alice", uuid } }, cookie),
    );
    assert.equal(res.status, 200);
    const added = await res.json();
    assert.equal(added.user.uuid, uuid);

    // exec:false still wrote config.json; assert it contains the new client (M8/C1).
    const cfg = JSON.parse(readFileSync(configPath, "utf8"));
    const inbound = cfg.inbounds.find((i) => i.tag === "vless-ws");
    assert.ok(
      inbound.settings.clients.some((c) => c.id === uuid),
      "config.json on disk must contain the added user",
    );

    // Set a public host so /sub can build links.
    res = await fetch(
      srv.base + "/admin/network-settings.json",
      post({ host: "node.example.com" }, cookie),
    );
    assert.equal(res.status, 200);

    // Read the sub token back.
    res = await fetch(srv.base + "/admin/network-settings.json", {
      headers: { cookie: `auth=${cookie}`, "user-agent": UA },
    });
    const settings = await res.json();
    assert.ok(settings.subToken, "settings expose the sub token");

    // /sub with a good token returns the vless link.
    res = await fetch(`${srv.base}/sub?token=${settings.subToken}`);
    assert.equal(res.status, 200);
    const subBody = Buffer.from(await res.text(), "base64").toString("utf8");
    assert.match(subBody, /^vless:\/\//);
    assert.ok(subBody.includes(uuid), "sub link carries the user's uuid");
    assert.match(subBody, /encryption=none/);

    // /sub with a bad token is 403.
    res = await fetch(`${srv.base}/sub?token=wrong`);
    assert.equal(res.status, 403);

    // Per-user auto-subscription: /sub?u=<subId> returns only that user's
    // configs, keyed by the unguessable subId (sha256(subToken:userId)[:24]),
    // with no admin token. A bogus subId is 403.
    const { createHash: _sha } = await import("node:crypto");
    const uid = settings.users[0].id;
    const subId = _sha("sha256").update(settings.subToken + ":" + uid).digest("hex").slice(0, 24);
    res = await fetch(`${srv.base}/sub?u=${subId}`);
    assert.equal(res.status, 200, "per-user sub returns 200");
    const perUser = Buffer.from(await res.text(), "base64").toString("utf8");
    assert.ok(perUser.includes(uuid), "per-user sub carries the user's uuid");
    res = await fetch(`${srv.base}/sub?u=deadbeefdeadbeefdeadbeef`);
    assert.equal(res.status, 403, "an unknown subId is rejected");
  } finally {
    await srv.close();
    cleanup();
    try {
      rmSync(configPath);
    } catch {}
  }
});

test("REST API v1: docs public, token-gated CRUD, reseller scoping", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  const post = (obj, cookie) => ({
    method: "POST",
    headers: {
      "content-type": "application/json", "user-agent": UA,
      ...(cookie ? { cookie: `auth=${cookie}` } : {}),
    },
    body: JSON.stringify(obj),
  });
  const bearer = (tok, extra = {}) => ({ headers: { authorization: `Bearer ${tok}`, "user-agent": UA, ...extra } });
  try {
    let res = await fetch(srv.base + "/install/set", post({ password: "hunter2secret" }));
    const cookie = cookieValue(res);

    // Docs are public (no token).
    res = await fetch(srv.base + "/api/v1");
    assert.equal(res.status, 200);
    const docs = await res.json();
    assert.equal(docs.version, "v1");
    assert.ok(Array.isArray(docs.endpoints) && docs.endpoints.length > 5);

    // No token -> 401.
    res = await fetch(srv.base + "/api/v1/users");
    assert.equal(res.status, 401);

    // Create an owner token via the admin endpoint (plaintext shown once).
    res = await fetch(srv.base + "/admin/api-tokens", post({ name: "ci", role: "owner" }, cookie));
    assert.equal(res.status, 200);
    const { token } = await res.json();
    assert.ok(token && token.startsWith("nova_"), "returns a plaintext token once");

    // Listing tokens never leaks the plaintext or the hash.
    res = await fetch(srv.base + "/admin/api-tokens", { headers: { cookie: `auth=${cookie}`, "user-agent": UA } });
    const tl = await res.json();
    assert.equal(tl.tokens.length, 1);
    assert.ok(!("hash" in tl.tokens[0]) && !("token" in tl.tokens[0]));

    // Bad token -> 401; good token -> 200.
    res = await fetch(srv.base + "/api/v1/health", bearer("nova_wrong"));
    assert.equal(res.status, 401);
    res = await fetch(srv.base + "/api/v1/health", bearer(token));
    assert.equal(res.status, 200);
    assert.equal((await res.json()).role, "owner");

    // Create a user through the API.
    const uuid = "22222222-2222-4222-8222-222222222222";
    res = await fetch(srv.base + "/api/v1/users", {
      method: "POST",
      headers: { authorization: `Bearer ${token}`, "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ action: "add", user: { id: "bob", email: "bob", uuid } }),
    });
    assert.equal(res.status, 200);

    // It shows up in the list with a sub link.
    res = await fetch(srv.base + "/api/v1/users", bearer(token));
    const { users } = await res.json();
    assert.ok(users.find((u) => u.id === "bob"), "API user list includes the new user");

    // config.json on disk got the client too (same path as the panel).
    const cfg = JSON.parse(readFileSync(configPath, "utf8"));
    const inbound = cfg.inbounds.find((i) => i.tag === "vless-ws");
    assert.ok(inbound.settings.clients.some((c) => c.id === uuid), "API add reached xray config");

    // Reseller token only sees its own users (bob has no ownerId, reseller r1 sees none).
    res = await fetch(srv.base + "/admin/api-tokens", post({ name: "r1", role: "reseller", ownerId: "r1" }, cookie));
    const rtok = (await res.json()).token;
    res = await fetch(srv.base + "/api/v1/users", bearer(rtok));
    assert.equal((await res.json()).users.length, 0, "reseller is scoped to its own users");
    // Reseller cannot touch inbounds.
    res = await fetch(srv.base + "/api/v1/inbounds", bearer(rtok));
    assert.equal(res.status, 403);
  } finally {
    await srv.close();
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("Telegram Mini App: initData HMAC verification", async () => {
  const { verifyTelegramWebApp } = await import("../src/auth.mjs");
  const { createHmac } = await import("node:crypto");
  const botToken = "123456:ABC-DEF";
  const params = { auth_date: String(Math.floor(Date.now() / 1000)), query_id: "AAbb", user: JSON.stringify({ id: 555, first_name: "Vahid" }) };
  const dcs = Object.entries(params).map(([k, v]) => `${k}=${v}`).sort().join("\n");
  const secret = createHmac("sha256", "WebAppData").update(botToken).digest();
  const hash = createHmac("sha256", secret).update(dcs).digest("hex");
  const initData = new URLSearchParams({ ...params, hash }).toString();

  // Valid initData -> returns the user.
  const v = verifyTelegramWebApp(initData, botToken);
  assert.ok(v && v.user && v.user.id === 555);
  // Wrong bot token -> null.
  assert.equal(verifyTelegramWebApp(initData, "999:WRONG"), null);
  // Tampered payload -> null.
  assert.equal(verifyTelegramWebApp(initData.replace("Vahid", "Mallory"), botToken), null);
  // Missing hash -> null.
  assert.equal(verifyTelegramWebApp("user=%7B%7D&auth_date=1", botToken), null);
  // Stale auth_date -> null.
  const oldParams = { auth_date: "1000000000", user: JSON.stringify({ id: 1 }) };
  const odcs = Object.entries(oldParams).map(([k, v]) => `${k}=${v}`).sort().join("\n");
  const oh = createHmac("sha256", secret).update(odcs).digest("hex");
  assert.equal(verifyTelegramWebApp(new URLSearchParams({ ...oldParams, hash: oh }).toString(), botToken), null);
  // Signed data without auth_date, or dated far into the future, is invalid.
  const noDate = { user: JSON.stringify({ id: 1 }) };
  const ndh = createHmac("sha256", secret).update(`user=${noDate.user}`).digest("hex");
  assert.equal(verifyTelegramWebApp(new URLSearchParams({ ...noDate, hash: ndh }).toString(), botToken), null);
  const future = { auth_date: String(Math.floor(Date.now() / 1000) + 3600), user: JSON.stringify({ id: 1 }) };
  const fdcs = Object.entries(future).map(([k, v]) => `${k}=${v}`).sort().join("\n");
  const fh = createHmac("sha256", secret).update(fdcs).digest("hex");
  assert.equal(verifyTelegramWebApp(new URLSearchParams({ ...future, hash: fh }).toString(), botToken), null);
});

test("automations: clean-IP refresh, auto-update gating, throttle", async () => {
  const { kv, cleanup } = freshKv();
  const { maybeCleanIpRefresh, maybeAutoUpdate, semverGt, getSettings, putSettings } = await import("../src/server.mjs");
  try {
    assert.equal(semverGt("0.2.6", "0.2.5"), true);
    assert.equal(semverGt("0.2.5", "0.2.5"), false);
    assert.equal(semverGt("1.0.0", "0.9.9"), true);

    await setPassword(kv, "x");
    await getSettings(kv);

    // Clean-IP refresh is OFF by default -> does nothing.
    const ipFetch = async () => ({ ok: true, text: async () => "1.1.1.1\n2.2.2.2\nnotanip\n3.3.3.3" });
    await maybeCleanIpRefresh(kv, {}, { fetchImpl: ipFetch, now: 1_000_000 });
    assert.equal((await getSettings(kv)).customIPs, undefined);

    // Turn it on -> pulls + filters valid IPs into customIPs.
    await putSettings(kv, { ...(await getSettings(kv)), autoCleanIp: true });
    await maybeCleanIpRefresh(kv, {}, { fetchImpl: ipFetch, now: 2_000_000 });
    assert.equal((await getSettings(kv)).customIPs, "1.1.1.1\n2.2.2.2\n3.3.3.3");

    // Throttled: a second run in the same day does not re-fetch (change source, expect no change).
    const ipFetch2 = async () => ({ ok: true, text: async () => "9.9.9.9" });
    await maybeCleanIpRefresh(kv, {}, { fetchImpl: ipFetch2, now: 2_000_000 + 60_000 });
    assert.equal((await getSettings(kv)).customIPs, "1.1.1.1\n2.2.2.2\n3.3.3.3", "throttle blocks same-day re-run");

    // Auto-update: off by default -> no-op even with a newer version published.
    let updateChecked = false;
    const verFetch = async () => { updateChecked = true; return { ok: true, text: async () => "9.9.9" }; };
    await maybeAutoUpdate(kv, { managerOpts: { exec: false } }, { fetchImpl: verFetch, now: 3_000_000 });
    assert.equal(updateChecked, false, "auto-update does nothing while disabled");
    // On + exec disabled (test mode) -> still guarded (won't spawn), returns cleanly.
    await putSettings(kv, { ...(await getSettings(kv)), autoUpdate: true });
    await maybeAutoUpdate(kv, { managerOpts: { exec: false } }, { fetchImpl: verFetch, now: 3_000_000 });
    assert.equal(updateChecked, false, "exec:false short-circuits before the version fetch");
  } finally {
    cleanup();
  }
});

test("Iran reachability + block detection + setup recommendation (mocked)", async () => {
  const { kv, cleanup } = freshKv();
  const { checkIranReachability } = await import("../src/iran-reach.mjs");
  const { recommendSetup, maybeIranBlockCheck, getSettings, putSettings } = await import("../src/server.mjs");
  const noSleep = async () => {};
  // A check-host mock: nodes/hosts -> one Iran node; check-tcp -> a request id;
  // check-result -> whatever `tcpResult` is set to.
  const makeCh = (tcpResult) => async (url) => {
    if (String(url).includes("/nodes/hosts")) return { ok: true, json: async () => ({ nodes: { "ir1.node.check-host.net": { location: ["ir", "Iran", "Tehran"] } } }) };
    if (String(url).includes("/check-tcp")) return { ok: true, json: async () => ({ ok: 1, request_id: "REQ1" }) };
    if (String(url).includes("/check-result/")) return { ok: true, json: async () => ({ "ir1.node.check-host.net": tcpResult }) };
    return { ok: false, json: async () => ({}) };
  };
  try {
    // Blocked: the Iran node cannot connect.
    const blocked = await checkIranReachability({ host: "5.5.5.5", port: 443, fetchImpl: makeCh([{ error: "Timeout exceeded" }]), sleepImpl: noSleep });
    assert.equal(blocked.verdict, "blocked");
    assert.equal(blocked.ok, 0);
    assert.equal(blocked.total, 1);

    // Reachable: the Iran node connects.
    const reach = await checkIranReachability({ host: "5.5.5.5", port: 443, fetchImpl: makeCh([{ address: "5.5.5.5", time: 0.12 }]), sleepImpl: noSleep });
    assert.equal(reach.verdict, "reachable");
    assert.equal(reach.ok, 1);

    // recommendSetup: no domain -> Reality; with a trusted domain -> tls.
    await setPassword(kv, "x");
    await putSettings(kv, { ...(await getSettings(kv)), host: "", insecure: true });
    let rec = recommendSetup(await getSettings(kv));
    assert.equal(rec.hasDomain, false);
    assert.equal(rec.recommend, "reality");
    assert.ok(rec.serverNames.length > 0);
    await putSettings(kv, { ...(await getSettings(kv)), host: "node.example.com", insecure: false });
    rec = recommendSetup(await getSettings(kv));
    assert.equal(rec.hasDomain, true);
    assert.equal(rec.recommend, "tls");

    // maybeIranBlockCheck: OFF by default -> never touches the network.
    let called = false;
    const spyFetch = async () => { called = true; return { ok: true, json: async () => ({}), text: async () => "" }; };
    await putSettings(kv, { ...(await getSettings(kv)), iranBlockCheck: false });
    await maybeIranBlockCheck(kv, {}, { fetchImpl: spyFetch, now: 1_000_000 });
    assert.equal(called, false, "disabled -> no probe");

    // ON but no Telegram channel configured -> still no probe (nowhere to alert).
    await putSettings(kv, { ...(await getSettings(kv)), iranBlockCheck: true, enableTelegram: false });
    await maybeIranBlockCheck(kv, {}, { fetchImpl: spyFetch, now: 2_000_000 });
    assert.equal(called, false, "no alert channel -> no probe");
  } finally {
    cleanup();
  }
});

test("IP rotation: provider detection + DO/Vultr/Hetzner adapters (mocked)", async () => {
  const { detectProvider, rotateViaProvider } = await import("../src/ip-rotate.mjs");
  const ok = (obj) => ({ ok: true, status: 200, json: async () => obj });

  // Detection maps ASN/org text to a provider key.
  const detFetch = () => ok({ org: "AS14061 DigitalOcean, LLC", asn: "AS14061" });
  const det = await detectProvider("5.5.5.5", { fetchImpl: detFetch });
  assert.equal(det.key, "digitalocean");
  assert.equal(det.api, true);
  const vDet = await detectProvider("5.5.5.5", { fetchImpl: () => ok({ org: "AS20473 The Constant Company (Vultr)" }) });
  assert.equal(vDet.key, "vultr");
  const unknown = await detectProvider("5.5.5.5", { fetchImpl: () => ok({ org: "AS12345 Some Local ISP" }) });
  assert.equal(unknown.key, "unknown");
  assert.equal(unknown.api, false);

  // DigitalOcean: list droplets -> owns IP -> create reserved IP.
  const doFetch = async (url) => {
    if (url.includes("/v2/droplets")) return ok({ droplets: [{ id: 1, networks: { v4: [{ ip_address: "5.5.5.5" }] } }] });
    if (url.includes("/v2/reserved_ips")) return ok({ reserved_ip: { ip: "6.6.6.6" } });
    return { ok: false, status: 404, json: async () => ({}) };
  };
  assert.equal((await rotateViaProvider("digitalocean", "tok", "5.5.5.5", { fetchImpl: doFetch })).ip, "6.6.6.6");

  // Vultr: list instances -> create reserved IP -> attach.
  const vFetch = async (url) => {
    if (url.includes("/v2/instances")) return ok({ instances: [{ id: "i1", main_ip: "5.5.5.5", region: "ewr" }] });
    if (url.endsWith("/reserved-ips")) return ok({ reserved_ip: { id: "r1", subnet: "7.7.7.7" } });
    if (url.includes("/attach")) return ok({});
    return { ok: false, status: 404, json: async () => ({}) };
  };
  assert.equal((await rotateViaProvider("vultr", "tok", "5.5.5.5", { fetchImpl: vFetch })).ip, "7.7.7.7");

  // Hetzner: list servers -> create floating IP.
  const hFetch = async (url) => {
    if (url.includes("/v1/servers")) return ok({ servers: [{ id: 1, public_net: { ipv4: { ip: "5.5.5.5" } } }] });
    if (url.includes("/v1/floating_ips")) return ok({ floating_ip: { ip: "8.8.8.8" } });
    return { ok: false, status: 404, json: async () => ({}) };
  };
  assert.equal((await rotateViaProvider("hetzner", "tok", "5.5.5.5", { fetchImpl: hFetch })).ip, "8.8.8.8");

  // Linode: list instances -> allocate a new public IPv4.
  const lFetch = async (url) => {
    if (url.includes("/v4/linode/instances") && url.includes("/ips")) return ok({ address: "9.9.9.9" });
    if (url.includes("/v4/linode/instances")) return ok({ data: [{ id: 42, ipv4: ["5.5.5.5"] }] });
    return { ok: false, status: 404, json: async () => ({}) };
  };
  assert.equal((await rotateViaProvider("linode", "tok", "5.5.5.5", { fetchImpl: lFetch })).ip, "9.9.9.9");

  // Guards: unsupported provider (OVH is guided) and missing token both throw.
  await assert.rejects(() => rotateViaProvider("ovh", "tok", "5.5.5.5", { fetchImpl: doFetch }));
  await assert.rejects(() => rotateViaProvider("digitalocean", "", "5.5.5.5", { fetchImpl: doFetch }));
  // No droplet owns the IP -> throws (never silently returns a bad IP).
  await assert.rejects(() => rotateViaProvider("digitalocean", "tok", "9.9.9.9", { fetchImpl: async (url) => url.includes("/v2/droplets") ? ok({ droplets: [] }) : ok({}) }));
});

test("Cloudflare: token verify, zone lookup, DNS A upsert (mocked)", async () => {
  const { cfVerifyToken, cfFindZone, cfUpsertA, rootDomain, publicIp } = await import("../src/cloudflare.mjs");
  assert.equal(rootDomain("vpn.sub.example.com"), "example.com");
  assert.equal(rootDomain("example.com"), "example.com");

  const ok = (result) => { const calls = []; return { calls, fetchImpl: async (url, init) => { calls.push({ url, method: (init && init.method) || "GET" }); return { text: async () => "1.2.3.4", json: async () => ({ success: true, result }) }; } }; };

  assert.deepEqual(await cfVerifyToken("t", ok({ status: "active", id: "x" })), { valid: true, id: "x" });
  // Inactive token -> not valid.
  assert.equal((await cfVerifyToken("t", ok({ status: "disabled" }))).valid, false);
  // Zone lookup.
  const z = await cfFindZone("t", "vpn.example.com", ok([{ id: "z1", name: "example.com" }]));
  assert.deepEqual(z, { id: "z1", name: "example.com" });
  // No zone -> clear error.
  await assert.rejects(() => cfFindZone("t", "vpn.example.com", ok([])), /no active Cloudflare zone/);

  // Upsert: no existing record -> POST creates it.
  const created = ok([]);
  await cfUpsertA("t", "z1", { name: "vpn.example.com", ip: "1.2.3.4" }, created);
  assert.equal(created.calls[created.calls.length - 1].method, "POST");
  // Existing record -> PUT updates it.
  const updated = ok([{ id: "rec1" }]);
  await cfUpsertA("t", "z1", { name: "vpn.example.com", ip: "9.9.9.9", proxied: false }, updated);
  assert.equal(updated.calls[updated.calls.length - 1].method, "PUT");

  // API failure surfaces the CF error message.
  const failFetch = async () => ({ json: async () => ({ success: false, errors: [{ message: "Invalid API Token" }] }) });
  await assert.rejects(() => cfVerifyToken("bad", { fetchImpl: failFetch }), /Invalid API Token/);
});

test("2FA: TOTP setup, enable, and login enforcement", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  const { verifyTotp } = await import("../src/auth.mjs");
  const post = (obj, cookie) => ({
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": UA, ...(cookie ? { cookie: `auth=${cookie}` } : {}) },
    body: JSON.stringify(obj),
  });
  // Derive a valid code for a base32 secret (mirrors auth.mjs).
  const { createHmac } = await import("node:crypto");
  const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const dec = (str) => { let bits = 0, val = 0; const out = []; for (const c of str) { const i = B32.indexOf(c); if (i < 0) continue; val = (val << 5) | i; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } } return Buffer.from(out); };
  const codeFor = (secret) => { const key = dec(secret); const cnt = Math.floor(Date.now() / 1000 / 30); const b = Buffer.alloc(8); b.writeUInt32BE(0, 0); b.writeUInt32BE(cnt >>> 0, 4); const h = createHmac("sha1", key).update(b).digest(); const o = h[h.length - 1] & 0xf; const c = ((h[o] & 0x7f) << 24) | ((h[o + 1] & 0xff) << 16) | ((h[o + 2] & 0xff) << 8) | (h[o + 3] & 0xff); return String(c % 1000000).padStart(6, "0"); };
  try {
    let res = await fetch(srv.base + "/install/set", post({ password: "ownerpass1" }));
    const c = cookieValue(res);

    // Setup returns a secret + otpauth URI; not yet enabled.
    res = await fetch(srv.base + "/admin/2fa", post({ action: "setup" }, c));
    const { secret, uri } = await res.json();
    assert.ok(secret && uri.startsWith("otpauth://totp/"));
    res = await fetch(srv.base + "/admin/2fa", { headers: { cookie: `auth=${c}`, "user-agent": UA } });
    assert.equal((await res.json()).enabled, false);

    // Enable requires a valid code.
    res = await fetch(srv.base + "/admin/2fa", post({ action: "enable", code: "000000" }, c));
    assert.equal(res.status, 400);
    res = await fetch(srv.base + "/admin/2fa", post({ action: "enable", code: codeFor(secret) }, c));
    assert.equal(res.status, 200);

    // Now login: password alone returns {twofa:true}, not a session.
    res = await fetch(srv.base + "/login", post({ password: "ownerpass1" }));
    let body = await res.json();
    assert.equal(body.twofa, true);
    assert.ok(!cookieValue(res), "no session without the code");
    // Wrong code -> 401.
    res = await fetch(srv.base + "/login", post({ password: "ownerpass1", code: "000000" }));
    assert.equal(res.status, 401);
    // Correct password + code -> session issued.
    res = await fetch(srv.base + "/login", post({ password: "ownerpass1", code: codeFor(secret) }));
    assert.equal(res.status, 200);
    assert.ok(cookieValue(res), "session issued with a valid code");

    // Disable (with a code) turns it back off.
    res = await fetch(srv.base + "/admin/2fa", post({ action: "disable", code: codeFor(secret) }, c));
    assert.equal(res.status, 200);
    res = await fetch(srv.base + "/login", post({ password: "ownerpass1" }));
    assert.ok(cookieValue(res), "password-only login works again after disabling 2FA");
  } finally {
    await srv.close();
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("per-user inbound grants: sub shows only what the user was granted", async () => {
  const { kv, cleanup } = freshKv();
  try {
    const inbounds = [
      { id: "in-reality", tag: "vless-reality", protocol: "vless", network: "tcp", security: "reality", port: 8443, enabled: true, allUsers: true, reality: { privateKey: "k", publicKey: "p", serverNames: ["x.com"], dest: "x.com:443", shortIds: ["ab"] } },
    ];
    // Front protocols vless+trojan on; one standalone reality inbound.
    const opts = { host: "node.example.com", wsPath: "/nova", kv, protocols: { vless: true, trojan: true }, inbounds };

    // No allowlist -> gets front vless + trojan + the reality inbound.
    const all = Buffer.from(await buildSub([{ id: "u1", uuid: "11111111-1111-4111-8111-111111111111", enabled: true }], opts), "base64").toString("utf8");
    assert.ok(/vless:\/\/.*@node\.example\.com/.test(all), "front vless present");
    assert.ok(/trojan:\/\//.test(all), "front trojan present");
    assert.ok(/@node\.example\.com:8443/.test(all), "reality inbound present");

    // Allowlist = only front vless -> trojan and the reality inbound are hidden.
    const scoped = Buffer.from(await buildSub([{ id: "u2", uuid: "22222222-2222-4222-8222-222222222222", enabled: true, inboundIds: ["front:vless"] }], opts), "base64").toString("utf8");
    assert.ok(/vless:\/\//.test(scoped), "granted front vless shown");
    assert.ok(!/trojan:\/\//.test(scoped), "ungranted trojan hidden");
    assert.ok(!/:8443/.test(scoped), "ungranted reality inbound hidden");

    // Allowlist = only the reality inbound -> no front protocols at all.
    const onlyIn = Buffer.from(await buildSub([{ id: "u3", uuid: "33333333-3333-4333-8333-333333333333", enabled: true, inboundIds: ["in-reality"] }], opts), "base64").toString("utf8");
    assert.ok(/:8443/.test(onlyIn), "granted reality inbound shown");
    assert.ok(!/path=%2Fnova/.test(onlyIn) && !/trojan:\/\//.test(onlyIn), "front protocols hidden when not granted");
  } finally {
    cleanup();
  }
});

test("WireGuard inbound: model, validation, xray build, peer .conf", async () => {
  const { normalizeInbound, validateInbound, buildInbound, buildInbounds, renderWgPeerConf, nextWgAddress, PROTOCOLS, clientsForInbound } = await import("../src/xray/inbounds.mjs");
  assert.ok(PROTOCOLS.includes("wireguard"), "wireguard is a selectable inbound protocol");

  const inb = normalizeInbound({
    protocol: "wireguard", port: 51820, wgSecretKey: "SRVPRIV", wgPublicKey: "SRVPUB",
    peers: [{ id: "p1", name: "phone", privateKey: "ppriv", publicKey: "ppub", address: "10.7.0.2/32" }],
  });
  assert.equal(validateInbound(inb).ok, true);
  // Missing server key is rejected.
  assert.equal(validateInbound(normalizeInbound({ protocol: "wireguard", port: 51820 })).ok, false);
  // A peer without a public key/address is rejected.
  assert.equal(validateInbound(normalizeInbound({ protocol: "wireguard", port: 51820, wgSecretKey: "K", peers: [{ name: "x" }] })).ok, false);

  // Builds a real xray wireguard inbound: peers in settings, no clients/stream.
  const built = buildInbound(inb, clientsForInbound(inb, [{ id: "u", enabled: true }]));
  assert.equal(built.protocol, "wireguard");
  assert.equal(built.settings.secretKey, "SRVPRIV");
  assert.deepEqual(built.settings.peers, [{ publicKey: "ppub", allowedIPs: ["10.7.0.2/32"] }]);
  assert.ok(!built.streamSettings && !built.settings.clients, "wireguard has no stream/clients");

  // buildInbounds includes it in the xray config (not skipped like sing-box).
  const { inbounds } = buildInbounds([inb], [], { reservedPorts: [443] });
  assert.ok(inbounds.some((i) => i.protocol === "wireguard"), "wireguard flows into the xray config");

  // Peer address allocation + client .conf.
  assert.equal(nextWgAddress(inb.peers), "10.7.0.3/32");
  const conf = renderWgPeerConf(inb, inb.peers[0], "node.example.com");
  assert.match(conf, /\[Interface\]/);
  assert.match(conf, /PrivateKey = ppriv/);
  assert.match(conf, /PublicKey = SRVPUB/);
  assert.match(conf, /Endpoint = node\.example\.com:51820/);
});

test("WARP: license apply + account status summary (mocked Cloudflare)", async () => {
  const { accountFromRegistration, accountSummary, setWarpLicense, warpAccountStatus } = await import("../src/xray/warp.mjs");

  // Registration now keeps id + token + a normalized account summary.
  const acc = accountFromRegistration(
    { privateKey: "priv", publicKey: "pub" },
    { id: "reg123", token: "tok456", created: "2026-01-01", account: { warp_plus: false, account_type: "free", quota: 0 }, config: { peers: [{ public_key: "PK", endpoint: { host: "h:2408" } }], interface: { addresses: { v4: "1.2.3.4" } }, client_id: "abc" } },
  );
  assert.equal(acc.id, "reg123");
  assert.equal(acc.token, "tok456");
  assert.equal(acc.account.warpPlus, false);

  // accountSummary maps Cloudflare's shape to the panel's.
  const sum = accountSummary({ warp_plus: true, account_type: "plus", premium_data: 5 * 1024 * 1024 * 1024, premium_data_expires: "2027-01-01", license: "L" });
  assert.equal(sum.warpPlus, true);
  assert.equal(sum.premiumData, 5 * 1024 * 1024 * 1024);

  // setWarpLicense PUTs the key and returns the upgraded summary.
  let putUrl = "", putBody = null, auth = "";
  const fetchImpl = async (url, init) => {
    putUrl = url; putBody = JSON.parse(init.body); auth = init.headers.authorization;
    return { ok: true, status: 200, json: async () => ({ warp_plus: true, account_type: "plus", premium_data: 1000, premium_data_expires: "2027-01-01" }) };
  };
  const upgraded = await setWarpLicense(acc, "MY-LICENSE-KEY", { fetchImpl });
  assert.match(putUrl, /\/reg\/reg123\/account$/);
  assert.equal(putBody.license, "MY-LICENSE-KEY");
  assert.equal(auth, "Bearer tok456");
  assert.equal(upgraded.warpPlus, true);

  // A rejected license surfaces a clear error.
  const reject = async () => ({ ok: false, status: 400, json: async () => ({}) });
  await assert.rejects(() => setWarpLicense(acc, "bad", { fetchImpl: reject }), /rejected/i);

  // warpAccountStatus polls GET and returns the summary.
  const st = await warpAccountStatus(acc, { fetchImpl: async () => ({ ok: true, status: 200, json: async () => ({ warp_plus: true, premium_data: 42 }) }) });
  assert.equal(st.premiumData, 42);
});

test("WARP: low-data + expiry alert fires once (throttled)", async () => {
  const { kv, cleanup } = freshKv();
  const { maybeWarpQuotaCheck } = await import("../src/server.mjs");
  try {
    await kv.put("warp-account.json", JSON.stringify({ privateKey: "p", id: "r", token: "t", account: { warpPlus: true } }));
    // Low remaining data -> sets the warning flag.
    const lowFetch = async () => ({ ok: true, status: 200, json: async () => ({ warp_plus: true, premium_data: 1024 * 1024 }) });
    await maybeWarpQuotaCheck(kv, { fetchImpl: lowFetch, now: 1_000_000 });
    assert.equal(await kv.get("warp:lowflag"), "1", "low data raises the flag");
    // Throttled: a second call within 6h does nothing new (no throw, flag stays).
    await maybeWarpQuotaCheck(kv, { fetchImpl: lowFetch, now: 1_000_000 + 60_000 });
    assert.equal(await kv.get("warp:lowflag"), "1");
    // After a top-up (plenty of data), a later check clears the flag.
    const okFetch = async () => ({ ok: true, status: 200, json: async () => ({ warp_plus: true, premium_data: 5 * 1024 * 1024 * 1024 }) });
    await maybeWarpQuotaCheck(kv, { fetchImpl: okFetch, now: 1_000_000 + 7 * 60 * 60 * 1000 });
    assert.equal(await kv.get("warp:lowflag"), null, "recovered clears the flag");
  } finally {
    cleanup();
  }
});

test("client sub routing: Direct Iran bypasses the tunnel in clash + sing-box", async () => {
  const { toClash, toSingbox } = await import("../src/sub-formats.mjs");
  const proxies = [{ name: "Nova-1", protocol: "vless", server: "h", port: 443, uuid: "u", network: "ws", tls: true, sni: "h", path: "/x" }];

  // Off by default (no anti-censorship rules) -> everything through Nova.
  let clash = toClash(proxies, { net: {} });
  assert.ok(!/DIRECT/.test(clash), "no direct rules when nothing enabled");
  assert.match(clash, /MATCH,Nova/);

  // Direct Iran on: .ir + Iranian IPs go DIRECT on the client (keeps real IP).
  clash = toClash(proxies, { net: { bypassIran: true, enableAdBlock: true } });
  assert.match(clash, /DOMAIN-SUFFIX,ir,DIRECT/);
  assert.match(clash, /GEOIP,IR,DIRECT,no-resolve/);
  assert.match(clash, /GEOSITE,category-ads-all,REJECT/);
  // Order: the DIRECT/REJECT rules must come BEFORE the catch-all MATCH.
  assert.ok(clash.indexOf("DOMAIN-SUFFIX,ir,DIRECT") < clash.indexOf("MATCH,Nova"), "bypass rules precede MATCH");

  // sing-box: domain_suffix .ir + geoip ir -> direct, before final Nova.
  const sb = JSON.parse(toSingbox(proxies, { net: { bypassIran: true } }));
  assert.equal(sb.route.final, "Nova");
  assert.ok(sb.route.rules.some((r) => Array.isArray(r.domain_suffix) && r.domain_suffix.includes(".ir") && r.outbound === "direct"));
  assert.ok(sb.route.rules.some((r) => Array.isArray(r.geoip) && r.geoip.includes("ir") && r.outbound === "direct"));
  assert.ok(sb.outbounds.some((o) => o.tag === "direct") && sb.outbounds.some((o) => o.tag === "block"));

  // Master off suppresses the whole bundle.
  const off = toClash(proxies, { net: { antiCensorship: false, bypassIran: true } });
  assert.ok(!/DIRECT/.test(off), "antiCensorship=false suppresses client rules");
});

test("per-inbound outbound: assigning tor/psiphon/custom applies + emits it", async () => {
  const { buildOutbounds, buildRoutingRules, buildCustomOutbound } = await import("../src/xray/routing.mjs");

  // Inbound assigned to tor while enableTor is OFF: the tor outbound is still
  // emitted (else xray won't start) and a rule routes that inbound through it.
  const net = {
    enableTor: false,
    inbounds: [{ id: "i1", tag: "reality-a", outbound: "tor" }, { id: "i2", tag: "ss-b", outbound: "direct" }],
    outbounds: [{ id: "o1", tag: "up1", type: "socks", address: "10.0.0.9", port: 1080, enabled: true }],
  };
  const outs = buildOutbounds(net, {});
  assert.ok(outs.some((o) => o.tag === "tor"), "referenced tor outbound is force-emitted");
  assert.ok(outs.some((o) => o.tag === "up1" && o.protocol === "socks"), "custom outbound emitted");
  const rules = buildRoutingRules(net);
  assert.ok(rules.some((r) => r.inboundTag && r.inboundTag[0] === "reality-a" && r.outboundTag === "tor"), "per-inbound tor rule added");
  assert.ok(!rules.some((r) => r.inboundTag && r.inboundTag[0] === "ss-b"), "a direct inbound gets no extra rule");

  // buildCustomOutbound guided types + raw escape hatch.
  assert.equal(buildCustomOutbound({ tag: "b", type: "blackhole" }).protocol, "blackhole");
  assert.equal(buildCustomOutbound({ tag: "h", type: "http", address: "h", port: 8080 }).protocol, "http");
  assert.equal(buildCustomOutbound({ tag: "s", type: "socks" }), null, "socks without address is rejected");
  assert.deepEqual(buildCustomOutbound({ tag: "r", raw: { protocol: "freedom", settings: {} } }), { protocol: "freedom", settings: {}, tag: "r" });
});

test("BackPack tunnel backend: recommended, TOML for both roles, UDP", async () => {
  const { BACKENDS, RECOMMENDED, TRANSPORTS, backpackConfig, renderTunnel, validateTunnel } = await import("../src/tunnels/config.mjs");
  assert.ok(BACKENDS.includes("backpack"));
  assert.ok(RECOMMENDED.includes("backpack") && RECOMMENDED.includes("backhaul"));
  assert.ok(TRANSPORTS.backpack.includes("wssmux") && TRANSPORTS.backpack.includes("udp"));

  const bridge = { backend: "backpack", role: "bridge", transport: "wssmux", tunnelPort: 8880, token: "supersecret", forwards: ["443", "8443/udp"], mux: 8 };
  assert.equal(validateTunnel(bridge).ok, true);
  const srv = backpackConfig(bridge);
  assert.match(srv, /\[server\]/);
  assert.match(srv, /bind_addr = "0\.0\.0\.0:8880"/);
  assert.match(srv, /accept_udp = true/);
  assert.match(srv, /ports = \["443=127\.0\.0\.1:443", "8443=127\.0\.0\.1:8443"\]/);

  const exit = { backend: "backpack", role: "exit", transport: "wssmux", tunnelPort: 8880, token: "supersecret", bridgeAddr: "1.2.3.4:8880", forwards: ["443"] };
  const cli = backpackConfig(exit);
  assert.match(cli, /\[client\]/);
  assert.match(cli, /remote_addr = "1\.2\.3\.4:8880"/);

  const art = renderTunnel(bridge);
  assert.equal(art.exec, "backpack");
  assert.match(art.path, /backpack\.toml$/);
});

test("tunnel config: validation + backhaul/rathole/wstunnel generation", async () => {
  const {
    validateTunnel, backhaulConfig, ratholeConfig, wstunnelArgs, renderTunnel, normalizeForwards,
  } = await import("../src/tunnels/config.mjs");

  // Validation rejects the obvious mistakes.
  assert.equal(validateTunnel({ backend: "nope" }).ok, false);
  assert.equal(validateTunnel({ backend: "backhaul", role: "bridge", transport: "quic", tunnelPort: 443, token: "secret123", forwards: ["443"] }).ok, false);
  assert.equal(validateTunnel({ backend: "backhaul", role: "exit", tunnelPort: 443, token: "secret123", forwards: ["443"] }).ok, false, "exit needs bridgeAddr");
  assert.equal(validateTunnel({ backend: "backhaul", role: "bridge", tunnelPort: 443, token: "short", forwards: ["443"] }).ok, false, "token too short");

  // Forwards normalize (proto + default target).
  const fwd = normalizeForwards(["443", "8443/udp", "80=127.0.0.1:8080"]);
  assert.equal(fwd.length, 3);
  assert.equal(fwd[1].proto, "udp");
  assert.equal(fwd[2].target, "127.0.0.1:8080");

  // Backhaul bridge (Iran server) forwards TCP 443 + UDP 8443 (Hysteria2). The
  // control port must be a third port not in the forwards (2053 here), or the
  // 8443 control channel would collide with the 8443 forward.
  const bridge = { backend: "backhaul", role: "bridge", transport: "wssmux", tunnelPort: 2053, token: "supersecret", mux: 8, forwards: ["443", "8443/udp"] };
  assert.equal(validateTunnel(bridge).ok, true);
  const bcfg = backhaulConfig(bridge);
  assert.match(bcfg, /\[server\]/);
  assert.match(bcfg, /transport = "wssmux"/);
  assert.match(bcfg, /mux_con = 8/);
  assert.match(bcfg, /"443=127\.0\.0\.1:443"/);
  assert.match(bcfg, /"8443=127\.0\.0\.1:8443"/);
  assert.match(bcfg, /accept_udp = true/, "Backhaul bridge enables UDP when any forward is /udp");

  const tcpOnly = backhaulConfig({ ...bridge, forwards: ["443"] });
  assert.doesNotMatch(tcpOnly, /accept_udp/, "TCP-only Backhaul bridge does not enable UDP globally");

  // Backhaul exit (foreign client) dials the bridge.
  const exit = { backend: "backhaul", role: "exit", transport: "wssmux", tunnelPort: 8443, token: "supersecret", bridgeAddr: "1.2.3.4:8443", forwards: ["443"] };
  const ecfg = backhaulConfig(exit);
  assert.match(ecfg, /\[client\]/);
  assert.match(ecfg, /remote_addr = "1\.2\.3\.4:8443"/);

  // rathole generates per-service blocks.
  const rcfg = ratholeConfig({ ...bridge, backend: "rathole", transport: "noise" });
  assert.match(rcfg, /\[server\]/);
  assert.match(rcfg, /\[server\.services\.nova_443\]/);
  assert.match(rcfg, /\[server\.services\.nova_443\]\ntype = "tcp"/);
  assert.match(rcfg, /\[server\.services\.nova_8443\]\ntype = "udp"/);
  assert.match(rcfg, /type = "noise"/);
  const { TRANSPORTS } = await import("../src/tunnels/config.mjs");
  assert.deepEqual(TRANSPORTS.rathole, ["tcp", "noise"], "Rathole only advertises deployable control transports");

  // wstunnel emits CLI args for both roles.
  const wsb = wstunnelArgs({ backend: "wstunnel", role: "bridge", transport: "wss", tunnelPort: 8443, token: "supersecret", forwards: ["443"] });
  assert.deepEqual(wsb, ["server", "wss://0.0.0.0:8443"]);
  const wsc = wstunnelArgs({ backend: "wstunnel", role: "exit", transport: "wss", tunnelPort: 8443, token: "supersecret", bridgeAddr: "1.2.3.4:8443", forwards: ["443"] });
  assert.ok(wsc.includes("client") && wsc.some((a) => a.includes("tcp://443")));

  // renderTunnel returns a deployable artifact.
  const art = renderTunnel(bridge);
  assert.equal(art.kind, "file");
  assert.match(art.path, /backhaul\.toml$/);
  assert.equal(renderTunnel({ backend: "wstunnel", role: "bridge", transport: "wss", tunnelPort: 8443, token: "supersecret", forwards: ["443"] }).kind, "args");
});

test("tunnel endpoint: save + read back (no exec)", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  const post = (obj, cookie) => ({
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": UA, ...(cookie ? { cookie: `auth=${cookie}` } : {}) },
    body: JSON.stringify(obj),
  });
  try {
    let res = await fetch(srv.base + "/install/set", post({ password: "ownerpass1" }));
    const c = cookieValue(res);
    // Save a bridge tunnel (exec is off, so no systemd, just persistence).
    res = await fetch(srv.base + "/admin/tunnels", post({
      action: "save",
      tunnel: { backend: "backhaul", role: "bridge", transport: "wssmux", tunnelPort: 2053, token: "supersecret", forwards: ["443", "8443/udp"] },
    }, c));
    assert.equal(res.status, 200);
    // Read it back.
    res = await fetch(srv.base + "/admin/tunnels", { headers: { cookie: `auth=${c}`, "user-agent": UA } });
    const body = await res.json();
    assert.equal(body.tunnel.backend, "backhaul");
    assert.equal(body.tunnel.enabled, true);
    assert.ok(body.backends.includes("rathole"));
    assert.deepEqual(body.health.samples, [], "new tunnel has no stale payload history");
    // Read-only runtime refuses commands that would touch systemd or the network.
    res = await fetch(srv.base + "/admin/tunnels", post({ action: "probe" }, c));
    assert.equal(res.status, 503);
    res = await fetch(srv.base + "/admin/tunnels", post({ action: "publish" }, c));
    assert.equal(res.status, 503);
    res = await fetch(srv.base + "/admin/tunnels", post({
      action: "preflight",
      tunnel: { backend: "backhaul", role: "exit", transport: "tcpmux", tunnelPort: 2053, token: "supersecret", bridgeAddr: "1.1.1.1:2053", forwards: ["443"] },
    }, c));
    assert.equal(res.status, 503);
    // A bad spec is rejected.
    res = await fetch(srv.base + "/admin/tunnels", post({ action: "save", tunnel: { backend: "backhaul", role: "exit", tunnelPort: 8443, token: "supersecret", forwards: ["443"] } }, c));
    assert.equal(res.status, 400, "exit without bridgeAddr is rejected");
  } finally {
    await srv.close();
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("tunnel phone-home: token-gated bridge auto-report", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  const post = (obj, cookie) => ({
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": UA, ...(cookie ? { cookie: `auth=${cookie}` } : {}) },
    body: JSON.stringify(obj),
  });
  const hello = (obj) => fetch(srv.base + "/api/tunnel/hello", {
    method: "POST", headers: { "content-type": "application/json", "user-agent": UA }, body: JSON.stringify(obj),
  });
  try {
    // No exit tunnel yet -> 404 (endpoint is inert until configured).
    let res = await hello({ token: "whatever", ip: "9.9.9.9", port: 2053 });
    assert.equal(res.status, 404, "no exit tunnel -> 404");
    // Become owner, save an EXIT tunnel with a token + bridge address.
    res = await fetch(srv.base + "/install/set", post({ password: "ownerpass1" }));
    const c = cookieValue(res);
    res = await fetch(srv.base + "/admin/tunnels", post({ action: "save", tunnel: { backend: "backhaul", role: "exit", tunnelPort: 2053, token: "sekret123", bridgeAddr: "1.1.1.1:2053", forwards: ["443"] } }, c));
    assert.equal(res.status, 200);
    // Wrong token -> 403, no session needed either way.
    res = await hello({ token: "nope", ip: "9.9.9.9", port: 2053 });
    assert.equal(res.status, 403, "bad token -> 403");
    // Malformed IP -> 400, and it must NOT consume the rate-limit window.
    res = await hello({ token: "sekret123", ip: "9.9.9.9/evil?sni=x", port: 2053 });
    assert.equal(res.status, 400, "bad ip -> 400");
    // Correct token -> bridge address recorded from the reported IP.
    res = await hello({ token: "sekret123", ip: "9.9.9.9", port: 2053 });
    assert.equal(res.status, 200);
    assert.equal((await res.json()).bridgeAddr, "9.9.9.9:2053");
    res = await fetch(srv.base + "/admin/tunnels", { headers: { cookie: `auth=${c}`, "user-agent": UA } });
    const body = await res.json();
    assert.equal(body.tunnel.bridgeAddr, "9.9.9.9:2053");
    assert.ok(Number(body.tunnel.bridgeLastSeen) > 0, "bridgeLastSeen recorded");
    assert.equal((await getSettings(kv)).tunnelAddr || "", "", "phone-home discovers but never publishes an unverified bridge");
    // Direct attempts to publish the bridge are blocked until a recent full
    // payload success exists.
    res = await fetch(srv.base + "/admin/network-settings.json", post({ tunnelAddr: "9.9.9.9" }, c));
    assert.equal(res.status, 409);
    await recordTunnelHealth(kv, {
      up: true,
      state: "active",
      probe: { ok: true, state: "pass", httpStatus: 200, latencyMs: 90, detail: "Nova payload reached" },
    });
    res = await fetch(srv.base + "/admin/network-settings.json", post({ tunnelAddr: "9.9.9.9" }, c));
    assert.equal(res.status, 200, "fresh payload success unlocks bridge publication");
    assert.equal((await getSettings(kv)).tunnelAddr, "9.9.9.9");
    // Immediate second report is throttled, not re-applied.
    res = await hello({ token: "sekret123", ip: "8.8.8.8", port: 2053 });
    assert.equal((await res.json()).throttled, true, "second report throttled");
  } finally {
    await srv.close();
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("factory reset wipes users/inbounds but keeps the owner logged in", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  const post = (obj, c) => ({ method: "POST", headers: { "content-type": "application/json", "user-agent": UA, ...(c ? { cookie: `auth=${c}` } : {}) }, body: JSON.stringify(obj) });
  try {
    let res = await fetch(srv.base + "/install/set", post({ password: "ownerpass1" }));
    const c = cookieValue(res);
    await fetch(srv.base + "/admin/users.json", post({ action: "add", user: { name: "u", protocols: { vless: true } } }, c));
    // seed owner 2FA in settings; it must survive the reset (login is kept)
    const seed = JSON.parse(await kv.get("network-settings.json"));
    seed.owner2fa = { secret: "OWNER2FASECRET", enabled: true };
    await kv.put("network-settings.json", JSON.stringify(seed));
    // wrong confirmation is rejected
    res = await fetch(srv.base + "/admin/reset", post({ confirm: "nope" }, c));
    assert.equal(res.status, 400, "wrong confirm rejected");
    // typed confirmation resets
    res = await fetch(srv.base + "/admin/reset", post({ confirm: "RESET" }, c));
    assert.equal(res.status, 200, "reset ok");
    const st = await (await fetch(srv.base + "/admin/network-settings.json", { headers: { cookie: `auth=${c}`, "user-agent": UA } })).json();
    assert.equal((st.users || []).length, 0, "users wiped");
    assert.ok(st.owner2fa && st.owner2fa.secret === "OWNER2FASECRET", "owner 2FA preserved across reset");
    // the owner cookie still reaches an owner-only route (login preserved)
    res = await fetch(srv.base + "/admin/network-settings.json", { headers: { cookie: `auth=${c}`, "user-agent": UA } });
    assert.equal(res.status, 200, "owner still logged in after reset");
  } finally { await srv.close(); cleanup(); try { rmSync(configPath); } catch {} }
});

test("logs endpoint returns lines for the owner", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  const post = (obj) => ({ method: "POST", headers: { "content-type": "application/json", "user-agent": UA }, body: JSON.stringify(obj) });
  try {
    const res0 = await fetch(srv.base + "/install/set", post({ password: "ownerpass1" }));
    const c = cookieValue(res0);
    const res = await fetch(srv.base + "/admin/logs?unit=nova-agent&lines=50", { headers: { cookie: `auth=${c}`, "user-agent": UA } });
    assert.equal(res.status, 200);
    const j = await res.json();
    assert.equal(j.unit, "nova-agent");
    assert.ok(Array.isArray(j.lines), "lines is an array");
  } finally { await srv.close(); cleanup(); try { rmSync(configPath); } catch {} }
});

test("HWID device binding: /sub caps distinct devices, reset clears them", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  const post = (obj, c) => ({ method: "POST", headers: { "content-type": "application/json", "user-agent": UA, ...(c ? { cookie: `auth=${c}` } : {}) }, body: JSON.stringify(obj) });
  const { createHash } = await import("node:crypto");
  try {
    let res = await fetch(srv.base + "/install/set", post({ password: "ownerpass1" }));
    const c = cookieValue(res);
    res = await fetch(srv.base + "/admin/users.json", post({ action: "add", user: { name: "dev", deviceLimit: 2, protocols: { vless: true } } }, c));
    assert.equal(res.status, 200);
    const st = await (await fetch(srv.base + "/admin/network-settings.json", { headers: { cookie: `auth=${c}`, "user-agent": UA } })).json();
    const u = st.users.find((x) => x.name === "dev");
    assert.equal(u.deviceLimit, 2, "deviceLimit persisted on add");
    const subId = createHash("sha256").update(st.subToken + ":" + u.id).digest("hex").slice(0, 24);
    const sub = (hwid) => fetch(srv.base + "/sub?u=" + subId, { headers: { "user-agent": UA, ...(hwid ? { "x-hwid": hwid } : {}) } });
    assert.equal((await sub("A")).status, 200, "device A");
    assert.equal((await sub("B")).status, 200, "device B");
    assert.equal((await sub("A")).status, 200, "known device still allowed");
    assert.equal((await sub("C")).status, 403, "3rd device blocked at limit 2");
    assert.equal((await sub(null)).status, 200, "no-hwid client not blocked (fail open)");
    const dev = await (await fetch(srv.base + "/admin/hwid", { headers: { cookie: `auth=${c}`, "user-agent": UA } })).json();
    assert.equal(dev.devices[u.id], 2, "two bound devices reported");
    assert.equal((await fetch(srv.base + "/admin/hwid", post({ action: "reset", id: u.id }, c))).status, 200, "reset ok");
    assert.equal((await sub("C")).status, 200, "device C allowed after reset");
  } finally {
    await srv.close(); cleanup(); try { rmSync(configPath); } catch {}
  }
});

test("multi-node fleet: register a node, aggregate users, provision remotely", async () => {
  const a = freshKv(), b = freshKv();
  const cfgA = tmpConfig(), cfgB = tmpConfig();
  const srvA = await startServer(a.kv, { managerOpts: { exec: false, configPath: cfgA } });
  const srvB = await startServer(b.kv, { managerOpts: { exec: false, configPath: cfgB } });
  const post = (obj, cookie) => ({
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": UA, ...(cookie ? { cookie: `auth=${cookie}` } : {}) },
    body: JSON.stringify(obj),
  });
  try {
    // Bring up both nodes; make an API token on B.
    let res = await fetch(srvA.base + "/install/set", post({ password: "ownerA1" }));
    const ca = cookieValue(res);
    res = await fetch(srvB.base + "/install/set", post({ password: "ownerB1" }));
    const cb = cookieValue(res);
    res = await fetch(srvB.base + "/admin/api-tokens", post({ name: "fleet", role: "owner" }, cb));
    const bToken = (await res.json()).token;

    // Give each node a user of its own.
    await fetch(srvA.base + "/admin/users.json", post({ action: "add", user: { id: "a_user", email: "a" } }, ca));
    await fetch(srvB.base + "/admin/users.json", post({ action: "add", user: { id: "b_user", email: "b" } }, cb));

    // Register B as a node of A (A validates reachability + token before saving).
    res = await fetch(srvA.base + "/admin/nodes", post({ name: "node-b", url: srvB.base, apiToken: bToken }, ca));
    assert.equal(res.status, 200, "node registers when reachable");
    const nodeId = (await res.json()).node.id;

    // A bad token is rejected up front.
    res = await fetch(srvA.base + "/admin/nodes", post({ name: "bad", url: srvB.base, apiToken: "nova_nope" }, ca));
    assert.equal(res.status, 502);

    // Fleet users aggregates local (A) + remote (B), tagged by node.
    res = await fetch(srvA.base + "/admin/fleet/users", { headers: { cookie: `auth=${ca}`, "user-agent": UA } });
    const fleet = await res.json();
    assert.ok(fleet.users.some((u) => u.nodeId === "local" && u.id === "a_user"));
    assert.ok(fleet.users.some((u) => u.nodeId === nodeId && u.id === "b_user"), "remote node's user shows up");

    // Provision a new user onto B through A.
    res = await fetch(srvA.base + "/admin/fleet/provision", post({ nodeId, user: { id: "pushed", email: "pushed" } }, ca));
    assert.equal(res.status, 200);
    // It really landed on B.
    res = await fetch(srvB.base + "/api/v1/users", { headers: { authorization: `Bearer ${bToken}`, "user-agent": UA } });
    const bUsers = (await res.json()).users;
    assert.ok(bUsers.some((u) => u.id === "pushed"), "provisioned user exists on the remote node");
  } finally {
    await srvA.close(); await srvB.close();
    a.cleanup(); b.cleanup();
    try { rmSync(cfgA); rmSync(cfgB); } catch {}
  }
});

test("multi-admin: reseller login, owner-only gating, ownership scoping", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  const post = (obj, cookie) => ({
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": UA, ...(cookie ? { cookie: `auth=${cookie}` } : {}) },
    body: JSON.stringify(obj),
  });
  const get = (cookie) => ({ headers: { cookie: `auth=${cookie}`, "user-agent": UA } });
  try {
    let res = await fetch(srv.base + "/install/set", post({ password: "ownerpass1" }));
    const owner = cookieValue(res);

    // whoami reports owner.
    res = await fetch(srv.base + "/admin/whoami", get(owner));
    assert.equal((await res.json()).role, "owner");

    // Owner creates a reseller with prepaid balance, and a sellable plan for it.
    res = await fetch(srv.base + "/admin/admins", post({ name: "reseller-a", password: "resellpass", balance: 100 }, owner));
    assert.equal(res.status, 200);
    res = await fetch(srv.base + "/admin/user-templates", post({ template: { id: "plan1", name: "Basic", sellable: true, price: 5, volumeGB: 10, expireDays: 30 } }, owner));
    assert.equal(res.status, 200);

    // Reseller can log in and gets a reseller-scoped session.
    res = await fetch(srv.base + "/login", post({ password: "resellpass" }));
    assert.equal(res.status, 200);
    assert.equal((await res.json()).role, "reseller");
    const rc = cookieValue(res);
    res = await fetch(srv.base + "/admin/whoami", get(rc));
    assert.equal((await res.json()).role, "reseller");

    // Reseller is blocked from owner-only routes.
    res = await fetch(srv.base + "/admin/network-settings.json", get(rc));
    assert.equal(res.status, 403);
    res = await fetch(srv.base + "/admin/inbounds", get(rc));
    assert.equal(res.status, 403);
    res = await fetch(srv.base + "/admin/admins", get(rc));
    assert.equal(res.status, 403);
    // ...but can add its own user only through a sellable plan (the quality gate).
    res = await fetch(srv.base + "/admin/users.json", post({ action: "add", user: { name: "cust1", planId: "plan1" } }, rc));
    assert.equal(res.status, 200);
    // A free-form add (no plan) is refused, so a reseller can't sell the free front.
    res = await fetch(srv.base + "/admin/users.json", post({ action: "add", user: { name: "cust2" } }, rc));
    assert.equal(res.status, 400);

    // The owner's user (added by owner) is not visible to the reseller's usage view.
    res = await fetch(srv.base + "/admin/users.json", post({ action: "add", user: { id: "owned_by_owner", email: "ob" } }, owner));
    assert.equal(res.status, 200);
    res = await fetch(srv.base + "/admin/usage-data", get(rc));
    const usage = (await res.json()).usage;
    assert.ok(!("owned_by_owner" in usage), "reseller usage excludes the owner's user");

    // Reseller cannot delete a user it does not own.
    res = await fetch(srv.base + "/admin/users.json", post({ action: "delete", user: { id: "owned_by_owner" } }, rc));
    assert.equal(res.status, 404);

    // Deleting the reseller invalidates its session.
    res = await fetch(srv.base + "/admin/admins", get(owner));
    const list = (await res.json()).admins;
    const radm = list.find((a) => a.name === "reseller-a");
    res = await fetch(srv.base + "/admin/admins", post({ action: "delete", id: radm.id }, owner));
    assert.equal(res.status, 200);
    res = await fetch(srv.base + "/admin/whoami", get(rc));
    assert.equal(res.status, 401, "deleted reseller's cookie no longer resolves");
  } finally {
    await srv.close();
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("rbac: manager sees all + capability enforcement + reseller-safe list is scoped and key-free", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  const post = (obj, cookie) => ({
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": UA, ...(cookie ? { cookie: `auth=${cookie}` } : {}) },
    body: JSON.stringify(obj),
  });
  const get = (cookie) => ({ headers: { cookie: `auth=${cookie}`, "user-agent": UA } });
  try {
    let res = await fetch(srv.base + "/install/set", post({ password: "ownerpass1" }));
    const owner = cookieValue(res);

    // Owner adds a user, and a reseller who will own a different user.
    await fetch(srv.base + "/admin/users.json", post({ action: "add", user: { id: "owner_user", email: "ou" } }, owner));
    await fetch(srv.base + "/admin/admins", post({ name: "res-b", password: "resbpass1", role: "reseller" }, owner));
    // A read-only MANAGER: sees everyone, but can only view (no create).
    res = await fetch(srv.base + "/admin/admins", post({ name: "mgr-view", password: "mgrpass12", role: "manager", caps: ["users.view", "dashboard.view"] }, owner));
    assert.equal(res.status, 200);

    // Manager logs in; whoami reports manager + scope all + its caps.
    res = await fetch(srv.base + "/login", post({ password: "mgrpass12" }));
    const mc = cookieValue(res);
    const who = await (await fetch(srv.base + "/admin/whoami", get(mc))).json();
    assert.equal(who.role, "manager");
    assert.equal(who.scope, "all");
    assert.ok(who.caps.includes("users.view") && !who.caps.includes("users.create"));

    // Manager (scope all) sees the owner's user in the reseller-safe list.
    res = await fetch(srv.base + "/admin/users.json", get(mc));
    assert.equal(res.status, 200);
    const mlist = await res.json();
    assert.ok(mlist.users.some((u) => u.id === "owner_user"), "manager sees all users");
    // The reseller-safe projection carries no node secrets.
    for (const k of ["subToken", "admins", "reality", "cfToken", "relayKey"]) assert.ok(!(k in mlist), `users.json must not leak ${k}`);
    for (const inb of mlist.inbounds || []) for (const k of ["reality", "wgSecretKey", "raw"]) assert.ok(!(k in inb), `inbound projection must not leak ${k}`);

    // Manager lacking users.create is refused on create (per-action cap).
    res = await fetch(srv.base + "/admin/users.json", post({ action: "add", user: { name: "x", email: "x" } }, mc));
    assert.equal(res.status, 403, "read-only manager cannot create users");
    // ...and lacking traffic.view is refused on usage-data (route cap).
    res = await fetch(srv.base + "/admin/usage-data", get(mc));
    assert.equal(res.status, 403, "manager without traffic.view is blocked");

    // Reseller res-b sees only its own users (none yet, not the owner's).
    res = await fetch(srv.base + "/login", post({ password: "resbpass1" }));
    const rbc = cookieValue(res);
    const rlist = await (await fetch(srv.base + "/admin/users.json", get(rbc))).json();
    assert.ok(!rlist.users.some((u) => u.id === "owner_user"), "reseller list excludes the owner's user");
  } finally {
    await srv.close();
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("Telegram bot: inline-keyboard menu callbacks (no network)", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const { handleCallback } = await import("../src/telegram/bot.mjs");
  const { getSettings, putSettings, applyUserAction } = await import("../src/server.mjs");
  const opts = { managerOpts: { exec: false, configPath } };
  try {
    await setPassword(kv, "hunter2secret");
    await getSettings(kv);
    await putSettings(kv, { ...(await getSettings(kv)), host: "node.example.com" });
    await applyUserAction(kv, { action: "add", user: { id: "u_a", name: "alice", email: "alice" } }, opts);
    let s = await getSettings(kv);

    // Main menu + users list render as keyboards.
    assert.ok(Array.isArray((await handleCallback(kv, s, "menu", opts)).keyboard), "menu keyboard");
    const list = await handleCallback(kv, s, "users:0", opts);
    assert.ok(list.keyboard.flat().some((b) => b.callback_data === "user:u_a"), "user button present");

    // User detail -> disable via button.
    const detail = await handleCallback(kv, s, "user:u_a", opts);
    assert.ok(detail.keyboard.flat().some((b) => b.callback_data === "off:u_a"));
    const off = await handleCallback(kv, s, "off:u_a", opts);
    assert.equal(off.alert, "Disabled");
    assert.equal((await getSettings(kv)).users[0].enabled, false);

    // Reset traffic via button.
    await kv.put("uusage:u_a", "999");
    const r = await handleCallback(kv, s, "reset:u_a", opts);
    assert.equal(r.alert, "Traffic reset");
    assert.equal(await kv.get("uusage:u_a"), "0");

    // Add button asks for a name (force_reply prompt).
    assert.ok((await handleCallback(kv, s, "add", opts)).prompt, "add returns a name prompt");

    // Status button.
    assert.match((await handleCallback(kv, s, "status", opts)).text, /status/i);
  } finally {
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("Telegram bot: command router add/list/disable/reset (no network)", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const { handleCommand } = await import("../src/telegram/bot.mjs");
  const { getSettings, putSettings } = await import("../src/server.mjs");
  const opts = { managerOpts: { exec: false, configPath } };
  try {
    await setPassword(kv, "hunter2secret");
    await getSettings(kv); // materialize defaults
    await putSettings(kv, { ...(await getSettings(kv)), host: "node.example.com" });

    let s = await getSettings(kv);
    let out = await handleCommand(kv, s, "/help", opts);
    assert.match(out, /Nova node bot/);

    // /add creates a user and returns a sub link.
    out = await handleCommand(kv, s, "/add alice", opts);
    assert.match(out, /Added/);
    assert.match(out, /\/sub\?u=/);

    s = await getSettings(kv);
    assert.equal(s.users.length, 1);
    const id = s.users[0].id;

    // /users lists it.
    out = await handleCommand(kv, s, "/users", opts);
    assert.match(out, new RegExp(id));

    // /disable flips enabled.
    out = await handleCommand(kv, s, `/disable ${id}`, opts);
    assert.match(out, /Disabled/);
    s = await getSettings(kv);
    assert.equal(s.users[0].enabled, false);

    // /reset zeroes usage.
    await kv.put(`uusage:${id}`, "12345");
    out = await handleCommand(kv, s, `/reset ${id}`, opts);
    assert.match(out, /reset/i);
    assert.equal(await kv.get(`uusage:${id}`), "0");

    // Unknown command.
    out = await handleCommand(kv, s, "/frobnicate", opts);
    assert.match(out, /Unknown command/);
  } finally {
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("rejecting a user with no valid uuid does not brick the config (H4)", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  try {
    let res = await fetch(srv.base + "/install/set", {
      method: "POST",
      headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ password: "hunter2secret" }),
    });
    const cookie = cookieValue(res);

    // A network-settings POST with a malformed user must be rejected with 400.
    res = await fetch(srv.base + "/admin/network-settings.json", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "user-agent": UA,
        cookie: `auth=${cookie}`,
      },
      body: JSON.stringify({ users: [{ id: "bad", email: "bad" }] }),
    });
    assert.equal(res.status, 400);

    // An invalid wsPath is likewise rejected.
    res = await fetch(srv.base + "/admin/network-settings.json", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "user-agent": UA,
        cookie: `auth=${cookie}`,
      },
      body: JSON.stringify({ wsPath: "no-leading-slash and spaces" }),
    });
    assert.equal(res.status, 400);
  } finally {
    await srv.close();
    cleanup();
    try {
      rmSync(configPath);
    } catch {}
  }
});

test("concurrent user adds are serialized, none are lost (H1)", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = tmpConfig();
  try {
    await setPassword(kv, "hunter2secret");
    const N = 20;
    await Promise.all(
      Array.from({ length: N }, (_, i) =>
        applyUserAction(
          kv,
          { action: "add", user: { email: `u${i}` } },
          { managerOpts: { exec: false, configPath } },
        ),
      ),
    );
    const settings = await getSettings(kv);
    assert.equal(settings.users.length, N, "every concurrent add persisted");
  } finally {
    cleanup();
    try {
      rmSync(configPath);
    } catch {}
  }
});

test("usage accrues under the Nova id even when email != id (M1)", async () => {
  const { kv, cleanup } = freshKv();
  try {
    const users = [
      {
        id: "u_123",
        uuid: "44444444-4444-4444-8444-444444444444",
        email: "alice@example.com",
        enabled: true,
        quotaBytes: 1000,
      },
    ];
    const emailMap = new Map(users.map((u) => [u.email, u.id]));
    // xray reports under the email; accounting maps it back to the id.
    await accrue(
      kv,
      { "alice@example.com": { up: 600, down: 600 } },
      { emailToId: (e) => emailMap.get(e) || e },
    );

    // The quota check reads uusage:<id>; it must see the 1200 bytes.
    assert.equal(await kv.get("uusage:u_123"), "1200");
    // If accounting had landed under the email (the bug), this key would be set
    // and the id key would stay 0, so quota would never trip.
    assert.equal(await kv.get("uusage:alice@example.com"), null);

    const body = Buffer.from(
      await buildSub(users, { host: "node.example.com", kv }),
      "base64",
    ).toString("utf8");
    assert.equal(body, "", "over-quota user (accrued by email->id) must be hidden");
  } finally {
    cleanup();
  }
});

test("xray HandlerService add/remove use the v26.3.27 CLI forms (C1)", async () => {
  const configPath = tmpConfig();
  const user = {
    id: "u1",
    uuid: "55555555-5555-4555-8555-555555555555",
    email: "alice",
    enabled: true,
  };
  try {
    // --- add: prev empty -> next has one user -> `adu` with a JSON doc file ---
    let calls = [];
    let aduDoc = null;
    let runExec = async (bin, args) => {
      if (args.includes("adu")) {
        aduDoc = JSON.parse(readFileSync(args[args.length - 1], "utf8"));
      }
      calls.push({ bin, args });
      return { stdout: "" };
    };
    const addRes = await applyUsers([user], {
      exec: true,
      prev: [],
      runExec,
      configPath,
      apiAddr: "127.0.0.1:10085",
    });
    assert.equal(addRes.method, "hot");
    const adu = calls.find((c) => c.args.includes("adu"));
    assert.ok(adu, "adu was invoked");
    assert.deepEqual(adu.args.slice(0, 3), ["api", "adu", "--server=127.0.0.1:10085"]);
    // No -email/-uuid flags: adu reads the tag + clients from the doc.
    assert.ok(!adu.args.includes("-email"));
    assert.ok(!adu.args.includes("-uuid"));
    assert.equal(aduDoc.inbounds[0].tag, "vless-ws");
    assert.equal(aduDoc.inbounds[0].settings.clients[0].id, user.uuid);
    assert.equal(aduDoc.inbounds[0].settings.clients[0].email, "alice");

    // --- remove: prev has the user -> next empty -> `rmu -tag=... <email>` ---
    calls = [];
    runExec = async (bin, args) => {
      calls.push({ bin, args });
      return { stdout: "" };
    };
    const rmRes = await applyUsers([], {
      exec: true,
      prev: [user],
      runExec,
      configPath,
      apiAddr: "127.0.0.1:10085",
    });
    assert.equal(rmRes.method, "hot");
    const rmu = calls.find((c) => c.args.includes("rmu"));
    assert.ok(rmu, "rmu was invoked");
    assert.deepEqual(rmu.args, [
      "api",
      "rmu",
      "--server=127.0.0.1:10085",
      "-tag=vless-ws",
      "alice",
    ]);
  } finally {
    try {
      rmSync(configPath);
    } catch {}
  }
});

test("a config-only change forces a restart, not a silent no-op (H3)", async () => {
  const configPath = tmpConfig();
  const users = [
    { id: "u1", uuid: "66666666-6666-4666-8666-666666666666", email: "a", enabled: true },
  ];
  try {
    // forceReload (e.g. wsPath changed) with no user delta -> full restart.
    const calls = [];
    const res = await applyUsers(users, {
      exec: true,
      prev: users,
      forceReload: true,
      runExec: async (bin, args) => {
        calls.push({ bin, args });
        return { stdout: "" };
      },
      configPath,
    });
    assert.equal(res.method, "restart");
    assert.ok(
      calls.some((c) => c.bin === "systemctl" && c.args.join(" ") === "restart xray"),
      "config-only change must restart xray",
    );

    // No change and no forceReload -> nothing to do, no restart.
    const calls2 = [];
    const res2 = await applyUsers(users, {
      exec: true,
      prev: users,
      forceReload: false,
      runExec: async (bin, args) => {
        calls2.push({ bin, args });
        return { stdout: "" };
      },
      configPath,
    });
    assert.equal(res2.method, "unchanged");
    assert.ok(!calls2.some((c) => c.bin === "systemctl"), "no-op must not restart");
  } finally {
    try {
      rmSync(configPath);
    } catch {}
  }
});
