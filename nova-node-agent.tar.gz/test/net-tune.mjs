import { test } from "node:test";
import assert from "node:assert/strict";
import { applyBbr, readCongestion } from "../src/net-tune.mjs";

// Mock sysctl/modprobe: record calls, answer reads from a settable kernel state.
function mockExec(state = { current: "cubic", available: "reno cubic bbr" }) {
  const calls = [];
  const runExec = async (bin, args) => {
    calls.push([bin, args.join(" ")]);
    if (bin === "sysctl" && args[0] === "-n") {
      if (args[1] === "net.ipv4.tcp_congestion_control") return { stdout: state.current + "\n" };
      if (args[1] === "net.ipv4.tcp_available_congestion_control") return { stdout: state.available + "\n" };
    }
    if (bin === "sysctl" && args[0] === "-w") {
      const m = String(args[1]).match(/^net\.ipv4\.tcp_congestion_control=(.+)$/);
      if (m) state.current = m[1]; // model the kernel switching
    }
    return { stdout: "" };
  };
  return { runExec, calls, state };
}

test("readCongestion parses current + available and detects bbr", async () => {
  const { runExec } = mockExec({ current: "bbr", available: "reno cubic bbr" });
  const cc = await readCongestion({ runExec });
  assert.equal(cc.current, "bbr");
  assert.deepEqual(cc.available, ["reno", "cubic", "bbr"]);
  assert.equal(cc.bbr, true);
});

test("readCongestion reports bbr:false when the kernel lacks it", async () => {
  const { runExec } = mockExec({ current: "cubic", available: "reno cubic" });
  const cc = await readCongestion({ runExec });
  assert.equal(cc.bbr, false);
});

test("applyBbr(true) sets fq + bbr live and returns bbr", async () => {
  const m = mockExec({ current: "cubic", available: "reno cubic bbr" });
  const result = await applyBbr(true, { runExec: m.runExec });
  const joined = m.calls.map((c) => c.join(" "));
  assert.ok(joined.some((c) => c === "modprobe tcp_bbr"), "loads the module");
  assert.ok(joined.some((c) => c === "sysctl -w net.core.default_qdisc=fq"), "sets fq qdisc");
  assert.ok(joined.some((c) => c === "sysctl -w net.ipv4.tcp_congestion_control=bbr"), "sets bbr");
  assert.equal(result, "bbr");
});

test("applyBbr(false) resets to cubic", async () => {
  const m = mockExec({ current: "bbr", available: "reno cubic bbr" });
  const result = await applyBbr(false, { runExec: m.runExec });
  const joined = m.calls.map((c) => c.join(" "));
  assert.ok(joined.some((c) => c === "sysctl -w net.ipv4.tcp_congestion_control=cubic"), "resets to cubic");
  assert.equal(result, "cubic");
});

test("applyBbr never throws when sysctl is missing", async () => {
  const runExec = async () => { throw new Error("sysctl: not found"); };
  const result = await applyBbr(true, { runExec });
  assert.equal(result, ""); // no current readable, but no throw
});
