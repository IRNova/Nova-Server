import { test } from "node:test";
import assert from "node:assert/strict";

import { enumerateProxies, toClash, toSingbox } from "../src/sub-formats.mjs";
import { normalizeInbound, VISION_FLOW } from "../src/xray/inbounds.mjs";

const U = { id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "alice", enabled: true };
const reality = normalizeInbound({
  id: "rv", tag: "rv", protocol: "vless", network: "tcp", security: "reality", port: 8443, flow: VISION_FLOW, remark: "Reality",
  reality: { dest: "www.microsoft.com:443", serverNames: ["www.microsoft.com"], shortIds: ["0123abcd"], privateKey: "PRIV", publicKey: "PUBKEY" },
});

async function proxies() {
  return enumerateProxies([U], { host: "cf.example.com", directHost: "203.0.113.9", protocols: { vless: true }, inbounds: [reality] });
}

test("enumerateProxies yields the front proxy + one per assigned inbound", async () => {
  const ps = await proxies();
  assert.equal(ps.length, 2);
  assert.equal(ps[0].protocol, "vless");
  assert.equal(ps[0].server, "cf.example.com");
  const rv = ps[1];
  assert.equal(rv.server, "203.0.113.9");
  assert.equal(rv.port, 8443);
  assert.equal(rv.flow, VISION_FLOW);
  assert.equal(rv.reality.pbk, "PUBKEY");
});

test("toClash renders valid-looking YAML with a url-test group", async () => {
  const y = toClash(await proxies());
  assert.match(y, /^proxies:/m);
  assert.match(y, /type: vless/);
  assert.match(y, /reality-opts: \{public-key: "PUBKEY", short-id: "0123abcd"\}/);
  assert.match(y, /flow: "xtls-rprx-vision"/);
  assert.match(y, /proxy-groups:/);
  assert.match(y, /type: url-test/);
  assert.match(y, /rules:/);
});

test("toSingbox renders valid JSON with reality tls + selector/urltest", async () => {
  const j = JSON.parse(toSingbox(await proxies()));
  const tags = j.outbounds.map((o) => o.tag);
  assert.ok(tags.includes("Nova"));
  assert.ok(tags.includes("auto"));
  assert.ok(tags.includes("direct"));
  const rv = j.outbounds.find((o) => o.type === "vless" && o.server === "203.0.113.9");
  assert.equal(rv.flow, "xtls-rprx-vision");
  assert.equal(rv.tls.reality.enabled, true);
  assert.equal(rv.tls.reality.public_key, "PUBKEY");
  assert.equal(j.route.final, "Nova");
});
