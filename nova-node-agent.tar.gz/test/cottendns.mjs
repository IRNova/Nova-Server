// CottenDns DNS-tunnel engine: pure config/client helpers, plus the engine
// selector on /admin/dns-tunnel with the shell side stubbed (managerOpts.exec=false).
import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { rmSync } from "node:fs";

import { openKv } from "../src/kv/sqlite.mjs";
import { createServer } from "../src/server.mjs";
import {
  patchCottenConfig,
  buildCottenClientConfig,
  cottenClientInfo,
  COTTEN_DEFAULT_RESOLVERS,
} from "../src/cottendns.mjs";
import { DNS_ENC_METHODS } from "../src/masterdns.mjs";

const UA = "Nova/1.0.0 (desktop)";

// --- pure config helpers ----------------------------------------------------

test("patchCottenConfig patches the shipped config and forces safe listeners", () => {
  const template = [
    'CONFIG_VERSION = "default"',
    'DOMAIN = ["v.domain.com"]',
    'PROTOCOL_TYPE = "SOCKS5"',
    'UDP_HOST = "0.0.0.0"',
    'UDP_PORT = 53',
    'DOH_COEXIST_MODE = "auto"',
    'DOT_LISTENER_ENABLED = false',
    'DOH_LISTENER_ENABLED = false',
    'DATA_ENCRYPTION_METHOD = 3',
    'ENCRYPTION_KEY_FILE = "encrypt_key.txt"',
    'SOME_KNOB = 99',
  ].join("\n");
  const out = patchCottenConfig(template, { domain: "dns.example.com", protocol: "SOCKS5", udpHost: "203.0.113.9", encMethod: DNS_ENC_METHODS["aes-256-gcm"] });
  assert.match(out, /^CONFIG_VERSION = "default"$/m);
  assert.match(out, /^DOMAIN = \["dns\.example\.com"\]$/m);
  assert.match(out, /^UDP_HOST = "203\.0\.113\.9"$/m, "binds the public IP");
  assert.match(out, /^TCP_LISTENER_ENABLED = true$/m, "TCP/53 fallback stays on");
  assert.match(out, /^DATA_ENCRYPTION_METHOD = 5$/m);
  // Must never take :443: DoH coexist stays auto, TLS listeners off.
  assert.match(out, /^DOH_COEXIST_MODE = "auto"$/m);
  assert.match(out, /^DOT_LISTENER_ENABLED = false$/m);
  assert.match(out, /^DOH_LISTENER_ENABLED = false$/m);
  assert.match(out, /^SOME_KNOB = 99$/m, "leaves unrelated knobs alone");
  assert.equal((out.match(/^DOMAIN =/mg) || []).length, 1, "patched in place, not duplicated");
});

test("patchCottenConfig sets FORWARD_* only for TCP; rejects a bad domain", () => {
  const tcp = patchCottenConfig('CONFIG_VERSION = "default"\n', { domain: "dns.example.com", protocol: "TCP", forwardIp: "127.0.0.1", forwardPort: 8388 });
  assert.match(tcp, /^PROTOCOL_TYPE = "TCP"$/m);
  assert.match(tcp, /^FORWARD_IP = "127\.0\.0\.1"$/m);
  assert.match(tcp, /^FORWARD_PORT = 8388$/m);
  const socks = patchCottenConfig('CONFIG_VERSION = "default"\n', { domain: "dns.example.com", protocol: "SOCKS5" });
  assert.ok(!/FORWARD_IP/.test(socks), "no forward keys in SOCKS5 mode");
  assert.throws(() => patchCottenConfig("", { domain: "not-a-domain" }), /invalid tunnel domain/);
});

test("buildCottenClientConfig + cottenClientInfo carry the matching key/method/domain", () => {
  const cfg = buildCottenClientConfig({ domain: "dns.example.com", key: "SECRETKEY", encMethod: DNS_ENC_METHODS.chacha20, protocol: "SOCKS5", localPort: 18000 });
  assert.match(cfg, /DOMAINS = \["dns\.example\.com"\]/);
  assert.match(cfg, /DATA_ENCRYPTION_METHOD = 2/);
  assert.match(cfg, /ENCRYPTION_KEY = "SECRETKEY"/);
  assert.match(cfg, /LISTEN_PORT = 18000/);
  // Default resolvers are listed for the companion client_resolvers.txt.
  for (const r of COTTEN_DEFAULT_RESOLVERS) assert.ok(cfg.includes(r), `resolver ${r} present`);

  const info = cottenClientInfo({ domain: "dns.example.com", key: "SECRETKEY", encMethod: 2, protocol: "SOCKS5", localPort: 18000 });
  assert.equal(info.encryptionMethod, "chacha20");
  assert.equal(info.encryptionKey, "SECRETKEY");
  assert.equal(info.localSocks, "127.0.0.1:18000");
  assert.ok(Array.isArray(info.resolvers) && info.resolvers.length > 0);
});

// --- endpoint engine selector (shell stubbed via exec:false) ----------------

function startServer(kv) {
  const configPath = join(tmpdir(), `nova-ct-${randomBytes(6).toString("hex")}.json`);
  const server = createServer(kv, { managerOpts: { exec: false, configPath } });
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      resolve({ base: `http://127.0.0.1:${server.address().port}`, close: () => new Promise((r) => server.close(r)), configPath });
    });
  });
}
function freshKv() {
  const path = join(tmpdir(), `nova-ct-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return { kv, cleanup() { kv.close(); for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} } } };
}
function cookieValue(res) { const m = /(?:^|,\s*)auth=([^;]+)/.exec(res.headers.get("set-cookie") || ""); return m ? m[1] : null; }

test("/admin/dns-tunnel: engine selector defaults to masterdns and switches to cottendns", async () => {
  const { kv, cleanup } = freshKv();
  const srv = await startServer(kv);
  try {
    let res = await fetch(srv.base + "/install/set", { method: "POST", headers: { "content-type": "application/json", "user-agent": UA }, body: JSON.stringify({ password: "hunter2secret" }) });
    const auth = { cookie: `auth=${cookieValue(res)}`, "user-agent": UA, "content-type": "application/json" };

    // Fresh state: engine defaults to masterdns, both engines advertised.
    let d = await (await fetch(srv.base + "/admin/dns-tunnel", { headers: auth })).json();
    assert.equal(d.config.engine, "masterdns");
    assert.deepEqual(d.engines, ["masterdns", "cottendns"]);

    // Enable with the cottendns engine; it persists as the selected engine.
    res = await fetch(srv.base + "/admin/dns-tunnel", { method: "POST", headers: auth, body: JSON.stringify({ action: "enable", engine: "cottendns", domain: "dns.example.com", protocol: "SOCKS5", encMethod: 5 }) });
    assert.equal(res.status, 200, await res.text());
    d = await (await fetch(srv.base + "/admin/dns-tunnel", { headers: auth })).json();
    assert.equal(d.config.engine, "cottendns");
    assert.equal(d.config.enabled, true);
    assert.equal(d.config.domain, "dns.example.com");

    // Switch back to masterdns; the selected engine follows.
    res = await fetch(srv.base + "/admin/dns-tunnel", { method: "POST", headers: auth, body: JSON.stringify({ action: "enable", engine: "masterdns", domain: "dns.example.com", protocol: "SOCKS5", encMethod: 2 }) });
    assert.equal(res.status, 200);
    d = await (await fetch(srv.base + "/admin/dns-tunnel", { headers: auth })).json();
    assert.equal(d.config.engine, "masterdns");

    // An unknown engine value falls back to masterdns (not an error).
    res = await fetch(srv.base + "/admin/dns-tunnel", { method: "POST", headers: auth, body: JSON.stringify({ action: "enable", engine: "bogus", domain: "dns.example.com" }) });
    assert.equal(res.status, 200);
    d = await (await fetch(srv.base + "/admin/dns-tunnel", { headers: auth })).json();
    assert.equal(d.config.engine, "masterdns");

    // Disable clears the flag (engine choice is retained).
    res = await fetch(srv.base + "/admin/dns-tunnel", { method: "POST", headers: auth, body: JSON.stringify({ action: "disable" }) });
    assert.equal(res.status, 200);
    d = await (await fetch(srv.base + "/admin/dns-tunnel", { headers: auth })).json();
    assert.equal(d.config.enabled, false);
  } finally {
    await srv.close(); cleanup();
    try { rmSync(srv.configPath); } catch {}
  }
});
