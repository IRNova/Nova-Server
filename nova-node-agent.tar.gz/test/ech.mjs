import test from "node:test";
import assert from "node:assert/strict";
import { extractPemBlock, parseEchKeypair, generateEch } from "../src/singbox/ech.mjs";
import { enumerateProxies, toSingbox, toClash } from "../src/sub-formats.mjs";
import { normalizeInbound } from "../src/xray/inbounds.mjs";

const KEYGEN_OUT = [
  "-----BEGIN ECH CONFIGS-----",
  "AEb+DQBCAAAgACA/SOwlKfL05DMUMKXCEW+RNzj/H4h6DcbpWK652genQgAMAAEA",
  "AQABAAIAAQADAAtleGFtcGxlLmNvbQAA",
  "-----END ECH CONFIGS-----",
  "-----BEGIN ECH KEYS-----",
  "ACCpr1odx+1JhQwwBhyySpx3/0FDyyuNouTTKVS0nQEXjQBG/g0AQgAAIAAgP0js",
  "-----END ECH KEYS-----",
].join("\n");

const U = { id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "a", name: "a", enabled: true };
const hy2 = (over = {}) => normalizeInbound({ id: "h1", tag: "hy1", protocol: "hysteria2", port: 443, sni: "exit.example.com", ...over });

test("parseEchKeypair splits the public config from the private key", () => {
  const kp = parseEchKeypair(KEYGEN_OUT);
  assert.equal(kp.config[0], "-----BEGIN ECH CONFIGS-----");
  assert.equal(kp.config[kp.config.length - 1], "-----END ECH CONFIGS-----");
  assert.equal(kp.key[0], "-----BEGIN ECH KEYS-----");
  assert.equal(kp.key[kp.key.length - 1], "-----END ECH KEYS-----");
  assert.deepEqual(extractPemBlock("nope", "ECH KEYS"), []);
});

test("generateEch rejects a hostile server name and never throws", async () => {
  assert.equal(await generateEch("a.com; reboot", { runExec: async () => ({ stdout: KEYGEN_OUT }) }), null);
  assert.equal(await generateEch("good.example.com", { runExec: async () => { throw new Error("no binary"); } }), null);
  const kp = await generateEch("good.example.com", { runExec: async () => ({ stdout: KEYGEN_OUT }) });
  assert.ok(kp && kp.config.length && kp.key.length);
});

test("a hy2 inbound with hopping+obfs+ECH renders a full sing-box outbound", async () => {
  const inb = hy2({ hopStart: 40000, hopEnd: 50000, hopInterval: 60, obfsType: "salamander", obfsPassword: "sekret", ech: true, echConfig: parseEchKeypair(KEYGEN_OUT).config });
  const proxies = await enumerateProxies([U], { host: "exit.example.com", directHost: "203.0.113.9", inbounds: [inb], protocols: {} });
  const hp = proxies.find((p) => p.protocol === "hysteria2");
  assert.ok(hp, "hy2 now enumerated for the sing-box format");
  const sb = toSingbox([hp], { net: {} });
  assert.match(sb, /"server_ports":\s*\[\s*"40000:50000"\s*\]/);
  assert.match(sb, /"hop_interval":\s*"60s"/);
  assert.match(sb, /"salamander"/);
  assert.match(sb, /"ech":/);
  assert.match(sb, /BEGIN ECH CONFIGS/);
  assert.doesNotMatch(sb, /ECH KEYS/, "the private key never reaches a client config");
});

test("Clash carries hy2 hopping+obfs but not ECH", async () => {
  const inb = hy2({ hopStart: 40000, hopEnd: 50000, obfsType: "salamander", obfsPassword: "s", ech: true, echConfig: parseEchKeypair(KEYGEN_OUT).config });
  const proxies = await enumerateProxies([U], { host: "exit.example.com", directHost: "203.0.113.9", inbounds: [inb], protocols: {} });
  const clash = toClash(proxies.filter((p) => p.protocol === "hysteria2"), { net: {} });
  assert.match(clash, /ports: "40000-50000"/);
  assert.match(clash, /obfs: salamander/);
  assert.doesNotMatch(clash, /ech/i);
});
