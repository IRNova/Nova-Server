// /admin/dashboard + /admin/activity through the real server (exec off).
import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { rmSync } from "node:fs";

import { openKv } from "../src/kv/sqlite.mjs";
import { createServer } from "../src/server.mjs";

const UA = "Nova/1.0.0 (desktop; sing-box)";

function startServer(kv, opts) {
  const server = createServer(kv, opts);
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      resolve({ base: `http://127.0.0.1:${port}`, close: () => new Promise((r) => server.close(r)) });
    });
  });
}
function freshKv() {
  const path = join(tmpdir(), `nova-dash-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return { kv, cleanup() { kv.close(); for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} } } };
}
function cookieValue(res) {
  const m = /(?:^|,\s*)auth=([^;]+)/.exec(res.headers.get("set-cookie") || "");
  return m ? m[1] : null;
}

test("dashboard: real system stats + a 14-day traffic series + counts; login shows in activity", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-dash-cfg-${randomBytes(6).toString("hex")}.json`);
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  try {
    // Seed some daily usage so the series has data.
    const today = new Date().toISOString().slice(0, 10);
    await kv.put(`uusage:me`, "5000");
    await kv.put(`uusage-d:me:${today}`, "1500");

    let res = await fetch(srv.base + "/install/set", {
      method: "POST", headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ password: "hunter2secret" }),
    });
    const cookie = cookieValue(res);
    const auth = { cookie: `auth=${cookie}`, "user-agent": UA };

    res = await fetch(srv.base + "/admin/dashboard", { headers: auth });
    assert.equal(res.status, 200);
    const d = await res.json();
    assert.ok(d.system.cpu.cores >= 1, "cpu cores");
    assert.ok(d.system.mem.total > 0, "mem total");
    assert.equal(d.traffic.total, 5000);
    assert.equal(d.traffic.today, 1500);
    assert.equal(d.traffic.series.length, 14);
    assert.equal(d.traffic.series[13].date, today);
    assert.equal(d.traffic.series[13].bytes, 1500);

    // Sign in was recorded in the activity log.
    await fetch(srv.base + "/login", {
      method: "POST", headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ password: "hunter2secret" }),
    });
    res = await fetch(srv.base + "/admin/activity", { headers: auth });
    const act = (await res.json()).activity;
    assert.ok(act.some((a) => a.action.startsWith("Admin sign in")), "login logged");
  } finally {
    await srv.close();
    cleanup();
  }
});
