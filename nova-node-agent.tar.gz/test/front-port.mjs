import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSub } from "../src/subscription.mjs";
const decode = (b) => Buffer.from(b, "base64").toString("utf8");
const user = (e) => ({ id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "u1", enabled: true, ...e });

test("front links carry NOVA_FRONT_PORT when 443 is taken", async () => {
  process.env.NOVA_FRONT_PORT = "4430";
  try {
    const sub = decode(await buildSub([user({})], { host: "h.example.com", protocols: { vless: true } }));
    assert.match(sub, /@h\.example\.com:4430/);
    assert.doesNotMatch(sub, /@h\.example\.com:443\b/);
  } finally { delete process.env.NOVA_FRONT_PORT; }
});
test("front stays on 443 when NOVA_FRONT_PORT is unset", async () => {
  const sub = decode(await buildSub([user({})], { host: "h.example.com", protocols: { vless: true } }));
  assert.match(sub, /@h\.example\.com:443/);
});
