import test from "node:test";
import assert from "node:assert/strict";
import { hy2HopSpecs, hopRuleArgs, applyHy2Hop, HOP_CHAIN } from "../src/singbox/porthop.mjs";
import { buildSub } from "../src/subscription.mjs";
import { normalizeInbound } from "../src/xray/inbounds.mjs";

const U = { id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "alice", name: "alice", enabled: true };

test("a hy2 inbound with a hop range carries mport in its subscription link", async () => {
  const hop = normalizeInbound({ id: "h1", tag: "hy1", protocol: "hysteria2", port: 443, remark: "HY", hopStart: 20000, hopEnd: 40000 });
  const plain = normalizeInbound({ id: "h2", tag: "hy2", protocol: "hysteria2", port: 8443, remark: "HYP" });
  const body = Buffer.from(await buildSub([U], {
    host: "h", directHost: "203.0.113.9", insecure: true,
    protocols: { vless: true }, inbounds: [hop, plain],
  }), "base64").toString("utf8");
  assert.match(body, /hysteria2:\/\/[^\n]*@203\.0\.113\.9:443[^\n]*mport=20000-40000/, "ranged inbound emits mport");
  assert.doesNotMatch(body, /@203\.0\.113\.9:8443[^\n]*mport=/, "the non-hopping inbound has no mport");
});

test("an out-of-range hop bound is clamped so the sub and firewall cannot drift", async () => {
  const bad = normalizeInbound({ id: "h3", tag: "hy3", protocol: "hysteria2", port: 443, hopStart: 20000, hopEnd: 99999 });
  assert.equal(bad.hopEnd, 65535, "hopEnd clamps to a valid port");
  const body = Buffer.from(await buildSub([U], {
    host: "h", directHost: "203.0.113.9", protocols: { vless: true }, inbounds: [bad],
  }), "base64").toString("utf8");
  // The advertised range matches exactly what hy2HopSpecs/the firewall will accept.
  assert.match(body, /mport=20000-65535/);
  assert.deepEqual(hy2HopSpecs([bad]), [{ start: 20000, end: 65535, toPort: 443 }]);
});

test("hy2HopSpecs keeps valid hy2 ranges, normalizes, dedupes, drops the rest", () => {
  const specs = hy2HopSpecs([
    { protocol: "hysteria2", port: 443, hopStart: 20000, hopEnd: 40000 },  // valid
    { protocol: "hysteria2", port: 8443, hopStart: 40000, hopEnd: 20000 }, // reversed -> normalized
    { protocol: "hysteria2", port: 443, hopStart: 20000, hopEnd: 40000 },  // duplicate of #1
    { protocol: "hysteria2", port: 2000, hopStart: 5000, hopEnd: 5000 },   // single port, not a range
    { protocol: "hysteria2", port: 2000, hopStart: 0, hopEnd: 0 },         // off
    { protocol: "tuic", port: 900, hopStart: 1000, hopEnd: 2000 },         // not hysteria2
    { protocol: "hysteria2", port: 70000, hopStart: 1, hopEnd: 2 },        // invalid listen port
  ]);
  assert.deepEqual(specs, [
    { start: 20000, end: 40000, toPort: 443 },
    { start: 20000, end: 40000, toPort: 8443 },
  ]);
});

test("hopRuleArgs builds a scoped REDIRECT into Nova's own chain", () => {
  assert.deepEqual(
    hopRuleArgs({ start: 20000, end: 40000, toPort: 443 }),
    ["-t", "nat", "-A", HOP_CHAIN, "-p", "udp", "--dport", "20000:40000", "-j", "REDIRECT", "--to-ports", "443"],
  );
});

test("applyHy2Hop only ever touches Nova's own chain, and flushes it when empty", async () => {
  const calls = [];
  const runExec = (bin, args) => { calls.push([bin, ...args].join(" ")); return Promise.resolve({ stdout: "" }); };

  await applyHy2Hop([{ start: 20000, end: 40000, toPort: 443 }], { runExec, allowUfw: false });
  // PREROUTING is only ever referenced to check/add the jump to OUR chain.
  assert.ok(calls.filter(s => s.includes("PREROUTING")).every(s => s.includes(HOP_CHAIN)));
  assert.ok(calls.some(s => s.includes(`-A ${HOP_CHAIN} -p udp --dport 20000:40000`)));
  assert.ok(calls.some(s => s.includes(`-F ${HOP_CHAIN}`)), "rebuilds by flushing our chain");
  // Never flushes or deletes a builtin chain.
  assert.ok(!calls.some(s => /-(F|X) (PREROUTING|POSTROUTING|OUTPUT)\b/.test(s)));

  // Empty specs => flush only, no redirect rules.
  calls.length = 0;
  await applyHy2Hop([], { runExec, allowUfw: false });
  assert.ok(calls.some(s => s.includes(`-F ${HOP_CHAIN}`)), "empty specs flush the chain");
  assert.ok(!calls.some(s => s.includes("REDIRECT")), "empty specs add no redirect");
});

test("applyHy2Hop never throws when the firewall tool is missing", async () => {
  const runExec = () => Promise.reject(new Error("iptables: command not found"));
  await applyHy2Hop([{ start: 20000, end: 40000, toPort: 443 }], { runExec });
  // Reaching here without throwing is the assertion.
  assert.ok(true);
});
