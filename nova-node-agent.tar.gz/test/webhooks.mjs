// Outbound webhooks: normalize, event selection, signing, and dispatch shape.
import { test } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";

import {
  WEBHOOK_EVENTS,
  normalizeWebhook,
  selectWebhooks,
  signPayload,
  dispatchWebhooks,
} from "../src/webhooks.mjs";

test("normalizeWebhook fills defaults + filters unknown events", () => {
  const w = normalizeWebhook({ url: "  https://x.test/hook  ", events: ["user.created", "bogus", "user.created"] });
  assert.ok(w.id.startsWith("wh_"));
  assert.equal(w.url, "https://x.test/hook");
  assert.deepEqual(w.events, ["user.created"]); // deduped, bogus dropped
  assert.equal(w.enabled, true);
});

test("selectWebhooks: empty events = all, and disabled/urlless are skipped", () => {
  const hooks = [
    { id: "a", url: "https://a.test", events: [], enabled: true },
    { id: "b", url: "https://b.test", events: ["user.deleted"], enabled: true },
    { id: "c", url: "https://c.test", events: ["user.created"], enabled: false },
    { id: "d", url: "", events: [], enabled: true },
  ];
  const forCreated = selectWebhooks(hooks, "user.created").map((w) => w.id);
  assert.deepEqual(forCreated, ["a"]); // a=all; b=other event; c=disabled; d=no url
  const forDeleted = selectWebhooks(hooks, "user.deleted").map((w) => w.id);
  assert.deepEqual(forDeleted.sort(), ["a", "b"]);
});

test("signPayload is a verifiable HMAC-SHA256", () => {
  const body = JSON.stringify({ hello: "world" });
  const sig = signPayload("s3cret", body);
  const expected = "sha256=" + createHmac("sha256", "s3cret").update(body).digest("hex");
  assert.equal(sig, expected);
});

test("dispatchWebhooks POSTs to matching hooks with signature + payload", async () => {
  const calls = [];
  const fetchImpl = async (url, opts) => {
    calls.push({ url, opts });
    return { ok: true, status: 200 };
  };
  const hooks = [
    { id: "a", url: "https://a.test/hook", secret: "k", events: ["user.created"], enabled: true },
    { id: "b", url: "https://b.test/hook", events: ["user.deleted"], enabled: true },
  ];
  const now = new Date("2026-01-02T03:04:05.000Z");
  const r = dispatchWebhooks(hooks, "user.created", { id: "u1" }, { fetchImpl, node: "vpn.example", now });
  assert.equal(r.count, 1);
  await Promise.all(r.sent);
  assert.equal(calls.length, 1);
  const c = calls[0];
  assert.equal(c.url, "https://a.test/hook");
  assert.equal(c.opts.method, "POST");
  assert.equal(c.opts.headers["x-nova-event"], "user.created");
  assert.equal(c.opts.headers["x-nova-signature"], signPayload("k", c.opts.body));
  const payload = JSON.parse(c.opts.body);
  assert.deepEqual(payload, {
    event: "user.created",
    timestamp: "2026-01-02T03:04:05.000Z",
    node: "vpn.example",
    data: { id: "u1" },
  });
});

test("dispatchWebhooks swallows a failing endpoint (never throws)", async () => {
  const fetchImpl = async () => { throw new Error("connection refused"); };
  const hooks = [{ id: "a", url: "https://dead.test", events: [], enabled: true }];
  const r = dispatchWebhooks(hooks, "login.banned", { ip: "1.2.3.4" }, { fetchImpl });
  assert.equal(r.count, 1);
  await Promise.all(r.sent); // resolves despite the throw
});

test("WEBHOOK_EVENTS covers the wired events", () => {
  for (const e of ["user.created", "user.updated", "user.deleted", "user.expired", "user.quota", "node.enrolled", "login.banned", "tunnel.failed", "tunnel.recovered"]) {
    assert.ok(WEBHOOK_EVENTS.includes(e), `missing ${e}`);
  }
});
