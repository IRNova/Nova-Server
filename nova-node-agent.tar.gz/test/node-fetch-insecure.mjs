// Regression: reaching a no-domain (self-signed) child node must NOT depend on
// `import("undici")`. undici powers Node's global fetch but is not an importable
// bare module in a dependency-free runtime, so the old dispatcher threw
// "Cannot find package 'undici'" and every self-signed node failed to enroll
// ("could not reach the node back"). nodeFetch now uses node:https with
// rejectUnauthorized:false, so this must work with only Node built-ins.
import { test } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:https";
import { execSync } from "node:child_process";
import { readFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { nodeFetch, pingNode } from "../src/nodes.mjs";

function selfSignedServer(handler) {
  const d = mkdtempSync(join(tmpdir(), "nf-"));
  execSync(`openssl req -x509 -newkey rsa:2048 -nodes -keyout ${d}/k.pem -out ${d}/c.pem -days 1 -subj "/CN=test" >/dev/null 2>&1`);
  const srv = createServer({ key: readFileSync(`${d}/k.pem`), cert: readFileSync(`${d}/c.pem`) }, handler);
  return srv;
}

test("nodeFetch reaches a self-signed https node with insecure:true (no undici)", async () => {
  const srv = selfSignedServer((req, res) => {
    if (req.url === "/api/v1/health") {
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify({ ok: true, role: "owner" }));
    } else {
      res.writeHead(404); res.end("{}");
    }
  });
  await new Promise((r) => srv.listen(0, "127.0.0.1", r));
  const port = srv.address().port;
  try {
    const node = { url: `https://127.0.0.1:${port}`, apiToken: "x", insecure: true };
    const h = await nodeFetch(node, "/health");
    assert.deepEqual(h, { ok: true, role: "owner" });
    const ping = await pingNode(node);
    assert.equal(ping.ok, true);
    assert.equal(ping.role, "owner");
  } finally {
    srv.close();
  }
});

test("nodeFetch refuses cleartext http:// to a REMOTE host (owner token must not go over the wire)", async () => {
  await assert.rejects(
    nodeFetch({ url: "http://198.51.100.10:8080", apiToken: "secret" }, "/health"),
    /must be https/,
  );
  // A remote host merely NAMED like loopback must NOT slip through the carve-out.
  for (const bad of ["http://127.0.0.1.evil.com/", "http://127.evil.com/", "http://127.0.0.1x.evil.com/"]) {
    await assert.rejects(nodeFetch({ url: bad, apiToken: "secret" }, "/health"), /must be https/, bad);
  }
  // ...but loopback http is allowed (never leaves the machine; used by tests/tooling).
  const srv = (await import("node:http")).createServer((req, res) => {
    res.writeHead(200, { "content-type": "application/json" }); res.end('{"ok":true}');
  });
  await new Promise((r) => srv.listen(0, "127.0.0.1", r));
  try {
    const r = await nodeFetch({ url: `http://127.0.0.1:${srv.address().port}`, apiToken: "x" }, "/health");
    assert.deepEqual(r, { ok: true });
  } finally { srv.close(); }
});

test("pingNode reports ok:false with a message when the node is unreachable", async () => {
  // Closed local port: instant ECONNREFUSED, no waiting on a timeout.
  const ping = await pingNode({ url: "https://127.0.0.1:1", apiToken: "x", insecure: true });
  assert.equal(ping.ok, false);
  assert.ok(typeof ping.error === "string" && ping.error.length > 0);
  assert.ok(!/undici/i.test(ping.error), "must not fail due to a missing undici import");
});
