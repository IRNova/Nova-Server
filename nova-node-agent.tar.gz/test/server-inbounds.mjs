// Exercises the /admin/inbounds CRUD + keygen endpoints end to end through the
// real node:http server, with xray shell-outs no-op'd (managerOpts.exec=false).
import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { rmSync } from "node:fs";

import { openKv } from "../src/kv/sqlite.mjs";
import { createServer } from "../src/server.mjs";

const UA = "Nova/1.0.0 (desktop; sing-box)";

function startServer(kv, opts) {
  const server = createServer(kv, opts);
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      resolve({ base: `http://127.0.0.1:${port}`, close: () => new Promise((r) => server.close(r)) });
    });
  });
}
function freshKv() {
  const path = join(tmpdir(), `nova-inb-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return { kv, cleanup() { kv.close(); for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} } } };
}
function cookieValue(res) {
  const m = /(?:^|,\s*)auth=([^;]+)/.exec(res.headers.get("set-cookie") || "");
  return m ? m[1] : null;
}

test("inbounds: create a Reality inbound (keys auto-generated), then /sub emits its link", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-inb-cfg-${randomBytes(6).toString("hex")}.json`);
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  try {
    let res = await fetch(srv.base + "/install/set", {
      method: "POST",
      headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ password: "hunter2secret" }),
    });
    const cookie = cookieValue(res);
    const auth = { cookie: `auth=${cookie}`, "user-agent": UA, "content-type": "application/json" };

    // Give the node a host + a user.
    await fetch(srv.base + "/admin/network-settings.json", {
      method: "POST", headers: auth,
      body: JSON.stringify({ host: "203.0.113.9", insecure: true, protocols: { vless: true } }),
    });
    await fetch(srv.base + "/admin/users.json", {
      method: "POST", headers: auth,
      body: JSON.stringify({ action: "add", user: { id: "me", uuid: "11111111-1111-4111-8111-111111111111", email: "me", enabled: true } }),
    });

    // Reality keygen endpoint works.
    res = await fetch(srv.base + "/admin/reality-keys", { method: "POST", headers: auth });
    const keys = await res.json();
    assert.match(keys.privateKey, /^[A-Za-z0-9_-]{43}$/);
    assert.match(keys.shortId, /^[0-9a-f]+$/);

    // Add a Reality-Vision inbound WITHOUT keys; the server fills them in.
    res = await fetch(srv.base + "/admin/inbounds", {
      method: "POST", headers: auth,
      body: JSON.stringify({
        action: "add",
        inbound: {
          id: "rv", protocol: "vless", network: "tcp", security: "reality", port: 8443,
          flow: "xtls-rprx-vision", remark: "Reality",
          reality: { serverNames: ["www.microsoft.com"] },
        },
      }),
    });
    assert.equal(res.status, 200);
    const body = await res.json();
    const saved = body.saved;
    assert.ok(saved.reality.privateKey && saved.reality.publicKey, "keys auto-generated");
    assert.ok(saved.reality.dest, "dest derived from serverNames");
    assert.ok(saved.reality.shortIds.length, "shortId generated");

    // GET reflects it.
    res = await fetch(srv.base + "/admin/inbounds", { headers: { cookie: `auth=${cookie}`, "user-agent": UA } });
    const list = (await res.json()).inbounds;
    assert.equal(list.length, 1);
    assert.equal(list[0].port, 8443);

    // The subscription now carries a reality link on the direct host + port.
    const s = await (await fetch(srv.base + "/admin/network-settings.json", { headers: { cookie: `auth=${cookie}`, "user-agent": UA } })).json();
    res = await fetch(`${srv.base}/sub?token=${s.subToken}`);
    const sub = Buffer.from(await res.text(), "base64").toString("utf8");
    const lines = sub.split("\n").filter(Boolean);
    assert.ok(lines.some((l) => l.includes("203.0.113.9:8443") && l.includes("security=reality") && l.includes("flow=xtls-rprx-vision")));
  } finally {
    await srv.close();
    cleanup();
  }
});

test("inbounds: a port that collides with the front (443) is rejected", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-inb-cfg-${randomBytes(6).toString("hex")}.json`);
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  try {
    const res0 = await fetch(srv.base + "/install/set", {
      method: "POST", headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({ password: "hunter2secret" }),
    });
    const cookie = cookieValue(res0);
    const auth = { cookie: `auth=${cookie}`, "user-agent": UA, "content-type": "application/json" };
    const res = await fetch(srv.base + "/admin/inbounds", {
      method: "POST", headers: auth,
      body: JSON.stringify({ action: "add", inbound: { id: "x", protocol: "vless", network: "grpc", security: "tls", sni: "a.b", port: 443, serviceName: "n" } }),
    });
    assert.equal(res.status, 409);
    assert.match((await res.json()).error, /front port/);
  } finally {
    await srv.close();
    cleanup();
  }
});
