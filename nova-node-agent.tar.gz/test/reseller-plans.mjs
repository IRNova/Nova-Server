// Reseller quality gate: a reseller can ONLY provision users through a plan the
// owner marked sellable (so they can't sell the bare free front), the user's
// config is taken from the plan (not the client), and each provisioning charges
// the reseller's prepaid balance. The owner stays free-form and uncharged.
import { test } from "node:test";
import assert from "node:assert/strict";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import { openKv } from "../src/kv/sqlite.mjs";
import { applyUserAction, getSettings, putSettings } from "../src/server.mjs";

// No xray shell-outs, and write the generated config to a temp path (not the
// system /usr/local/etc/xray, which the test user can't create).
const OPTS = { managerOpts: { exec: false, configPath: join(tmpdir(), `nova-rsl-cfg-${randomBytes(6).toString("hex")}.json`) } };
const RESELLER = { id: "r1", role: "reseller", ownerId: "r1" };

async function freshKv(balance = 10) {
  const kv = await openKv(join(tmpdir(), `nova-rsl-${randomBytes(6).toString("hex")}.db`));
  await putSettings(kv, {
    host: "h.example.com", wsPath: "/nova", subToken: "t",
    protocols: { vless: true }, inbounds: [], users: [],
    admins: [{ id: "r1", role: "reseller", balance }],
    userTemplates: [
      // A real, sellable plan: 50 GB, 30 days, 2 devices, on node nd1.
      { id: "pl1", name: "Premium", sellable: true, price: 3, volumeGB: 50, expireDays: 30, deviceLimit: 2, nodeIds: ["nd1"], inboundIds: ["in-a"] },
      // A plan the owner did NOT mark sellable.
      { id: "pl0", name: "Draft", sellable: false, price: 0, volumeGB: 10 },
    ],
  });
  return kv;
}
const balOf = async (kv) => (await getSettings(kv)).admins.find((a) => a.id === "r1").balance;

test("reseller provisions a sellable plan -> plan config applied, balance charged", async () => {
  const kv = await freshKv(10);
  const { user } = await applyUserAction(kv, { action: "add", user: { name: "cust1", planId: "pl1" } }, OPTS, RESELLER);
  assert.equal(user.planId, "pl1");
  assert.equal(user.quotaBytes, 50 * 1024 ** 3, "quota from plan");
  assert.equal(user.deviceLimit, 2, "device limit from plan");
  assert.deepEqual(user.nodeIds, ["nd1"], "node grant from plan");
  assert.deepEqual(user.inboundIds, ["in-a"], "protocol grant from plan");
  assert.equal(user.ownerId, "r1", "stamped to the reseller");
  assert.equal(await balOf(kv), 7, "balance 10 -> 7 (price 3)");
});

test("reseller CANNOT sell the free front: client-supplied caps are ignored, plan wins", async () => {
  const kv = await freshKv(10);
  // Reseller tries to hand out a free-form config (no node, huge quota, no plan fields).
  const { user } = await applyUserAction(kv, { action: "add", user: { name: "c", planId: "pl1", quotaBytes: 999, nodeIds: [], inboundIds: ["front:vless"], deviceLimit: 99 } }, OPTS, RESELLER);
  assert.equal(user.quotaBytes, 50 * 1024 ** 3, "client quota ignored");
  assert.deepEqual(user.nodeIds, ["nd1"], "client node override ignored");
  assert.deepEqual(user.inboundIds, ["in-a"], "client can't downgrade to the free front");
  assert.equal(user.deviceLimit, 2, "client device override ignored");
});

test("reseller add with NO plan is rejected", async () => {
  const kv = await freshKv(10);
  await assert.rejects(() => applyUserAction(kv, { action: "add", user: { name: "c" } }, OPTS, RESELLER), /plan is required/);
  assert.equal((await getSettings(kv)).users.length, 0);
  assert.equal(await balOf(kv), 10, "no charge on rejection");
});

test("reseller add with a non-sellable plan is rejected", async () => {
  const kv = await freshKv(10);
  await assert.rejects(() => applyUserAction(kv, { action: "add", user: { name: "c", planId: "pl0" } }, OPTS, RESELLER), /no such sellable plan/);
  assert.equal(await balOf(kv), 10);
});

test("insufficient balance -> 402, nothing persisted", async () => {
  const kv = await freshKv(2); // price is 3
  await assert.rejects(() => applyUserAction(kv, { action: "add", user: { name: "c", planId: "pl1" } }, OPTS, RESELLER), /insufficient/);
  assert.equal((await getSettings(kv)).users.length, 0, "no user created");
  assert.equal(await balOf(kv), 2, "balance untouched");
});

test("owner is NOT gated and NOT charged (free-form still works)", async () => {
  const kv = await freshKv(10);
  const { user } = await applyUserAction(kv, { action: "add", user: { name: "ownercust", quotaBytes: 12345 } }, OPTS, null);
  assert.equal(user.quotaBytes, 12345, "owner free-form quota preserved");
  assert.equal(user.planId, undefined);
  assert.equal(await balOf(kv), 10, "owner action never charges a reseller");
});

test("reseller edit without a plan can't raise caps; passing a plan renews and re-charges", async () => {
  const kv = await freshKv(10);
  const { user } = await applyUserAction(kv, { action: "add", user: { name: "c", planId: "pl1" } }, OPTS, RESELLER);
  assert.equal(await balOf(kv), 7);
  // Edit without a plan: tries to raise quota + rename. Quota must not change.
  const upd = await applyUserAction(kv, { action: "update", user: { id: user.id, name: "c2", quotaBytes: 999999, enabled: false } }, OPTS, RESELLER);
  assert.equal(upd.user.quotaBytes, 50 * 1024 ** 3, "caps unchanged on a plan-less edit");
  assert.equal(upd.user.name, "c2", "rename allowed");
  assert.equal(upd.user.enabled, false, "disable allowed");
  assert.equal(await balOf(kv), 7, "a plan-less edit is free");
  // Renew with the plan: charges again.
  await applyUserAction(kv, { action: "update", user: { id: user.id, planId: "pl1" } }, OPTS, RESELLER);
  assert.equal(await balOf(kv), 4, "renewal charged (7 -> 4)");
});
