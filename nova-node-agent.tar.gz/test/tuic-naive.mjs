// TUIC + NaiveProxy (sing-box) inbounds: config generation, share links, and
// that they flow through buildSub for a user served on a standalone inbound.
import { test } from "node:test";
import assert from "node:assert/strict";

import { buildSub, tuicLine, naiveLine } from "../src/subscription.mjs";
import { normalizeInbound, SINGBOX_PROTOCOLS } from "../src/xray/inbounds.mjs";
import { generateSingboxConfig } from "../src/singbox/config.mjs";

const U = { id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "alice", name: "alice", enabled: true };

test("SINGBOX_PROTOCOLS now includes tuic and naive", () => {
  assert.ok(SINGBOX_PROTOCOLS.includes("tuic"));
  assert.ok(SINGBOX_PROTOCOLS.includes("naive"));
});

test("generateSingboxConfig builds tuic + naive inbounds with per-user creds", () => {
  const cfg = generateSingboxConfig([U], {
    enableDefault: false,
    extraInbounds: [
      { protocol: "tuic", tag: "tuic-2443", port: 2443, serves: () => true },
      { protocol: "naive", tag: "naive-2444", port: 2444, serves: () => true },
    ],
  });
  const tuic = cfg.inbounds.find((i) => i.type === "tuic");
  const naive = cfg.inbounds.find((i) => i.type === "naive");
  assert.ok(tuic && tuic.listen_port === 2443);
  assert.equal(tuic.congestion_control, "bbr");
  assert.deepEqual(tuic.tls.alpn, ["h3"]);
  assert.equal(tuic.users[0].uuid, U.uuid);
  assert.equal(tuic.users[0].password, U.uuid);
  assert.equal(tuic.users[0].name, "alice");
  assert.ok(naive && naive.listen_port === 2444);
  assert.equal(naive.users[0].username, "alice");
  assert.equal(naive.users[0].password, U.uuid);
  // The v2ray stats list picks up both tuic (name) and naive (username).
  const statUsers = cfg.experimental.v2ray_api.stats.users;
  assert.ok(statUsers.includes("alice"));
});

test("tuicLine / naiveLine format", () => {
  const t = tuicLine(U, { host: "203.0.113.9", port: 2443, insecure: true });
  assert.ok(t.startsWith(`tuic://${U.uuid}:${U.uuid}@203.0.113.9:2443?`));
  const tq = new URL(t).searchParams;
  assert.equal(tq.get("congestion_control"), "bbr");
  assert.equal(tq.get("alpn"), "h3");
  assert.equal(tq.get("sni"), "203.0.113.9");
  assert.equal(tq.get("allow_insecure"), "1");
  assert.equal(tq.get("udp_relay_mode"), "native");

  const n = naiveLine(U, { host: "203.0.113.9", port: 2444 });
  assert.ok(n.startsWith("naive+https://alice:"));
  assert.ok(n.includes(`${U.uuid}@203.0.113.9:2444`));
});

test("buildSub emits tuic + naive links for a served user", async () => {
  const tuicInb = normalizeInbound({ id: "t1", tag: "tuic1", protocol: "tuic", port: 2443, remark: "TUIC" });
  const naiveInb = normalizeInbound({ id: "n1", tag: "naive1", protocol: "naive", port: 2444, remark: "Naive" });
  const b64 = await buildSub([U], {
    host: "h", directHost: "203.0.113.9", insecure: true,
    protocols: { vless: true }, inbounds: [tuicInb, naiveInb],
  });
  const body = Buffer.from(b64, "base64").toString("utf8");
  assert.match(body, /tuic:\/\/[^\n]*@203\.0\.113\.9:2443/);
  assert.match(body, /naive\+https:\/\/[^\n]*@203\.0\.113\.9:2444/);
});
