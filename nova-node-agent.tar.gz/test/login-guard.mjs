// Persistent per-IP login guard: config clamping, fail counting, ban trip,
// expiry sweep, list, and unban.
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  guardConfig,
  isLoginBanned,
  recordLoginFail,
  clearLoginFails,
  listLoginBans,
  unbanLogin,
} from "../src/login-guard.mjs";

// Minimal in-memory KV with the list/get/put/delete surface the guard uses.
function memKv() {
  const m = new Map();
  return {
    map: m,
    async get(k) { return m.has(k) ? m.get(k) : null; },
    async put(k, v) { m.set(k, String(v)); },
    async delete(k) { m.delete(k); },
    async list({ prefix = "" } = {}) {
      return [...m.keys()].filter((k) => k.startsWith(prefix)).map((name) => ({ name }));
    },
  };
}

test("guardConfig defaults + clamping", () => {
  const d = guardConfig({});
  assert.equal(d.enabled, true);
  assert.equal(d.maxFails, 5);
  assert.equal(d.windowMs, 10 * 60_000);
  assert.equal(d.banMs, 60 * 60_000);

  const c = guardConfig({ loginGuard: { enabled: false, maxFails: 0, windowMin: 99999, banMin: -3 } });
  assert.equal(c.enabled, false);
  assert.equal(c.maxFails, 1); // clamped up from 0
  assert.equal(c.windowMs, 1440 * 60_000); // clamped down
  assert.equal(c.banMs, 1 * 60_000); // clamped up from negative
});

test("failures accumulate then trip a ban at maxFails", async () => {
  const kv = memKv();
  const cfg = guardConfig({ loginGuard: { maxFails: 3, windowMin: 10, banMin: 30 } });
  const ip = "203.0.113.7";
  let r = await recordLoginFail(kv, ip, cfg, 1000);
  assert.deepEqual([r.banned, r.remaining], [false, 2]);
  r = await recordLoginFail(kv, ip, cfg, 2000);
  assert.deepEqual([r.banned, r.remaining], [false, 1]);
  r = await recordLoginFail(kv, ip, cfg, 3000);
  assert.equal(r.banned, true);
  assert.equal(r.until, 3000 + 30 * 60_000);

  const b = await isLoginBanned(kv, ip, 4000);
  assert.equal(b.banned, true);
  // The fail counter is cleared once the ban is set.
  assert.equal(kv.map.has("loginfail:" + ip), false);
});

test("a stale failure window restarts the count", async () => {
  const kv = memKv();
  const cfg = guardConfig({ loginGuard: { maxFails: 3, windowMin: 10 } });
  const ip = "203.0.113.8";
  await recordLoginFail(kv, ip, cfg, 0);
  await recordLoginFail(kv, ip, cfg, 1000);
  // Jump past the 10-minute window: the next failure is counted as the first.
  const r = await recordLoginFail(kv, ip, cfg, 11 * 60_000);
  assert.deepEqual([r.banned, r.remaining], [false, 2]);
});

test("clearLoginFails resets the counter (successful login path)", async () => {
  const kv = memKv();
  const cfg = guardConfig({ loginGuard: { maxFails: 3 } });
  const ip = "203.0.113.9";
  await recordLoginFail(kv, ip, cfg, 0);
  await recordLoginFail(kv, ip, cfg, 100);
  await clearLoginFails(kv, ip);
  const r = await recordLoginFail(kv, ip, cfg, 200);
  assert.equal(r.remaining, 2); // back to the start
});

test("isLoginBanned sweeps an expired ban", async () => {
  const kv = memKv();
  await kv.put("loginban:1.2.3.4", String(5000));
  const b = await isLoginBanned(kv, "1.2.3.4", 6000);
  assert.equal(b.banned, false);
  assert.equal(kv.map.has("loginban:1.2.3.4"), false);
});

test("listLoginBans returns active bans, unban removes them", async () => {
  const kv = memKv();
  const cfg = guardConfig({ loginGuard: { maxFails: 1, banMin: 30 } });
  await recordLoginFail(kv, "10.0.0.1", cfg, 1000);
  await recordLoginFail(kv, "10.0.0.2", cfg, 2000);
  const bans = await listLoginBans(kv, 3000);
  assert.equal(bans.length, 2);
  // Sorted newest-expiry first.
  assert.equal(bans[0].ip, "10.0.0.2");

  await unbanLogin(kv, "10.0.0.2");
  const after = await listLoginBans(kv, 3000);
  assert.deepEqual(after.map((b) => b.ip), ["10.0.0.1"]);
});
