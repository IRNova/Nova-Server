// Quick wins: user templates (saved plans), bulk user actions, and CSV
// import/export. Exercised through the real node:http server with xray shelled
// out (managerOpts.exec=false).
import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { rmSync } from "node:fs";

import { openKv } from "../src/kv/sqlite.mjs";
import { createServer, usersToCsv, parseUsersCsv } from "../src/server.mjs";

const UA = "Nova/1.0.0 (desktop; sing-box)";
const GB = 1024 ** 3;

function startServer(kv, opts) {
  const server = createServer(kv, opts);
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      resolve({ base: `http://127.0.0.1:${port}`, close: () => new Promise((r) => server.close(r)) });
    });
  });
}
function freshKv() {
  const path = join(tmpdir(), `nova-qw-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return { kv, cleanup() { kv.close(); for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} } } };
}
function cookieValue(res) {
  const m = /(?:^|,\s*)auth=([^;]+)/.exec(res.headers.get("set-cookie") || "");
  return m ? m[1] : null;
}
async function setup(base) {
  const res = await fetch(base + "/install/set", {
    method: "POST", headers: { "content-type": "application/json", "user-agent": UA },
    body: JSON.stringify({ password: "hunter2secret" }),
  });
  const auth = { cookie: `auth=${cookieValue(res)}`, "user-agent": UA, "content-type": "application/json" };
  await fetch(base + "/admin/network-settings.json", {
    method: "POST", headers: auth,
    body: JSON.stringify({ host: "203.0.113.9", insecure: true, protocols: { vless: true } }),
  });
  return auth;
}
const addUser = (base, auth, u) => fetch(base + "/admin/users.json", {
  method: "POST", headers: auth, body: JSON.stringify({ action: "add", user: u }),
}).then((r) => r.json());
const listUsers = (base, auth) => fetch(base + "/admin/users.json", { headers: auth }).then((r) => r.json()).then((d) => d.users);

function withServer(fn) {
  return async () => {
    const { kv, cleanup } = freshKv();
    const configPath = join(tmpdir(), `nova-qw-cfg-${randomBytes(6).toString("hex")}.json`);
    const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
    try { await fn(srv); } finally { await srv.close(); cleanup(); try { rmSync(configPath); } catch {} }
  };
}

test("CSV round-trip: usersToCsv <-> parseUsersCsv preserves the fields", () => {
  const users = [
    { id: "u1", uuid: "11111111-1111-4111-8111-111111111111", name: "alice", quotaBytes: 50 * GB, expireDays: 30, ipLimit: 2, resetStrategy: "month", enabled: true },
    { id: "u2", uuid: "22222222-2222-4222-8222-222222222222", name: "bob, jr", quotaBytes: 0, enabled: false },
  ];
  const csv = usersToCsv(users);
  assert.match(csv.split("\n")[0], /^name,uuid,volumeGB,expireDays,upGB,downGB,ipLimit,resetStrategy,enabled$/);
  assert.match(csv, /"bob, jr"/); // comma in a field is quoted
  const parsed = parseUsersCsv(csv);
  assert.equal(parsed.length, 2);
  assert.equal(parsed[0].name, "alice");
  assert.equal(parsed[0].quotaBytes, 50 * GB);
  assert.equal(parsed[0].expireDays, 30);
  assert.equal(parsed[0].ipLimit, 2);
  assert.equal(parsed[0].resetStrategy, "month");
  assert.equal(parsed[0].enabled, true);
  assert.equal(parsed[1].name, "bob, jr");
  assert.equal(parsed[1].enabled, false);
});

test("user templates: CRUD, and apply a plan to selected users in bulk", withServer(async (srv) => {
  const auth = await setup(srv.base);
  // Create a plan.
  let res = await fetch(srv.base + "/admin/user-templates", {
    method: "POST", headers: auth,
    body: JSON.stringify({ template: { name: "30d / 50GB", volumeGB: 50, expireDays: 30, ipLimit: 3, resetStrategy: "month" } }),
  });
  assert.equal(res.status, 200);
  const { templates } = await res.json();
  assert.equal(templates.length, 1);
  const tpl = templates[0];
  assert.equal(tpl.volumeGB, 50);

  // Two users with no plan yet.
  await addUser(srv.base, auth, { id: "a", uuid: "aaaaaaaa-1111-4111-8111-111111111111", email: "a" });
  await addUser(srv.base, auth, { id: "b", uuid: "bbbbbbbb-1111-4111-8111-111111111111", email: "b" });

  // Apply the plan to both via bulk.
  res = await fetch(srv.base + "/admin/users.json", {
    method: "POST", headers: auth,
    body: JSON.stringify({ action: "bulk", op: "template", arg: tpl.id, ids: ["a", "b"] }),
  });
  assert.equal(res.status, 200);
  assert.equal((await res.json()).affected, 2);

  const users = await listUsers(srv.base, auth);
  for (const u of users) {
    assert.equal(u.quotaBytes, 50 * GB, "plan volume applied");
    assert.equal(u.expireDays, 30);
    assert.equal(u.ipLimit, 3);
    assert.equal(u.resetStrategy, "month");
  }

  // Delete the plan.
  res = await fetch(srv.base + "/admin/user-templates", {
    method: "POST", headers: auth, body: JSON.stringify({ action: "delete", id: tpl.id }),
  });
  assert.equal((await res.json()).templates.length, 0);
}));

test("bulk actions: disable, enable, extend, reset, delete", withServer(async (srv) => {
  const auth = await setup(srv.base);
  for (const id of ["a", "b", "c"]) {
    await addUser(srv.base, auth, { id, uuid: `${id}${id}${id}${id}${id}${id}${id}${id}-1111-4111-8111-111111111111`.slice(0, 36), email: id });
  }
  const bulk = (op, ids, arg) => fetch(srv.base + "/admin/users.json", {
    method: "POST", headers: auth, body: JSON.stringify({ action: "bulk", op, ids, arg }),
  });

  // Disable a + b.
  let r = await bulk("disable", ["a", "b"]);
  assert.equal((await r.json()).affected, 2);
  let users = await listUsers(srv.base, auth);
  assert.equal(users.find((u) => u.id === "a").enabled, false);
  assert.equal(users.find((u) => u.id === "c").enabled !== false, true);

  // Re-enable a.
  await bulk("enable", ["a"]);
  users = await listUsers(srv.base, auth);
  assert.equal(users.find((u) => u.id === "a").enabled, true);

  // Extend c by 10 days -> it gets an expiry in the future.
  r = await bulk("extend", ["c"], 10);
  assert.equal(r.status, 200);
  users = await listUsers(srv.base, auth);
  const exp = Date.parse(users.find((u) => u.id === "c").expiry);
  assert.ok(exp > Date.now() + 9 * 86400_000 && exp < Date.now() + 11 * 86400_000, "expiry ~10 days out");

  // Reset usage on a (no throw; op accepted).
  assert.equal((await bulk("reset", ["a"])).status, 200);

  // Delete b + c.
  r = await bulk("delete", ["b", "c"]);
  assert.equal((await r.json()).affected, 2);
  users = await listUsers(srv.base, auth);
  assert.deepEqual(users.map((u) => u.id).sort(), ["a"]);

  // Empty selection is rejected.
  assert.equal((await bulk("disable", [])).status, 400);
  // Unknown op is rejected.
  assert.equal((await bulk("frobnicate", ["a"])).status, 400);
}));

test("CSV import creates users, re-import updates them (idempotent by name)", withServer(async (srv) => {
  const auth = await setup(srv.base);
  const csv = [
    "name,uuid,volumeGB,expireDays,ipLimit,resetStrategy,enabled",
    "carol,,25,60,1,month,true",
    "dave,,0,,0,,false",
  ].join("\n");
  let res = await fetch(srv.base + "/admin/users/import", {
    method: "POST", headers: { ...auth, "content-type": "text/csv" }, body: csv,
  });
  assert.equal(res.status, 200);
  let out = await res.json();
  assert.equal(out.added, 2);
  assert.equal(out.updated, 0);

  let users = await listUsers(srv.base, auth);
  const carol = users.find((u) => u.name === "carol");
  assert.equal(carol.quotaBytes, 25 * GB);
  assert.equal(carol.expireDays, 60);
  assert.equal(users.find((u) => u.name === "dave").enabled, false);

  // Re-import the same names -> updates, does not duplicate.
  res = await fetch(srv.base + "/admin/users/import", {
    method: "POST", headers: { ...auth, "content-type": "text/csv" },
    body: "name,volumeGB\ncarol,100\n",
  });
  out = await res.json();
  assert.equal(out.updated, 1);
  assert.equal(out.added, 0);
  users = await listUsers(srv.base, auth);
  assert.equal(users.filter((u) => u.name === "carol").length, 1);
  assert.equal(users.find((u) => u.name === "carol").quotaBytes, 100 * GB);

  // Export returns a CSV with all users.
  res = await fetch(srv.base + "/admin/users.csv", { headers: auth });
  assert.equal(res.status, 200);
  assert.match(res.headers.get("content-type") || "", /text\/csv/);
  const body = await res.text();
  assert.match(body, /carol/);
  assert.match(body, /dave/);

  // Empty CSV is rejected.
  res = await fetch(srv.base + "/admin/users/import", {
    method: "POST", headers: { ...auth, "content-type": "text/csv" }, body: "name\n",
  });
  assert.equal(res.status, 400);
}));
