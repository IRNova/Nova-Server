// Customer Telegram alerts: warn a linked customer (tgChatId) before expiry
// (<=3 days) and when data is low (>=80%), each edge once. Off, or a customer
// with no linked chat, sends nothing.
import { test } from "node:test";
import assert from "node:assert/strict";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import { openKv } from "../src/kv/sqlite.mjs";
import { maybeCustomerAlerts, putSettings } from "../src/server.mjs";

function mockFetch() {
  const calls = [];
  const orig = globalThis.fetch;
  globalThis.fetch = async (url, opts) => {
    calls.push({ url: String(url), body: opts && opts.body ? JSON.parse(opts.body) : null });
    return { ok: true, json: async () => ({ ok: true }) };
  };
  return { calls, restore: () => { globalThis.fetch = orig; } };
}
const freshKv = () => openKv(join(tmpdir(), `nova-ca-${randomBytes(6).toString("hex")}.db`));
const NOW = Date.parse("2026-01-10T00:00:00Z");

test("expiring soon + data low each fire once; no-chat and far-off are skipped", async () => {
  const kv = await freshKv();
  await putSettings(kv, {
    customerAlerts: true, tgBotToken: "T", subToken: "s",
    users: [
      { id: "u1", enabled: true, tgChatId: "111", expiry: "2026-01-12" }, // 2 days -> alert
      { id: "u2", enabled: true, tgChatId: "222", quotaBytes: 100 },       // 85% -> data low
      { id: "u3", enabled: true, expiry: "2026-01-11" },                   // no chat -> skip
      { id: "u4", enabled: true, tgChatId: "444", expiry: "2026-02-20" },  // far -> no alert
    ],
  });
  const m = mockFetch();
  try {
    await maybeCustomerAlerts(kv, { now: NOW, usage: { u2: 85 } });
    const msgs = m.calls.filter((c) => /sendMessage/.test(c.url));
    const to = (id) => msgs.filter((c) => String(c.body.chat_id) === id);
    assert.equal(to("111").length, 1); assert.match(to("111")[0].body.text, /expires in/i);
    assert.equal(to("222").length, 1); assert.match(to("222")[0].body.text, /of your data/i);
    assert.equal(to("444").length, 0, "far expiry not alerted");
    assert.equal(msgs.length, 2, "u3 (no chat) not alerted");
    // Second run: both edges are throttled.
    m.calls.length = 0;
    await maybeCustomerAlerts(kv, { now: NOW, usage: { u2: 85 } });
    assert.equal(m.calls.filter((c) => /sendMessage/.test(c.url)).length, 0, "throttled second run");
  } finally { m.restore(); }
});

test("data flag re-arms after a reset (usage drops back under 80%)", async () => {
  const kv = await freshKv();
  await putSettings(kv, { customerAlerts: true, tgBotToken: "T", subToken: "s", users: [{ id: "u2", enabled: true, tgChatId: "222", quotaBytes: 100 }] });
  const m = mockFetch();
  try {
    await maybeCustomerAlerts(kv, { now: NOW, usage: { u2: 90 } });       // alert
    await maybeCustomerAlerts(kv, { now: NOW, usage: { u2: 90 } });       // throttled
    await maybeCustomerAlerts(kv, { now: NOW, usage: { u2: 10 } });       // reset -> clears flag
    await maybeCustomerAlerts(kv, { now: NOW, usage: { u2: 90 } });       // alert again
    assert.equal(m.calls.filter((c) => /sendMessage/.test(c.url)).length, 2, "two alerts across a reset");
  } finally { m.restore(); }
});

test("feature off -> nothing sent", async () => {
  const kv = await freshKv();
  await putSettings(kv, { customerAlerts: false, tgBotToken: "T", subToken: "s", users: [{ id: "u1", enabled: true, tgChatId: "1", expiry: "2026-01-11" }] });
  const m = mockFetch();
  try { await maybeCustomerAlerts(kv, { now: NOW, usage: {} }); assert.equal(m.calls.length, 0); }
  finally { m.restore(); }
});
