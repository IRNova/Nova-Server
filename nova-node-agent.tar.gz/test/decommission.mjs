// Self-decommission: /api/v1/decommission lets a parent tell a node to uninstall
// itself when it is removed from the fleet with "also uninstall". The teardown is
// spawned detached (so the HTTP response flushes first), and it must be guarded so
// it never runs a real uninstall in dev/PaaS.
import { test } from "node:test";
import assert from "node:assert/strict";
import { scheduleSelfUninstall } from "../src/server.mjs";

test("scheduleSelfUninstall is a no-op under NOVA_NO_EXEC (never spawns a real uninstall)", async () => {
  process.env.NOVA_NO_EXEC = "1";
  try {
    const r = await scheduleSelfUninstall();
    assert.equal(r.ok, false);
    assert.equal(r.skipped, "no-exec");
  } finally {
    delete process.env.NOVA_NO_EXEC;
  }
});

test("scheduleSelfUninstall is a no-op in PaaS mode", async () => {
  process.env.NOVA_PAAS = "1";
  try {
    const r = await scheduleSelfUninstall();
    assert.equal(r.ok, false);
    assert.equal(r.skipped, "paas");
  } finally {
    delete process.env.NOVA_PAAS;
  }
});
