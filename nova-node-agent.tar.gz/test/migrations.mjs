import { test } from "node:test";
import assert from "node:assert/strict";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import { openKv } from "../src/kv/sqlite.mjs";
import {
  convertPanelExport,
  detectMigrationSource,
  usersToPortableExport,
} from "../src/migrations.mjs";
import { createServer, getSettings, importUsers, putSettings } from "../src/server.mjs";
import { makeSession, setPassword } from "../src/auth.mjs";

const UUID_A = "11111111-1111-4111-8111-111111111111";
const UUID_B = "22222222-2222-4222-8222-222222222222";
const GIB = 1024 ** 3;
const OPTS = {
  managerOpts: {
    exec: false,
    configPath: join(tmpdir(), `nova-migrate-config-${randomBytes(6).toString("hex")}.json`),
  },
};

test("Marzban export preserves identity, policy, usage, expiry and status", () => {
  const source = {
    users: [{
      username: "ali", proxies: { vless: { id: UUID_A } },
      data_limit: 20 * GIB, used_traffic: 3 * GIB, expire: 2_000_000_000,
      data_limit_reset_strategy: "monthly", note: "legacy", status: "active",
    }],
  };
  assert.equal(detectMigrationSource(source), "marzban");
  const out = convertPanelExport(source);
  assert.equal(out.source, "marzban");
  assert.equal(out.rows.length, 1);
  assert.deepEqual(out.rows[0], {
    name: "ali", email: "ali", uuid: UUID_A,
    quotaBytes: 20 * GIB, usedBytes: 3 * GIB,
    expiry: new Date(2_000_000_000_000).toISOString(),
    note: "legacy", resetStrategy: "month", enabled: true,
  });
});

test("3x-ui merges the same client across inbounds and keeps the first credential", () => {
  const source = {
    success: true,
    obj: [
      {
        protocol: "vless", enable: true, trafficReset: "month",
        settings: JSON.stringify({ clients: [{ email: "sara", id: UUID_A, totalGB: 8 * GIB, expiryTime: 2_000_000_000_000, enable: true }] }),
        clientStats: [{ email: "sara", up: 100, down: 200, enable: true }],
      },
      {
        protocol: "trojan", enable: true,
        settings: { clients: [{ email: "sara", password: UUID_B, totalGB: 10 * GIB, enable: true }] },
        clientStats: [{ email: "sara", up: 80, down: 500, enable: true }],
      },
    ],
  };
  const out = convertPanelExport(source);
  assert.equal(out.source, "3x-ui");
  assert.equal(out.rows.length, 1);
  assert.equal(out.rows[0].uuid, UUID_A);
  assert.equal(out.rows[0].quotaBytes, 10 * GIB);
  assert.equal(out.rows[0].usedBytes, 580);
  assert.equal(out.rows[0].resetStrategy, "month");
  assert.ok(out.warnings.some((w) => w.includes("different credentials")));
});

test("s-ui, Hiddify and Remnawave adapters recognize their native fields", () => {
  const sui = convertPanelExport({
    clients: [{ name: "sui-user", config: { uuid: UUID_A }, volume: 2 * GIB, up: 4, down: 5, expiry: 2_000_000_000, enable: false }],
  });
  assert.equal(sui.source, "s-ui");
  assert.equal(sui.rows[0].uuid, UUID_A);
  assert.equal(sui.rows[0].usedBytes, 9);
  assert.equal(sui.rows[0].enabled, false);

  const hiddify = convertPanelExport({
    users: [{ name: "hid-user", uuid: UUID_B, usage_limit_GB: 12, current_usage_GB: 1.5, package_days: 30, max_ips: 2, enable: true }],
  });
  assert.equal(hiddify.source, "hiddify");
  assert.equal(hiddify.rows[0].quotaBytes, 12 * GIB);
  assert.equal(hiddify.rows[0].usedBytes, Math.round(1.5 * GIB));
  assert.equal(hiddify.rows[0].expireDays, 30);
  assert.equal(hiddify.rows[0].ipLimit, 2);

  const remnawave = convertPanelExport({
    users: [{ username: "rem-user", vlessUuid: UUID_A, trafficLimitBytes: 9 * GIB, usedTrafficBytes: 7, expireAt: "2030-01-02T00:00:00Z", status: "ACTIVE" }],
  });
  assert.equal(remnawave.source, "remnawave");
  assert.equal(remnawave.rows[0].uuid, UUID_A);
  assert.equal(remnawave.rows[0].expiry, "2030-01-02T00:00:00.000Z");
});

test("portable Nova export round-trips and imported usage is persisted", async () => {
  const portable = usersToPortableExport(
    [{ id: "old", name: "Reza", email: "reza", uuid: UUID_A, quotaBytes: 5 * GIB, enabled: true }],
    { old: 123456 },
  );
  assert.equal(detectMigrationSource(portable), "nova");
  const converted = convertPanelExport(portable);
  assert.equal(converted.rows[0].usedBytes, 123456);

  const kv = openKv(join(tmpdir(), `nova-migrate-${randomBytes(6).toString("hex")}.db`));
  try {
    await putSettings(kv, { host: "example.com", wsPath: "/nova", subToken: "t", protocols: { vless: true }, inbounds: [], users: [] });
    const result = await importUsers(kv, converted.rows, OPTS);
    assert.equal(result.added, 1);
    const user = (await getSettings(kv)).users[0];
    assert.equal(user.email, "reza");
    assert.equal(await kv.get(`uusage:${user.id}`), "123456");
  } finally {
    kv.close();
  }
});

test("reseller bulk migration/import cannot bypass sellable plan billing", async () => {
  const kv = openKv(join(tmpdir(), `nova-migrate-reseller-${randomBytes(6).toString("hex")}.db`));
  try {
    await putSettings(kv, { users: [], admins: [{ id: "r1", role: "reseller", balance: 0 }] });
    await assert.rejects(
      () => importUsers(kv, [{ name: "free-account", uuid: UUID_A }], OPTS, { id: "r1", role: "reseller" }),
      /reseller bulk import is disabled/,
    );
    assert.equal((await getSettings(kv)).users.length, 0);
  } finally {
    kv.close();
  }
});

test("migration HTTP endpoint previews before commit and portable export is not cached", async () => {
  const kv = openKv(join(tmpdir(), `nova-migrate-http-${randomBytes(6).toString("hex")}.db`));
  const server = createServer(kv, OPTS);
  try {
    await putSettings(kv, { host: "example.com", wsPath: "/nova", subToken: "t", protocols: { vless: true }, inbounds: [], users: [] });
    await setPassword(kv, "migration-test-password");
    const session = await makeSession(kv, { userAgent: "migration-test" });
    const cookie = session.cookie.split(";")[0];
    const base = await new Promise((resolve) => {
      server.listen(0, "127.0.0.1", () => resolve(`http://127.0.0.1:${server.address().port}`));
    });
    const source = { users: [{ username: "mina", proxies: { vless: { id: UUID_A } }, data_limit: GIB, used_traffic: 42, status: "active" }] };
    const headers = { "content-type": "application/json", cookie, "user-agent": "migration-test" };

    let res = await fetch(base + "/admin/users/migrate", {
      method: "POST", headers, body: JSON.stringify({ dryRun: true, data: source }),
    });
    assert.equal(res.status, 200);
    let body = await res.json();
    assert.equal(body.dryRun, true);
    assert.equal(body.source, "marzban");
    assert.equal((await getSettings(kv)).users.length, 0, "preview writes nothing");

    res = await fetch(base + "/admin/users/migrate", {
      method: "POST", headers, body: JSON.stringify({ dryRun: false, data: source }),
    });
    body = await res.json();
    assert.equal(body.added, 1);
    assert.equal((await getSettings(kv)).users.length, 1);

    res = await fetch(base + "/admin/users/export", { headers: { cookie, "user-agent": "migration-test" } });
    assert.equal(res.status, 200);
    assert.equal(res.headers.get("cache-control"), "no-store");
    assert.match(res.headers.get("content-disposition") || "", /nova-users\.json/);
    const exported = await res.json();
    assert.equal(exported.users[0].usedBytes, 42);
  } finally {
    await new Promise((resolve) => server.close(() => resolve()));
    kv.close();
  }
});
