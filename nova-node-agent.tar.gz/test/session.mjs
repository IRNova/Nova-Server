import { test } from "node:test";
import assert from "node:assert/strict";
import { openKv } from "../src/kv/sqlite.mjs";
import { setPassword, makeSession, resolveSession, verifySession, REMEMBER_MAX_AGE_MS } from "../src/auth.mjs";

const UA = "Nova/1.0 (test)";
const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;

function kv() {
  const k = openKv(":memory:");
  return k;
}

test('default session lasts 8h idle (not the old 30m), and slides via re-mint', async () => {
  const k = kv();
  await setPassword(k, "pw-session-1");
  const now = Date.now();
  const sess = await makeSession(k, { userAgent: UA, now });
  assert.match(sess.cookie, /Max-Age=28800/); // 8h in seconds
  // Valid at 7h59m, expired at 8h01m.
  assert.ok(await verifySession(k, sess.value, { userAgent: UA, now: now + 8 * HOUR - 60000 }));
  assert.equal(await verifySession(k, sess.value, { userAgent: UA, now: now + 8 * HOUR + 60000 }), false);
});

test('"remember me" (30-day) session survives long past the 8h default', async () => {
  const k = kv();
  await setPassword(k, "pw-session-2");
  const now = Date.now();
  const sess = await makeSession(k, { userAgent: UA, now, maxAgeMs: REMEMBER_MAX_AGE_MS });
  assert.match(sess.cookie, /Max-Age=2592000/); // 30d
  // Still valid at 20 days (would be long dead under the 8h default)...
  assert.ok(await verifySession(k, sess.value, { userAgent: UA, now: now + 20 * DAY }));
  // ...and the /admin gate's re-mint passes no maxAgeMs, yet the token's own TTL wins.
  const id = await resolveSession(k, sess.value, { userAgent: UA, now: now + 20 * DAY });
  assert.equal(id.maxAgeMs, REMEMBER_MAX_AGE_MS);
  // Dead after 31 days.
  assert.equal(await verifySession(k, sess.value, { userAgent: UA, now: now + 31 * DAY }), false);
});

test("the signed TTL is tamper-proof: bumping ttl in the token breaks the mac", async () => {
  const k = kv();
  await setPassword(k, "pw-session-3");
  const now = Date.now();
  const sess = await makeSession(k, { userAgent: UA, now }); // 8h token
  const [adminId, issuedAt, , mac] = sess.value.split(".");
  // Attacker rewrites ttl to 30 days but can't re-sign without the server key.
  const forged = `${adminId}.${issuedAt}.${REMEMBER_MAX_AGE_MS}.${mac}`;
  assert.equal(await verifySession(k, forged, { userAgent: UA, now: now + 20 * DAY }), false);
});

test("malformed / stale tokens never throw, just fail closed", async () => {
  const k = kv();
  await setPassword(k, "pw-session-4");
  // 3-part shape with a bad mac (the legacy parser path) -> reject, not crash.
  assert.equal(await verifySession(k, "owner.123.deadbeef", { userAgent: UA }), false);
  // 2-part legacy-owner shape, bad mac -> reject.
  assert.equal(await verifySession(k, "123.deadbeef", { userAgent: UA }), false);
  // Junk / wrong arity -> null.
  assert.equal(await resolveSession(k, "garbage", { userAgent: UA }), null);
  assert.equal(await resolveSession(k, "a.b.c.d.e", { userAgent: UA }), null);
  // A 4-part token with a non-numeric ttl -> null (parse guard).
  assert.equal(await resolveSession(k, "owner.123.notanumber.mac", { userAgent: UA }), null);
});
