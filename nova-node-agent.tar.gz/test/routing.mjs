import { test } from "node:test";
import assert from "node:assert/strict";

import { buildOutbounds, buildRoutingRules, buildDns, warpOutbound, structuredRule } from "../src/xray/routing.mjs";
import { accountFromRegistration, reservedFromClientId } from "../src/xray/warp.mjs";
import { generateXrayConfig } from "../src/xray/config.mjs";

const WARP = {
  privateKey: "cGEEE1S9hQ3H0T2i5m8u9r0uJ8kq\/example000000000=",
  publicKey: "PUB",
  peerPublicKey: "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo=",
  reserved: [1, 2, 3],
  addressV4: "172.16.0.2/32",
  endpoint: "engage.cloudflareclient.com:2408",
  mtu: 1280,
};

test("buildOutbounds: direct+block always, fragment when enabled", () => {
  const outs = buildOutbounds({});
  assert.deepEqual(outs.map((o) => o.tag), ["direct", "block"]);
  assert.equal(outs[0].settings.fragment, undefined);

  const frag = buildOutbounds({ tlsFragment: "custom", fragmentParams: { length: "10-20", interval: "5-10" } });
  assert.equal(frag[0].settings.fragment.length, "10-20");
  assert.equal(frag[0].settings.fragment.packets, "tlshello");
});

test("buildOutbounds: WARP outbound only when enabled AND an account exists", () => {
  assert.equal(buildOutbounds({ enableWarp: true }).some((o) => o.tag === "warp"), false); // no account
  const outs = buildOutbounds({ enableWarp: true }, { warpAccount: WARP });
  const warp = outs.find((o) => o.tag === "warp");
  assert.equal(warp.protocol, "wireguard");
  assert.equal(warp.settings.peers[0].publicKey, WARP.peerPublicKey);
  assert.deepEqual(warp.settings.reserved, [1, 2, 3]);
});

test("buildOutbounds: a socks5 chain adds an outbound + dialerProxy on direct", () => {
  const outs = buildOutbounds({ chainProxy: "socks5://user:pass@1.2.3.4:1080" });
  const chain = outs.find((o) => o.tag === "chain");
  assert.equal(chain.protocol, "socks");
  assert.equal(chain.settings.servers[0].address, "1.2.3.4");
  assert.equal(chain.settings.servers[0].users[0].user, "user");
  assert.equal(outs[0].streamSettings.sockopt.dialerProxy, "chain");
});

test("buildRoutingRules: api rule always; only reliable dat codes; bypass + quic map correctly", () => {
  const base = buildRoutingRules({});
  assert.equal(base[0].outboundTag, "api");
  // No block rule by default, and never a malware/phishing geosite code (absent
  // from the common .dat, would brick xray).
  assert.equal(JSON.stringify(base).includes("category-malware"), false);
  assert.equal(base.length, 1);

  const r = buildRoutingRules({ enableAdBlock: true, bypassChina: true, blockQUIC: true, enableDomesticBypass: true, bypassRussia: true });
  assert.ok(r.some((x) => x.outboundTag === "block" && (x.domain || []).includes("geosite:category-ads-all")));
  assert.ok(r.some((x) => x.outboundTag === "block" && x.network === "udp" && x.port === 443));
  assert.ok(r.some((x) => x.outboundTag === "direct" && (x.domain || []).includes("geosite:cn")));
  assert.ok(r.some((x) => x.outboundTag === "direct" && (x.domain || []).includes("domain:ir")));
  assert.ok(r.some((x) => x.outboundTag === "direct" && (x.ip || []).includes("geoip:ru")));
});

test("buildRoutingRules: warpCalls routes udp through warp", () => {
  const r = buildRoutingRules({ warpCalls: true });
  assert.ok(r.some((x) => x.network === "udp" && x.outboundTag === "warp"));
});

test("buildDns: undefined unless DoH/anti-sanction on", () => {
  assert.equal(buildDns({}), undefined);
  // Secure DNS resolves on the node itself (localhost), not a public provider.
  const d = buildDns({ enableDoH: true, dohProvider: "google" });
  assert.ok(d.servers.includes("localhost"));
  const a = buildDns({ enableAntiSanctionDNS: true, antiSanctionDNSProvider: "shecan" });
  assert.equal(a.servers[0].address, "178.22.122.100");
  assert.ok(a.servers[0].domains.includes("domain:ir"));
});

test("warp: reserved decodes from client_id; account shape is complete", () => {
  const clientId = Buffer.from([7, 8, 9, 255]).toString("base64");
  assert.deepEqual(reservedFromClientId(clientId), [7, 8, 9]);
  const acc = accountFromRegistration(
    { privateKey: "P", publicKey: "K" },
    { config: { client_id: clientId, peers: [{ public_key: "PEER", endpoint: { host: "x.cf:2408" } }], interface: { addresses: { v4: "172.16.0.5", v6: "2606::5" } } } },
  );
  assert.equal(acc.peerPublicKey, "PEER");
  assert.equal(acc.addressV4, "172.16.0.5/32");
  assert.equal(acc.addressV6, "2606::5/128");
  assert.deepEqual(acc.reserved, [7, 8, 9]);
  assert.equal(acc.endpoint, "x.cf:2408");
});

test("generateXrayConfig: net options flow into outbounds/routing/dns", () => {
  const users = [{ id: "me", uuid: "11111111-1111-4111-8111-111111111111", email: "me", enabled: true }];
  const cfg = generateXrayConfig(users, {
    net: { bypassChina: true, enableAdBlock: true, tlsFragment: "custom", enableDoH: true, dohProvider: "cloudflare" },
  });
  assert.ok(cfg.outbounds[0].settings.fragment, "fragment on direct");
  assert.ok(cfg.routing.rules.some((r) => (r.domain || []).includes("geosite:category-ads-all")));
  assert.ok(cfg.routing.rules.some((r) => (r.domain || []).includes("geosite:cn")));
  assert.equal(cfg.routing.domainStrategy, "IPIfNonMatch");
  assert.ok(cfg.dns && cfg.dns.servers.includes("localhost"));
  // still excludes diagnostics from the serialised form
  assert.equal(JSON.stringify(cfg).includes("_skippedInbounds"), false);
});

test("structuredRule: builds a sparse xray rule; empty rows are dropped", () => {
  const r = structuredRule({ domain: "geosite:cn, example.com", outboundTag: "direct", ruleTag: "cn-direct", network: "tcp,udp" });
  assert.equal(r.type, "field");
  assert.deepEqual(r.domain, ["geosite:cn", "example.com"]);
  assert.equal(r.outboundTag, "direct");
  assert.equal(r.ruleTag, "cn-direct");
  assert.equal(r.network, "tcp,udp");
  assert.equal(r.ip, undefined, "empty fields are omitted");
  // routingRules flow into the config, usable ones only.
  const cfg = generateXrayConfig(
    [{ id: "me", uuid: "11111111-1111-4111-8111-111111111111", email: "me", enabled: true }],
    { net: { routingRules: [
      { ip: "geoip:ir", outboundTag: "direct", ruleTag: "ir" },
      { domain: "", outboundTag: "" }, // half-filled -> dropped
    ] } },
  );
  const tags = cfg.routing.rules.map((x) => x.ruleTag).filter(Boolean);
  assert.ok(tags.includes("ir"), "usable structured rule is emitted");
  assert.ok(cfg.routing.rules.every((x) => !(x.ruleTag === undefined && x.domain === undefined && x.ip === undefined && x.outboundTag === undefined && x.balancerTag === undefined && x.inboundTag === undefined)));
});
