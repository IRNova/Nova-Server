// Node-mode + one-command enrollment. A "parent" panel mints a join token; a
// "child" node creates an API token and enrolls itself against the parent's
// public /nodes/enroll; the parent verifies it can reach the child back and
// registers it. Then the child is locked into node mode. Both run in-process
// over http on 127.0.0.1, so nodeFetch reaches the child without TLS.
import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { rmSync } from "node:fs";

import { openKv } from "../src/kv/sqlite.mjs";
import { createServer } from "../src/server.mjs";

const UA = "Nova/1.0.0 (desktop; sing-box)";

function startServer(kv, opts) {
  const server = createServer(kv, opts);
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      resolve({ base: `http://127.0.0.1:${port}`, host: `127.0.0.1:${port}`, close: () => new Promise((r) => server.close(r)) });
    });
  });
}
function freshKv(tag) {
  const path = join(tmpdir(), `nova-${tag}-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return { kv, cleanup() { kv.close(); for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} } } };
}
function cookieValue(res) {
  const m = /(?:^|,\s*)auth=([^;]+)/.exec(res.headers.get("set-cookie") || "");
  return m ? m[1] : null;
}
async function install(base) {
  const res = await fetch(base + "/install/set", {
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": UA },
    body: JSON.stringify({ password: "hunter2secret" }),
  });
  return { cookie: `auth=${cookieValue(res)}`, "user-agent": UA, "content-type": "application/json" };
}

test("one-command enrollment registers the child on the parent, token is one-time", async () => {
  const P = freshKv("parent"), C = freshKv("child");
  const pcfg = join(tmpdir(), `p-cfg-${randomBytes(4).toString("hex")}.json`);
  const ccfg = join(tmpdir(), `c-cfg-${randomBytes(4).toString("hex")}.json`);
  const parent = await startServer(P.kv, { managerOpts: { exec: false, configPath: pcfg } });
  const child = await startServer(C.kv, { managerOpts: { exec: false, configPath: ccfg } });
  try {
    const pAuth = await install(parent.base);
    const cAuth = await install(child.base);

    // Parent mints a join token.
    let res = await fetch(parent.base + "/admin/nodes", {
      method: "POST", headers: pAuth, body: JSON.stringify({ action: "join-token", name: "edge-1" }),
    });
    assert.equal(res.status, 200);
    const jt = await res.json();
    assert.match(jt.token, /^njt_/);
    assert.match(jt.oneLiner, /NOVA_JOIN_URL=/);
    assert.match(jt.oneLiner, /NOVA_JOIN_TOKEN=/);

    // Child mints an API token for the parent.
    res = await fetch(child.base + "/admin/api-tokens", {
      method: "POST", headers: cAuth, body: JSON.stringify({ name: "fleet-parent", role: "owner" }),
    });
    const { token: apiToken } = await res.json();
    assert.ok(apiToken);

    // Child enrolls itself against the parent (child gives its own url + token).
    res = await fetch(parent.base + "/nodes/enroll", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ token: jt.token, url: child.base, apiToken, name: "edge-1", insecure: false }),
    });
    const enrolled = await res.json();
    assert.equal(res.status, 200, JSON.stringify(enrolled));
    assert.ok(enrolled.ok && enrolled.nodeId);

    // The parent now lists the child, marked as enrolled.
    res = await fetch(parent.base + "/admin/nodes", { headers: pAuth });
    const { nodes } = await res.json();
    assert.equal(nodes.length, 1);
    assert.equal(nodes[0].url, child.base);
    assert.equal(nodes[0].enrolled, true);
    assert.equal(nodes[0].hasToken, true);

    // The parent can actually drive the child through the fleet aggregation.
    res = await fetch(parent.base + "/admin/fleet/users", { headers: pAuth });
    assert.equal(res.status, 200);
    const fleet = await res.json();
    assert.equal(fleet.errors.length, 0, JSON.stringify(fleet.errors));

    // The join token is one-time: a second enroll with it is rejected.
    res = await fetch(parent.base + "/nodes/enroll", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ token: jt.token, url: child.base, apiToken, name: "edge-1" }),
    });
    assert.equal(res.status, 401);
  } finally {
    await parent.close(); await child.close();
    P.cleanup(); C.cleanup();
    for (const f of [pcfg, ccfg]) { try { rmSync(f); } catch {} }
  }
});

test("enroll rejects a bad token and an unreachable node", async () => {
  const P = freshKv("parent2");
  const pcfg = join(tmpdir(), `p2-cfg-${randomBytes(4).toString("hex")}.json`);
  const parent = await startServer(P.kv, { managerOpts: { exec: false, configPath: pcfg } });
  try {
    const pAuth = await install(parent.base);
    // Bad token -> 401 (no node registered).
    let res = await fetch(parent.base + "/nodes/enroll", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ token: "njt_nope", url: "http://127.0.0.1:1", apiToken: "x", name: "n" }),
    });
    assert.equal(res.status, 401);
    // Valid token but the node address is unreachable -> 502.
    res = await fetch(parent.base + "/admin/nodes", {
      method: "POST", headers: pAuth, body: JSON.stringify({ action: "join-token" }),
    });
    const { token } = await res.json();
    res = await fetch(parent.base + "/nodes/enroll", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ token, url: "http://127.0.0.1:1", apiToken: "x", name: "n" }),
    });
    assert.equal(res.status, 502);
  } finally {
    await parent.close(); P.cleanup();
    try { rmSync(pcfg); } catch {}
  }
});

test("node mode: stub at root, sign-in closed, but the API and /sub still serve", async () => {
  const C = freshKv("nodemode");
  const ccfg = join(tmpdir(), `nm-cfg-${randomBytes(4).toString("hex")}.json`);
  const child = await startServer(C.kv, { managerOpts: { exec: false, configPath: ccfg } });
  try {
    const cAuth = await install(child.base);
    // Give it a host + a user + an API token BEFORE locking it.
    await fetch(child.base + "/admin/network-settings.json", {
      method: "POST", headers: cAuth,
      body: JSON.stringify({ host: "203.0.113.5", insecure: true, protocols: { vless: true } }),
    });
    await fetch(child.base + "/admin/users.json", {
      method: "POST", headers: cAuth,
      body: JSON.stringify({ action: "add", user: { id: "me", uuid: "11111111-1111-4111-8111-111111111111", email: "me", enabled: true } }),
    });
    let res = await fetch(child.base + "/admin/api-tokens", {
      method: "POST", headers: cAuth, body: JSON.stringify({ name: "p", role: "owner" }),
    });
    const { token: apiToken } = await res.json();

    // Lock the node.
    res = await fetch(child.base + "/admin/network-settings.json", {
      method: "POST", headers: cAuth, body: JSON.stringify({ nodeMode: true }),
    });
    assert.equal(res.status, 200);

    // Root now serves the managed-node stub, not the panel.
    res = await fetch(child.base + "/", { headers: { "user-agent": UA } });
    assert.equal(res.status, 200);
    const html = await res.text();
    assert.match(html, /managed node/i);
    assert.ok(!/window\.__NOVA/.test(html), "must not be the full panel");

    // Human sign-in surfaces are closed.
    for (const p of ["/login", "/install/set", "/admin/network-settings.json"]) {
      const r = await fetch(child.base + p, { method: p === "/login" || p === "/install/set" ? "POST" : "GET", headers: { ...cAuth } });
      assert.equal(r.status, 403, p);
    }

    // The Bearer-token API still works (that is how the parent drives it).
    res = await fetch(child.base + "/api/v1/health", { headers: { authorization: `Bearer ${apiToken}` } });
    assert.equal(res.status, 200);
    assert.equal((await res.json()).ok, true);

    // Users are still served: the personal sub link still returns configs.
    res = await fetch(child.base + "/api/v1/users", { headers: { authorization: `Bearer ${apiToken}` } });
    assert.equal(res.status, 200);
  } finally {
    await child.close(); C.cleanup();
    try { rmSync(ccfg); } catch {}
  }
});
