// DNS Tunnel (MasterDnsVPN) integration: config generation, the Cloudflare
// NS-delegation automation (mocked CF API), and the /admin/dns-tunnel endpoint
// with the shell side stubbed out (managerOpts.exec=false).
import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { rmSync } from "node:fs";

import { openKv } from "../src/kv/sqlite.mjs";
import { createServer } from "../src/server.mjs";
import { patchServerConfig, buildClientConfig, isTunnelDomain, clientConnectionInfo, DNS_ENC_METHODS } from "../src/masterdns.mjs";
import { cfDelegateSubdomain, cfUndelegateSubdomain } from "../src/cloudflare.mjs";

const UA = "Nova/1.0.0 (desktop; sing-box)";

// --- pure config helpers ----------------------------------------------------

test("isTunnelDomain accepts FQDNs and rejects junk", () => {
  assert.ok(isTunnelDomain("dns.example.com"));
  assert.ok(isTunnelDomain("v.sub.example.co.uk"));
  assert.ok(!isTunnelDomain("example"));
  assert.ok(!isTunnelDomain("1.2.3.4"));
  assert.ok(!isTunnelDomain(""));
  assert.ok(!isTunnelDomain("has space.com"));
});

test("patchServerConfig patches keys in the shipped config, keeping the rest", () => {
  const template = [
    'CONFIG_VERSION = "7"',
    'DOMAIN = ["v.domain.com"]',
    'PROTOCOL_TYPE = "SOCKS5"',
    'UDP_HOST = "0.0.0.0"',
    'UDP_PORT = 53',
    'DATA_ENCRYPTION_METHOD = 1',
    'ENCRYPTION_KEY_FILE = "encrypt_key.txt"',
    'SOME_OTHER_KNOB = 42',
  ].join("\n");
  const out = patchServerConfig(template, { domain: "dns.example.com", protocol: "SOCKS5", udpHost: "203.0.113.9", encMethod: DNS_ENC_METHODS.chacha20 });
  assert.match(out, /^CONFIG_VERSION = "7"$/m, "keeps CONFIG_VERSION");
  assert.match(out, /^DOMAIN = \["dns\.example\.com"\]$/m);
  assert.match(out, /^UDP_HOST = "203\.0\.113\.9"$/m, "binds the public IP, not 0.0.0.0");
  assert.match(out, /^DATA_ENCRYPTION_METHOD = 2$/m);
  assert.match(out, /^SOME_OTHER_KNOB = 42$/m, "leaves unrelated knobs alone");
  // Exactly one DOMAIN line (patched in place, not appended).
  assert.equal((out.match(/^DOMAIN =/mg) || []).length, 1);
});

test("patchServerConfig sets FORWARD_* only for TCP mode; rejects a bad domain", () => {
  const tcp = patchServerConfig('CONFIG_VERSION = "7"\n', { domain: "dns.example.com", protocol: "TCP", forwardIp: "127.0.0.1", forwardPort: 8388 });
  assert.match(tcp, /^PROTOCOL_TYPE = "TCP"$/m);
  assert.match(tcp, /^FORWARD_IP = "127\.0\.0\.1"$/m);
  assert.match(tcp, /^FORWARD_PORT = 8388$/m);
  const socks = patchServerConfig('CONFIG_VERSION = "7"\n', { domain: "dns.example.com", protocol: "SOCKS5" });
  assert.ok(!/FORWARD_IP/.test(socks), "no forward keys in SOCKS5 mode");
  assert.throws(() => patchServerConfig("", { domain: "not-a-domain" }), /invalid tunnel domain/);
});

test("buildClientConfig + clientConnectionInfo carry the matching key/method/domain", () => {
  const cfg = buildClientConfig({ domain: "dns.example.com", key: "SECRETKEY", encMethod: DNS_ENC_METHODS.chacha20, protocol: "SOCKS5" });
  assert.match(cfg, /DOMAINS = \["dns\.example\.com"\]/);
  assert.match(cfg, /DATA_ENCRYPTION_METHOD = 2/);
  assert.match(cfg, /ENCRYPTION_KEY = "SECRETKEY"/);
  const info = clientConnectionInfo({ domain: "dns.example.com", key: "SECRETKEY", encMethod: 2, protocol: "SOCKS5" });
  assert.equal(info.encryptionMethod, "chacha20");
  assert.equal(info.encryptionKey, "SECRETKEY");
  assert.equal(info.protocol, "SOCKS5");
});

// --- Cloudflare NS delegation (mocked CF API) -------------------------------

function mockCf() {
  const calls = [];
  const fetchImpl = async (url, init) => {
    const method = (init && init.method) || "GET";
    const body = init && init.body ? JSON.parse(init.body) : null;
    calls.push({ url, method, body });
    // GET list queries return an empty list (record does not exist yet).
    if (method === "GET") return { json: async () => ({ success: true, result: [] }) };
    // POST/PUT/DELETE succeed.
    return { json: async () => ({ success: true, result: { id: "rec_" + calls.length, ...(body || {}) } }) };
  };
  return { fetchImpl, calls };
}

test("cfDelegateSubdomain creates a glue A record and an NS delegation", async () => {
  const { fetchImpl, calls } = mockCf();
  const out = await cfDelegateSubdomain("tok", "zone1", { sub: "dns", ip: "203.0.113.9", zoneName: "example.com" }, { fetchImpl });
  assert.equal(out.fqdn, "dns.example.com");
  assert.equal(out.nsHost, "ns-dns.example.com");
  const creates = calls.filter((c) => c.method === "POST").map((c) => c.body);
  const a = creates.find((b) => b.type === "A");
  const ns = creates.find((b) => b.type === "NS");
  assert.ok(a && a.name === "ns-dns.example.com" && a.content === "203.0.113.9" && a.proxied === false);
  assert.ok(ns && ns.name === "dns.example.com" && ns.content === "ns-dns.example.com");
});

test("cfDelegateSubdomain rejects a bad subdomain label", async () => {
  const { fetchImpl } = mockCf();
  await assert.rejects(
    () => cfDelegateSubdomain("tok", "z", { sub: "bad label!", ip: "1.2.3.4", zoneName: "example.com" }, { fetchImpl }),
    /subdomain must be/,
  );
});

test("cfUndelegateSubdomain removes the NS + glue records", async () => {
  const calls = [];
  const fetchImpl = async (url, init) => {
    const method = (init && init.method) || "GET";
    calls.push({ url, method });
    if (method === "GET") return { json: async () => ({ success: true, result: [{ id: "r1" }] }) };
    return { json: async () => ({ success: true, result: {} }) };
  };
  const n = await cfUndelegateSubdomain("tok", "z", { sub: "dns", zoneName: "example.com" }, { fetchImpl });
  assert.equal(n, 2, "one NS + one A deleted");
  assert.equal(calls.filter((c) => c.method === "DELETE").length, 2);
});

// --- endpoint (shell stubbed via exec:false) --------------------------------

function startServer(kv) {
  const configPath = join(tmpdir(), `nova-dt-${randomBytes(6).toString("hex")}.json`);
  const server = createServer(kv, { managerOpts: { exec: false, configPath } });
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      resolve({ base: `http://127.0.0.1:${port}`, close: () => new Promise((r) => server.close(r)), configPath });
    });
  });
}
function freshKv() {
  const path = join(tmpdir(), `nova-dt-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return { kv, cleanup() { kv.close(); for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} } } };
}
function cookieValue(res) { const m = /(?:^|,\s*)auth=([^;]+)/.exec(res.headers.get("set-cookie") || ""); return m ? m[1] : null; }

test("/admin/dns-tunnel: enable validates + persists, disable clears, cf-delegate needs a token", async () => {
  const { kv, cleanup } = freshKv();
  const srv = await startServer(kv);
  try {
    let res = await fetch(srv.base + "/install/set", { method: "POST", headers: { "content-type": "application/json", "user-agent": UA }, body: JSON.stringify({ password: "hunter2secret" }) });
    const auth = { cookie: `auth=${cookieValue(res)}`, "user-agent": UA, "content-type": "application/json" };

    // A bad domain is rejected.
    res = await fetch(srv.base + "/admin/dns-tunnel", { method: "POST", headers: auth, body: JSON.stringify({ action: "enable", domain: "nope" }) });
    assert.equal(res.status, 400);

    // A valid domain enables + persists (shell stubbed, so no download/systemd).
    res = await fetch(srv.base + "/admin/dns-tunnel", { method: "POST", headers: auth, body: JSON.stringify({ action: "enable", domain: "dns.example.com", protocol: "SOCKS5", encMethod: 2 }) });
    assert.equal(res.status, 200, await res.text());

    res = await fetch(srv.base + "/admin/dns-tunnel", { headers: auth });
    let d = await res.json();
    assert.equal(d.config.enabled, true);
    assert.equal(d.config.domain, "dns.example.com");
    assert.equal(d.config.protocol, "SOCKS5");

    // Disable clears the flag.
    res = await fetch(srv.base + "/admin/dns-tunnel", { method: "POST", headers: auth, body: JSON.stringify({ action: "disable" }) });
    assert.equal(res.status, 200);
    d = await (await fetch(srv.base + "/admin/dns-tunnel", { headers: auth })).json();
    assert.equal(d.config.enabled, false);

    // cf-delegate with no Cloudflare token connected is a clear 400.
    res = await fetch(srv.base + "/admin/dns-tunnel", { method: "POST", headers: auth, body: JSON.stringify({ action: "cf-delegate", sub: "dns", zone: "example.com" }) });
    assert.equal(res.status, 400);
  } finally {
    await srv.close(); cleanup();
    try { rmSync(srv.configPath); } catch {}
  }
});
