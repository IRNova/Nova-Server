import test from "node:test";
import assert from "node:assert/strict";
import { buildSub } from "../src/subscription.mjs";
import { effectiveBridges, validateTunnel } from "../src/tunnels/config.mjs";

const decode = (b64) => Buffer.from(b64, "base64").toString("utf8");
const U = { id: "u1", uuid: "11111111-1111-4111-8111-111111111111", email: "a", name: "a", enabled: true };
const exitTunnel = (over = {}) => ({ backend: "backhaul", role: "exit", transport: "wssmux", tunnelPort: 2053, token: "abcdef12345678", bridgeAddr: "1.1.1.1:2053", forwards: ["443"], ...over });

test("effectiveBridges: single by default, the full list when set, deduped", () => {
  assert.deepEqual(effectiveBridges(exitTunnel()), ["1.1.1.1:2053"]);
  assert.deepEqual(
    effectiveBridges(exitTunnel({ bridges: ["1.1.1.1:2053", "2.2.2.2:2053", "1.1.1.1:2053"] })),
    ["1.1.1.1:2053", "2.2.2.2:2053"],
  );
  // A bridge role never expands (multi-bridge is an exit concept).
  assert.equal(effectiveBridges({ role: "bridge", bridgeAddr: "9.9.9.9:2053" }).length, 1);
});

test("validateTunnel accepts good failover bridges and rejects a malformed one", () => {
  assert.equal(validateTunnel(exitTunnel({ bridges: ["1.1.1.1:2053", "2.2.2.2:2053"] })).ok, true);
  assert.equal(validateTunnel(exitTunnel({ bridges: ["1.1.1.1:2053", "2.2.2.2:not-a-port"] })).ok, false);
  assert.equal(validateTunnel(exitTunnel({ bridges: ["1.1.1.1:2053", "evil.com/x:443"] })).ok, false);
});

test("a published multi-bridge sub mirrors each forwarded link across every bridge", async () => {
  const sub = decode(await buildSub([U], {
    host: "exit.example.com", protocols: { vless: true },
    tunnelAddr: "10.0.0.1", tunnelAddrs: ["10.0.0.1", "10.0.0.2", "10.0.0.3"], tunnelPorts: [443],
  }));
  // The front VLESS link exists on every bridge IP, SNI/host stays the exit.
  assert.match(sub, /vless:\/\/[^\n]*@10\.0\.0\.1:443[^\n]*sni=exit\.example\.com/);
  assert.match(sub, /@10\.0\.0\.2:443[^\n]*bridge%202/, "second bridge variant, tagged");
  assert.match(sub, /@10\.0\.0\.3:443[^\n]*bridge%203/, "third bridge variant, tagged");
});

test("vmess links (address inside base64) also fail over across bridges", async () => {
  const sub = decode(await buildSub([U], {
    host: "exit.example.com", protocols: { vmess: true },
    tunnelAddr: "10.0.0.1", tunnelAddrs: ["10.0.0.1", "10.0.0.2"], tunnelPorts: [443],
  }));
  const vmess = sub.split("\n").filter((l) => l.startsWith("vmess://"));
  const adds = vmess.map((l) => JSON.parse(Buffer.from(l.slice(8), "base64").toString("utf8")).add);
  assert.ok(adds.includes("10.0.0.1"), "primary bridge");
  assert.ok(adds.includes("10.0.0.2"), "failover bridge");
});

test("at most 8 failover bridges", () => {
  const many = Array.from({ length: 9 }, (_, i) => `1.1.1.${i}:2053`);
  assert.equal(validateTunnel(exitTunnel({ bridges: many })).ok, false);
  assert.equal(validateTunnel(exitTunnel({ bridges: many.slice(0, 8) })).ok, true);
});

test("a single-bridge sub is unchanged: no mirror, no bridge tag", async () => {
  const sub = decode(await buildSub([U], {
    host: "exit.example.com", protocols: { vless: true },
    tunnelAddr: "10.0.0.1", tunnelAddrs: ["10.0.0.1"], tunnelPorts: [443],
  }));
  assert.match(sub, /@10\.0\.0\.1:443/);
  assert.doesNotMatch(sub, /bridge%20/, "no failover tag with one bridge");
  assert.equal((sub.match(/vless:\/\//g) || []).length, 1, "exactly one front link");
});
