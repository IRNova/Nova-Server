// Panel access hardening: the stealth subpath (settings.panelPath) gates the
// whole panel surface behind /<path>/... with a decoy 404 everywhere else, and
// the extra panel port (settings.panelPort) adds a panel-only TLS front to the
// generated xray config. Exercised through the real node:http server.
import { test } from "node:test";
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { rmSync } from "node:fs";

import { openKv } from "../src/kv/sqlite.mjs";
import { createServer, panelPathOf, panelPortOf } from "../src/server.mjs";
import { generateXrayConfig } from "../src/xray/config.mjs";

const UA = "Nova/1.0.0 (desktop; sing-box)";

function startServer(kv, opts) {
  const server = createServer(kv, opts);
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      resolve({ base: `http://127.0.0.1:${port}`, close: () => new Promise((r) => server.close(r)) });
    });
  });
}
function freshKv() {
  const path = join(tmpdir(), `nova-pa-${randomBytes(6).toString("hex")}.db`);
  const kv = openKv(path);
  return { kv, cleanup() { kv.close(); for (const e of ["", "-wal", "-shm"]) { try { rmSync(path + e); } catch {} } } };
}
function cookieValue(res) {
  const m = /(?:^|,\s*)auth=([^;]+)/.exec(res.headers.get("set-cookie") || "");
  return m ? m[1] : null;
}
async function setup(srv) {
  const res = await fetch(srv.base + "/install/set", {
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": UA },
    body: JSON.stringify({ password: "hunter2secret" }),
  });
  const cookie = cookieValue(res);
  return { cookie: `auth=${cookie}`, "user-agent": UA, "content-type": "application/json" };
}

test("panelPathOf / panelPortOf normalize and reject bad values", () => {
  assert.equal(panelPathOf({ panelPath: "p-abc123" }), "p-abc123");
  assert.equal(panelPathOf({ panelPath: "/p-abc123/" }), "p-abc123");
  assert.equal(panelPathOf({ panelPath: "ab" }), "");           // too short
  assert.equal(panelPathOf({ panelPath: "has space" }), "");    // bad chars
  assert.equal(panelPathOf({ panelPath: "admin" }), "");        // reserved
  assert.equal(panelPathOf({}), "");
  assert.equal(panelPortOf({ panelPort: 2053 }), 2053);
  assert.equal(panelPortOf({ panelPort: "2053" }), 2053);
  assert.equal(panelPortOf({ panelPort: 0 }), 0);
  assert.equal(panelPortOf({ panelPort: 70000 }), 0);
  assert.equal(panelPortOf({}), 0);
});

test("stealth path: panel moves under /<path>/, everything else gets the decoy 404", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-pa-cfg-${randomBytes(6).toString("hex")}.json`);
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  try {
    const auth = await setup(srv);

    // Root serves the panel before a path is set.
    let res = await fetch(srv.base + "/", { headers: { "user-agent": UA } });
    assert.equal(res.status, 200);
    assert.match(await res.text(), /<title>Nova Server<\/title>/);

    // Set a stealth path (also proves the save endpoint accepts + normalizes it).
    res = await fetch(srv.base + "/admin/network-settings.json", {
      method: "POST", headers: auth,
      body: JSON.stringify({ panelPath: "/p-x7k2m9/" }),
    });
    assert.equal(res.status, 200);

    // Root is now a bare decoy 404 (HTML, not the JSON error).
    res = await fetch(srv.base + "/", { headers: { "user-agent": UA } });
    assert.equal(res.status, 404);
    assert.match(res.headers.get("content-type") || "", /text\/html/);
    assert.match(await res.text(), /404 Not Found/);

    // The whole panel surface without the prefix is hidden the same way.
    for (const p of ["/login", "/install/status", "/admin/network-settings.json", "/tgapp"]) {
      const r = await fetch(srv.base + p, { headers: auth });
      assert.equal(r.status, 404, p);
      assert.match(r.headers.get("content-type") || "", /text\/html/, p);
    }
    // Unmatched garbage paths also get the decoy, never the JSON "not found".
    res = await fetch(srv.base + "/some-random-path", { headers: { "user-agent": UA } });
    assert.equal(res.status, 404);
    assert.match(await res.text(), /404 Not Found/);

    // Under the prefix everything works: panel HTML (with the injected base) ...
    res = await fetch(srv.base + "/p-x7k2m9/", { headers: { "user-agent": UA } });
    assert.equal(res.status, 200);
    const html = await res.text();
    assert.match(html, /window\.__NOVA_BASE__="\/p-x7k2m9"/);
    // ... and the cookie-authed admin API.
    res = await fetch(srv.base + "/p-x7k2m9/admin/network-settings.json", { headers: auth });
    assert.equal(res.status, 200);
    const doc = await res.json();
    assert.equal(doc.panelPath, "p-x7k2m9");

    // User-facing endpoints stay at the root: /sub still answers (403 for a bad
    // token is its normal JSON answer, which proves it was routed, not decoyed).
    res = await fetch(srv.base + "/sub?token=nope", { headers: { "user-agent": UA } });
    assert.equal(res.status, 403);
    assert.match(res.headers.get("content-type") || "", /application\/json/);
    // /isp-profile stays public.
    res = await fetch(srv.base + "/isp-profile", { headers: { "user-agent": UA } });
    assert.equal(res.status, 200);
  } finally {
    await srv.close();
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("panelPath / panelPort validation rejects bad values", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-pa-cfg-${randomBytes(6).toString("hex")}.json`);
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  try {
    const auth = await setup(srv);
    const save = (body) => fetch(srv.base + "/admin/network-settings.json", {
      method: "POST", headers: auth, body: JSON.stringify(body),
    });

    assert.equal((await save({ panelPath: "aa" })).status, 400);          // too short
    assert.equal((await save({ panelPath: "admin" })).status, 400);       // reserved name
    assert.equal((await save({ panelPath: "has space" })).status, 400);   // bad chars
    assert.equal((await save({ panelPort: 443 })).status, 400);           // main front
    assert.equal((await save({ panelPort: 10085 })).status, 400);         // xray API
    assert.equal((await save({ panelPort: 99999 })).status, 400);         // out of range
    // Clearing works and valid values are normalized.
    assert.equal((await save({ panelPath: "", panelPort: 0 })).status, 200);
  } finally {
    await srv.close();
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("inbound on the panel port is refused (409)", async () => {
  const { kv, cleanup } = freshKv();
  const configPath = join(tmpdir(), `nova-pa-cfg-${randomBytes(6).toString("hex")}.json`);
  const srv = await startServer(kv, { managerOpts: { exec: false, configPath } });
  try {
    const auth = await setup(srv);
    let res = await fetch(srv.base + "/admin/network-settings.json", {
      method: "POST", headers: auth,
      body: JSON.stringify({ panelPort: 2053 }),
    });
    assert.equal(res.status, 200);
    res = await fetch(srv.base + "/admin/inbounds", {
      method: "POST", headers: auth,
      body: JSON.stringify({ action: "add", inbound: { protocol: "vless", network: "ws", security: "none", port: 2053 } }),
    });
    assert.equal(res.status, 409);
  } finally {
    await srv.close();
    cleanup();
    try { rmSync(configPath); } catch {}
  }
});

test("generateXrayConfig emits the panel-only TLS front for publicPanelPort", () => {
  const users = [{ id: "me", uuid: "11111111-1111-4111-8111-111111111111", email: "me", enabled: true }];
  const cfg = generateXrayConfig(users, { publicPanelPort: 2053 });
  const pf = cfg.inbounds.find((i) => i.tag === "panel-front");
  assert.ok(pf, "panel-front inbound present");
  assert.equal(pf.port, 2053);
  assert.equal(pf.streamSettings.security, "tls");
  assert.deepEqual(pf.settings.fallbacks, [{ dest: "127.0.0.1:8088", xver: 0 }]);
  assert.equal(pf.settings.clients.length, 0);

  // A standalone inbound colliding with the panel port is skipped, not emitted.
  const cfg2 = generateXrayConfig(users, {
    publicPanelPort: 2053,
    inbounds: [{ id: "x1", protocol: "vless", network: "ws", security: "none", port: 2053, enabled: true }],
  });
  assert.ok(!cfg2.inbounds.some((i) => i.tag !== "panel-front" && Number(i.port) === 2053 && i.tag !== "front"));
  assert.ok((cfg2._skippedInbounds || []).length >= 1, "collision surfaced in _skippedInbounds");

  // No extra front in PaaS mode (the platform edge owns the ports).
  const cfg3 = generateXrayConfig(users, { publicPanelPort: 2053, frontTls: false });
  assert.ok(!cfg3.inbounds.some((i) => i.tag === "panel-front"));
});
