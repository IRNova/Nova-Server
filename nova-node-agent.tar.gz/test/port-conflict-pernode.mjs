// Port conflicts are per-location. The main server's reserved ports (443 front,
// API, panel) only block main-server inbounds; every node has its own independent
// port space, so the same port is free on a node even while the main panel uses
// it. Two inbounds clash only when their locations overlap (same node, or one is
// "all"); the main server never clashes with a node.
import { test } from "node:test";
import assert from "node:assert/strict";
import { inboundPortConflict } from "../src/server.mjs";

const inb = (extra) => ({ id: "x", placement: "standalone", port: 443, nodeId: "local", ...extra });

test("main-server inbound on 443 is blocked (it is the front port)", () => {
  assert.match(inboundPortConflict([], inb({ nodeId: "local" }), {}) || "", /front port/);
});

test("node-placed inbound on 443 is ALLOWED (node has its own port space)", () => {
  assert.equal(inboundPortConflict([], inb({ nodeId: "nd1", port: 443 }), {}), null);
});

test("all-nodes inbound on 443 is allowed (not the main server's front)", () => {
  assert.equal(inboundPortConflict([], inb({ nodeId: "all", port: 443 }), {}), null);
});

test("main server 443 does not conflict with a node's 443", () => {
  const existing = [inb({ id: "main443", nodeId: "local", port: 443 })];
  assert.equal(inboundPortConflict(existing, inb({ id: "node443", nodeId: "nd1", port: 443 }), {}), null);
});

test("two different nodes may both use 8443", () => {
  const existing = [inb({ id: "a", nodeId: "nd1", port: 8443 })];
  assert.equal(inboundPortConflict(existing, inb({ id: "b", nodeId: "nd2", port: 8443 }), {}), null);
});

test("same node, same port -> conflict", () => {
  const existing = [inb({ id: "a", nodeId: "nd1", port: 8443 })];
  assert.match(inboundPortConflict(existing, inb({ id: "b", nodeId: "nd1", port: 8443 }), {}) || "", /already used/);
});

test("an all-nodes inbound conflicts with a specific node on the same port", () => {
  const existing = [inb({ id: "a", nodeId: "all", port: 8443 })];
  assert.match(inboundPortConflict(existing, inb({ id: "b", nodeId: "nd1", port: 8443 }), {}) || "", /already used/);
});

test("node reserved-port relaxation does not leak to the main server (10085 still reserved locally)", () => {
  assert.match(inboundPortConflict([], inb({ nodeId: "local", port: 10085 }), {}) || "", /reserved/);
  assert.equal(inboundPortConflict([], inb({ nodeId: "nd1", port: 10085 }), {}), null);
});
